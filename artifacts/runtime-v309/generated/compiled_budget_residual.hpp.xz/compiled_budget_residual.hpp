#pragma once
#include "budget_residual_features.hpp"
// LightGBM model SHA256: 8e63c24ef5f20a73bffd7fffedc914c7d8b9d5d0c7aff436046f1ddaccdfb9a8
__attribute__((noinline)) static double budget_tree_0(const BudgetResidualFeatures&r){
if(r.integer<27>()<=0){
if(r.integer<3>()<=75){
if(r.integer<53>()<=107){
if(r.integer<44>()<=16){
if(r.integer<1>()<=76){
if(r.integer<52>()<=39){
if(r.integer<53>()<=59){
if(r.integer<52>()<=9){
if(r.integer<31>()<=4920){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=0){
if(r.integer<10>()<=6){
return 0x1.496f0355e482dp+1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=4){
if(r.integer<52>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=286){
if(r.integer<53>()<=97){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<33>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<10>()<=35){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=13204){
if(r.integer<44>()<=13){
if(r.integer<7>()<=-43){
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=51){
if(r.integer<51>()<=-39){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=2122){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=93){
if(r.integer<26>()<=122){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<3>()<=51){
if(r.integer<19>()<=90){
if(r.integer<51>()<=60){
if(r.integer<39>()<=1){
if(r.integer<31>()<=9955){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=1){
return 0x0.0p+0;
}else{
return 0x1.4cccccccccccdp+2;
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<19>()<=85){
if(r.integer<20>()<=40){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x1.dbab54101f172p+1;
}
}
}else{
if(r.integer<20>()<=48){
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=67){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<52>()<=6){
if(r.integer<52>()<=1){
if(r.integer<5>()<=277){
if(r.integer<1>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=280){
if(r.integer<6>()<=279){
if(r.integer<3>()<=38){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=76){
if(r.integer<53>()<=59){
if(r.integer<0>()<=911){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=34){
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=36){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=4){
if(r.integer<52>()<=36){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=280){
if(r.integer<10>()<=89){
if(r.integer<51>()<=-62){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=29){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=2347){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=29){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=-21){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=6732){
if(r.integer<1>()<=75){
if(r.integer<43>()<=4){
if(r.integer<5>()<=345){
if(r.integer<8>()<=117){
if(r.integer<35>()<=1){
if(r.integer<31>()<=4521){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-29){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=6034){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=150){
if(r.integer<47>()<=7){
if(r.integer<1>()<=12){
if(r.integer<4>()<=96){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=4){
if(r.integer<50>()<=30){
if(r.integer<31>()<=5091){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=2){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=409){
if(r.integer<8>()<=96){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<47>()<=-7){
if(r.integer<9>()<=2){
if(r.integer<1>()<=35){
return 0x0.0p+0;
}else{
return 0x1.199999999999ap+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=14){
if(r.integer<2>()<=81){
if(r.integer<1>()<=20){
return 0x1.b333333333334p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=65){
if(r.integer<1>()<=85){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap+2;
}
}
}
}else{
if(r.integer<5>()<=340){
if(r.integer<8>()<=-266){
if(r.integer<35>()<=1){
if(r.integer<43>()<=4){
if(r.integer<6>()<=409){
if(r.integer<10>()<=333){
return -0x1.0000000000000p+0;
}else{
return -0x1.599999999999ap+2;
}
}else{
if(r.integer<50>()<=-21){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-2;
}
}
}else{
if(r.integer<43>()<=6){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-1;
}
}
}else{
if(r.integer<43>()<=3){
if(r.integer<35>()<=6){
if(r.integer<35>()<=4){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return -0x1.ccccccccccccdp+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=82){
return -0x1.e666666666667p+1;
}else{
return 0x1.3333333333334p-1;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=74){
if(r.integer<31>()<=8781){
if(r.integer<8>()<=93){
if(r.integer<35>()<=1){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=6){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}
}else{
if(r.integer<35>()<=6){
if(r.integer<50>()<=29){
if(r.integer<35>()<=4){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=3){
if(r.integer<6>()<=409){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<35>()<=1){
if(r.integer<43>()<=5){
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
if(r.integer<52>()<=25){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<38>()<=6){
if(r.integer<31>()<=10320){
if(r.integer<43>()<=4){
if(r.integer<2>()<=286){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=4781){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-2;
}
}
}else{
if(r.integer<1>()<=65){
if(r.integer<8>()<=-111){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<38>()<=0){
if(r.integer<35>()<=0){
if(r.integer<8>()<=129){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=95){
if(r.integer<43>()<=3){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3333333333334p+0;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<0>()<=5105){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-2;
}
}else{
if(r.integer<44>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=42){
return 0x1.0000000000000p+0;
}else{
if(r.integer<19>()<=94){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=111){
return 0x0.0p+0;
}else{
return 0x1.8000000000000p+1;
}
}
}
}
}
}
}else{
if(r.integer<31>()<=9813){
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
if(r.integer<1>()<=85){
if(r.integer<31>()<=7882){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=75){
if(r.integer<31>()<=8970){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<53>()<=288){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<3>()<=89){
if(r.integer<29>()<=12){
if(r.integer<28>()<=0){
if(r.integer<52>()<=8){
if(r.integer<19>()<=48){
return 0x1.999999999999ap-2;
}else{
if(r.integer<1>()<=89){
if(r.integer<1>()<=75){
return 0x1.ccccccccccccdp+1;
}else{
return 0x1.6666666666667p+4;
}
}else{
return 0x1.999999999999ap+0;
}
}
}else{
if(r.integer<29>()<=4){
if(r.integer<15>()<=5){
return 0x1.3333333333334p+0;
}else{
return 0x1.6cccccccccccdp+3;
}
}else{
if(r.integer<31>()<=7882){
if(r.integer<46>()<=-2){
return 0x1.999999999999ap+0;
}else{
if(r.integer<46>()<=6){
return 0x0.0p+0;
}else{
return 0x1.6666666666667p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=47){
if(r.integer<20>()<=65){
return 0x1.6666666666667p+0;
}else{
if(r.integer<39>()<=-1){
return 0x1.3333333333334p+0;
}else{
if(r.integer<5>()<=141){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<46>()<=-2){
if(r.integer<20>()<=86){
if(r.integer<8>()<=9){
if(r.integer<31>()<=8634){
if(r.integer<0>()<=1512){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=63){
return 0x1.c000000000000p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-8){
return 0x1.f333333333334p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=43){
if(r.integer<43>()<=5){
if(r.integer<31>()<=10616){
if(r.integer<20>()<=62){
if(r.integer<51>()<=12){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
if(r.integer<20>()<=88){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-6){
if(r.integer<47>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=6){
if(r.integer<6>()<=37){
if(r.integer<8>()<=21){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=22){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<51>()<=18){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=24){
if(r.integer<19>()<=45){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=8856){
if(r.integer<46>()<=6){
if(r.integer<53>()<=36){
if(r.integer<19>()<=38){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<26>()<=68){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=64){
if(r.integer<8>()<=24){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
if(r.integer<8>()<=36){
if(r.integer<20>()<=86){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=0){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<7>()<=-17){
return 0x1.6666666666667p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=2637){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<1>()<=87){
if(r.integer<10>()<=29){
if(r.integer<20>()<=48){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=99){
if(r.integer<44>()<=16){
if(r.integer<39>()<=-2){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.3333333333334p+1;
}
}else{
if(r.integer<31>()<=9243){
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<5>()<=52){
return -0x1.199999999999ap+1;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=107){
if(r.integer<44>()<=13){
if(r.integer<5>()<=307){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=1){
if(r.integer<6>()<=283){
if(r.integer<17>()<=7){
return 0x0.0p+0;
}else{
return 0x1.ccccccccccccdp+1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=7){
if(r.integer<53>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=6666){
if(r.integer<44>()<=16){
if(r.integer<1>()<=89){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=2){
if(r.integer<6>()<=280){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=89){
return 0x1.3333333333334p+1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<36>()<=18){
if(r.integer<31>()<=8387){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-261){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=12945){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}
}
}else{
if(r.integer<1>()<=99){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=9368){
if(r.integer<53>()<=34){
if(r.integer<28>()<=0){
if(r.integer<36>()<=10){
if(r.integer<20>()<=12){
if(r.integer<47>()<=-7){
return 0x1.d99999999999ap+3;
}else{
if(r.integer<19>()<=85){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}
}
}else{
if(r.integer<19>()<=9){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}
}else{
if(r.integer<19>()<=11){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=20){
if(r.integer<20>()<=1){
return -0x1.6666666666667p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=20){
if(r.integer<20>()<=63){
if(r.integer<19>()<=40){
if(r.integer<20>()<=49){
if(r.integer<20>()<=45){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<51>()<=9){
if(r.integer<20>()<=52){
if(r.integer<19>()<=49){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<20>()<=48){
if(r.integer<47>()<=0){
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x1.199999999999ap+1;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3333333333334p-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=16){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=74){
if(r.integer<19>()<=76){
if(r.integer<19>()<=24){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<9>()<=39){
if(r.integer<19>()<=48){
if(r.integer<38>()<=6){
if(r.integer<36>()<=18){
if(r.integer<29>()<=11){
if(r.integer<20>()<=42){
if(r.integer<53>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=30){
return 0x1.4cccccccccccdp+1;
}else{
return 0x1.6666666666667p+0;
}
}
}else{
if(r.integer<29>()<=3){
if(r.integer<14>()<=3){
return 0x1.4000000000000p+2;
}else{
return 0x1.999999999999ap+0;
}
}else{
if(r.integer<10>()<=79){
return 0x1.0000000000000p+0;
}else{
if(r.integer<20>()<=49){
return 0x1.ccccccccccccdp+0;
}else{
return 0x1.3333333333334p-1;
}
}
}
}
}else{
if(r.integer<20>()<=50){
if(r.integer<10>()<=47){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=16){
return 0x1.999999999999ap-1;
}else{
return 0x1.2666666666667p+3;
}
}
}else{
if(r.integer<53>()<=79){
return 0x1.999999999999ap-2;
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<29>()<=9){
if(r.integer<3>()<=74){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x1.3333333333334p-1;
}
}
}else{
if(r.integer<23>()<=53){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=9){
if(r.integer<44>()<=16){
return 0x1.3333333333334p-1;
}else{
if(r.integer<6>()<=279){
return 0x1.799999999999ap+3;
}else{
return 0x1.999999999999ap-1;
}
}
}else{
if(r.integer<44>()<=8){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
if(r.integer<53>()<=105){
if(r.integer<53>()<=47){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=79){
return 0x1.0000000000000p+0;
}else{
if(r.integer<44>()<=10){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-1;
}
}
}
}else{
if(r.integer<10>()<=150){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=190){
return 0x1.999999999999ap-2;
}else{
if(r.integer<29>()<=9){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<19>()<=46){
if(r.integer<29>()<=11){
if(r.integer<36>()<=10){
if(r.integer<3>()<=38){
if(r.integer<5>()<=383){
return 0x1.3333333333334p+1;
}else{
return 0x1.999999999999ap-1;
}
}else{
if(r.integer<31>()<=8050){
if(r.integer<35>()<=1){
return 0x1.999999999999ap-1;
}else{
return 0x1.ccccccccccccdp+0;
}
}else{
return 0x1.3333333333334p-1;
}
}
}else{
if(r.integer<5>()<=280){
if(r.integer<19>()<=13){
if(r.integer<8>()<=33){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x1.999999999999ap-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=9){
if(r.integer<10>()<=53){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=0){
return 0x1.3333333333334p-1;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<51>()<=-83){
if(r.integer<20>()<=35){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=63){
if(r.integer<8>()<=105){
if(r.integer<26>()<=44){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=2301){
if(r.integer<29>()<=20){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=25){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<10>()<=91){
if(r.integer<30>()<=16){
if(r.integer<20>()<=49){
if(r.integer<30>()<=8){
if(r.integer<43>()<=5){
if(r.integer<10>()<=39){
if(r.integer<20>()<=14){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}else{
return 0x1.3333333333334p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<4>()<=337){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=2362){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=57){
if(r.integer<3>()<=50){
if(r.integer<25>()<=198){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=465){
if(r.integer<4>()<=21){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=43){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<20>()<=42){
if(r.integer<30>()<=9){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=58){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-104){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=85){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=9){
if(r.integer<6>()<=279){
return 0x1.2000000000000p+3;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<19>()<=40){
if(r.integer<36>()<=13){
return 0x1.999999999999ap+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<3>()<=59){
return 0x1.999999999999ap-2;
}else{
return 0x1.999999999999ap-1;
}
}
}
}else{
if(r.integer<0>()<=2409){
if(r.integer<29>()<=12){
return 0x1.ccccccccccccdp+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<1>()<=62){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=53){
return 0x1.0000000000000p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<53>()<=26){
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=3){
if(r.integer<2>()<=99){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=1){
return -0x1.7333333333334p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=5){
if(r.integer<5>()<=269){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=10){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=28){
if(r.integer<20>()<=49){
if(r.integer<20>()<=46){
return 0x0.0p+0;
}else{
return -0x1.3333333333334p-1;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<19>()<=63){
if(r.integer<51>()<=-17){
return 0x1.999999999999ap-3;
}else{
if(r.integer<20>()<=49){
if(r.integer<19>()<=49){
if(r.integer<20>()<=45){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<20>()<=63){
if(r.integer<50>()<=48){
return 0x1.0000000000000p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<53>()<=107){
if(r.integer<44>()<=13){
if(r.integer<53>()<=39){
if(r.integer<28>()<=0){
if(r.integer<20>()<=14){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=15){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-1;
}
}
}else{
if(r.integer<20>()<=3){
return -0x1.6666666666667p+0;
}else{
if(r.integer<19>()<=15){
if(r.integer<10>()<=25){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=17){
if(r.integer<19>()<=49){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<20>()<=69){
if(r.integer<19>()<=71){
if(r.integer<20>()<=49){
if(r.integer<19>()<=49){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<6>()<=55){
if(r.integer<0>()<=1949){
if(r.integer<53>()<=47){
return -0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=40){
if(r.integer<29>()<=16){
return 0x1.3333333333334p-1;
}else{
if(r.integer<9>()<=74){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<29>()<=20){
if(r.integer<20>()<=58){
if(r.integer<53>()<=47){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=26){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<53>()<=91){
if(r.integer<19>()<=50){
if(r.integer<53>()<=49){
if(r.integer<20>()<=4){
return -0x1.6666666666667p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=-81){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<51>()<=81){
if(r.integer<24>()<=56){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=22){
if(r.integer<3>()<=38){
return 0x1.999999999999ap-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=30){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=39){
if(r.integer<28>()<=0){
if(r.integer<20>()<=87){
if(r.integer<19>()<=86){
return 0x1.999999999999ap-2;
}else{
return 0x1.0000000000000p+1;
}
}else{
return 0x1.a666666666667p+2;
}
}else{
if(r.integer<20>()<=9){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=14){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=81){
if(r.integer<20>()<=73){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<35>()<=0){
return 0x1.3333333333334p-1;
}else{
if(r.integer<31>()<=11962){
if(r.integer<20>()<=20){
if(r.integer<1>()<=61){
return 0x1.ccccccccccccdp+0;
}else{
if(r.integer<25>()<=242){
return 0x1.0000000000000p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x1.999999999999ap-2;
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=9){
if(r.integer<47>()<=-7){
if(r.integer<8>()<=-185){
return 0x1.0000000000000p+0;
}else{
return 0x1.0cccccccccccdp+3;
}
}else{
if(r.integer<47>()<=7){
if(r.integer<35>()<=4){
if(r.integer<5>()<=367){
if(r.integer<8>()<=-332){
if(r.integer<43>()<=3){
if(r.integer<35>()<=3){
return -0x1.6666666666667p+1;
}else{
return 0x1.ccccccccccccdp+0;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x1.999999999999ap-1;
}
}else{
if(r.integer<0>()<=5748){
if(r.integer<8>()<=132){
return 0x1.3333333333334p+3;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.0000000000000p+0;
}
}
}
}else{
if(r.integer<19>()<=49){
if(r.integer<1>()<=103){
if(r.integer<31>()<=14740){
if(r.integer<5>()<=351){
if(r.integer<35>()<=2){
if(r.integer<43>()<=3){
if(r.integer<51>()<=-271){
if(r.integer<6>()<=329){
return -0x1.199999999999ap+1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=9){
return 0x1.999999999999ap-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<8>()<=141){
if(r.integer<5>()<=262){
if(r.integer<20>()<=21){
return 0x1.0000000000000p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<31>()<=10997){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=150){
return 0x1.999999999999ap-1;
}else{
if(r.integer<19>()<=36){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=16763){
return 0x0.0p+0;
}else{
return -0x1.3333333333334p-1;
}
}
}else{
if(r.integer<8>()<=117){
if(r.integer<44>()<=16){
if(r.integer<35>()<=4){
if(r.integer<31>()<=14435){
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=4){
return 0x1.999999999999ap-3;
}else{
return 0x1.999999999999ap-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-81){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=5647){
return 0x1.0000000000000p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-79){
if(r.integer<35>()<=0){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}else{
if(r.integer<19>()<=18){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<50>()<=-81){
if(r.integer<43>()<=4){
if(r.integer<6>()<=412){
if(r.integer<31>()<=14167){
if(r.integer<35>()<=4){
if(r.integer<35>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<5>()<=455){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=367){
if(r.integer<35>()<=4){
if(r.integer<43>()<=4){
if(r.integer<51>()<=-290){
if(r.integer<43>()<=0){
if(r.integer<35>()<=2){
return -0x1.999999999999ap-2;
}else{
return 0x1.999999999999ap-3;
}
}else{
return -0x1.e666666666667p+1;
}
}else{
if(r.integer<50>()<=100){
return 0x0.0p+0;
}else{
return -0x1.3333333333334p-1;
}
}
}else{
if(r.integer<50>()<=-51){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=5){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=-146){
if(r.integer<35>()<=6){
if(r.integer<24>()<=28){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=5){
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=460){
if(r.integer<5>()<=411){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=69){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-131){
if(r.integer<20>()<=30){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<31>()<=14167){
if(r.integer<29>()<=10){
if(r.integer<19>()<=50){
if(r.integer<38>()<=-2){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=12194){
if(r.integer<3>()<=39){
return 0x1.0000000000000p+0;
}else{
if(r.integer<5>()<=271){
if(r.integer<26>()<=64){
return -0x1.999999999999ap-2;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x1.999999999999ap-1;
}
}
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<51>()<=126){
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=51){
if(r.integer<50>()<=-82){
if(r.integer<51>()<=-140){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=5){
if(r.integer<5>()<=345){
if(r.integer<30>()<=19){
if(r.integer<10>()<=353){
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=18){
return 0x0.0p+0;
}else{
if(r.integer<10>()<=299){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=15121){
if(r.integer<19>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=139){
return -0x1.999999999999ap-1;
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<10>()<=271){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_1(const BudgetResidualFeatures&r){
if(r.integer<27>()<=0){
if(r.integer<3>()<=75){
if(r.integer<53>()<=107){
if(r.integer<44>()<=16){
if(r.integer<9>()<=39){
if(r.integer<1>()<=80){
if(r.integer<53>()<=59){
if(r.integer<52>()<=9){
if(r.integer<31>()<=4991){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=1){
if(r.integer<53>()<=6){
return 0x1.976d896000530p-6;
}else{
if(r.integer<5>()<=37){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=280){
if(r.integer<53>()<=97){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=76){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<19>()<=85){
if(r.integer<20>()<=59){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=9){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
if(r.integer<20>()<=45){
if(r.integer<6>()<=478){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<10>()<=45){
if(r.integer<52>()<=48){
return 0x0.0p+0;
}else{
if(r.integer<28>()<=0){
if(r.integer<4>()<=117){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=6901){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
if(r.integer<23>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=12036){
return 0x0.0p+0;
}else{
if(r.integer<15>()<=3){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.999999999999ap-2;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<52>()<=6){
if(r.integer<52>()<=1){
if(r.integer<5>()<=277){
if(r.integer<1>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=280){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=80){
if(r.integer<53>()<=59){
if(r.integer<0>()<=911){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=2301){
if(r.integer<52>()<=29){
if(r.integer<5>()<=286){
if(r.integer<53>()<=95){
if(r.integer<51>()<=-62){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=2){
if(r.integer<13>()<=3){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=31){
if(r.integer<6>()<=284){
if(r.integer<53>()<=49){
return 0x1.0000000000000p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<28>()<=0){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=7915){
if(r.integer<1>()<=76){
if(r.integer<43>()<=4){
if(r.integer<5>()<=345){
if(r.integer<31>()<=5633){
if(r.integer<52>()<=28){
if(r.integer<35>()<=4){
if(r.integer<8>()<=117){
if(r.integer<31>()<=4521){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<36>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=26){
if(r.integer<35>()<=4){
if(r.integer<8>()<=-108){
if(r.integer<47>()<=7){
if(r.integer<52>()<=14){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<2>()<=147){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=124){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<9>()<=28){
if(r.integer<31>()<=6400){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=6868){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<7>()<=39){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=5700){
if(r.integer<3>()<=66){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=155){
if(r.integer<1>()<=74){
if(r.integer<31>()<=9368){
if(r.integer<52>()<=25){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
if(r.integer<52>()<=53){
if(r.integer<53>()<=186){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8563){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=62){
if(r.integer<31>()<=11064){
if(r.integer<52>()<=32){
if(r.integer<0>()<=4123){
return 0x0.0p+0;
}else{
return -0x1.1c28f5c28f5c3p+2;
}
}else{
if(r.integer<44>()<=9){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=73){
return -0x1.3333333333334p+1;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<31>()<=11571){
if(r.integer<0>()<=4781){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<31>()<=13115){
return 0x0.0p+0;
}else{
return 0x1.ccccccccccccdp+0;
}
}
}else{
if(r.integer<31>()<=9674){
if(r.integer<1>()<=85){
if(r.integer<52>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=51){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=69){
if(r.integer<43>()<=4){
if(r.integer<2>()<=442){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<23>()<=31){
if(r.integer<3>()<=88){
if(r.integer<9>()<=42){
if(r.integer<53>()<=22){
if(r.integer<46>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=59){
return 0x1.947ae147ae148p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=79){
if(r.integer<31>()<=5600){
if(r.integer<50>()<=-13){
return 0x1.3333333333334p-1;
}else{
return 0x1.50a3d70a3d70bp+3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<46>()<=0){
if(r.integer<50>()<=-3){
if(r.integer<31>()<=9453){
if(r.integer<6>()<=267){
if(r.integer<39>()<=0){
if(r.integer<1>()<=94){
if(r.integer<14>()<=9){
if(r.integer<36>()<=3){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<38>()<=1){
return 0x1.0a3d70a3d70a4p-1;
}else{
return -0x1.eb851eb851ebap-3;
}
}
}else{
return 0x1.663e750879678p-1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=91){
return 0x1.e147ae147ae14p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=485){
if(r.integer<20>()<=58){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.eb851eb851eb8p-2;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.6147ae147ae15p+2;
}
}else{
if(r.integer<20>()<=58){
if(r.integer<8>()<=-70){
return 0x0.0p+0;
}else{
return 0x1.6cccccccccccdp+3;
}
}else{
if(r.integer<8>()<=-60){
if(r.integer<20>()<=87){
if(r.integer<0>()<=1818){
return 0x1.0f5c28f5c28f6p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3d70a3d70a3d8p+3;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<46>()<=-1){
if(r.integer<20>()<=59){
if(r.integer<8>()<=3){
return 0x0.0p+0;
}else{
return 0x1.30a3d70a3d70bp+3;
}
}else{
if(r.integer<20>()<=91){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-5){
return 0x1.e8f5c28f5c290p+2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=392){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=107){
if(r.integer<44>()<=13){
if(r.integer<5>()<=307){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=2){
if(r.integer<47>()<=7){
if(r.integer<51>()<=-13){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-1){
return 0x1.1eb851eb851ebp-2;
}else{
if(r.integer<9>()<=0){
return 0x1.003f234bc7f84p+1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=6){
return 0x1.8000000000000p+1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=7747){
if(r.integer<44>()<=16){
if(r.integer<1>()<=89){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=2){
if(r.integer<6>()<=280){
if(r.integer<31>()<=6168){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=90){
if(r.integer<38>()<=-1){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=271){
if(r.integer<51>()<=-113){
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=38){
if(r.integer<20>()<=36){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=46){
if(r.integer<46>()<=-2){
if(r.integer<7>()<=24){
return 0x1.327fe4fb1777dp+3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<36>()<=16){
if(r.integer<23>()<=46){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=68){
return 0x0.0p+0;
}else{
return 0x1.b1bd9e39887e5p-1;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=48){
if(r.integer<0>()<=1094){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=5534){
if(r.integer<7>()<=1){
if(r.integer<36>()<=13){
if(r.integer<3>()<=77){
return 0x1.570a3d70a3d70p+3;
}else{
return 0x1.751eb851eb852p+4;
}
}else{
if(r.integer<50>()<=0){
return 0x1.01eb851eb851fp+4;
}else{
return -0x1.47ae147ae147dp+0;
}
}
}else{
if(r.integer<3>()<=77){
if(r.integer<0>()<=966){
return 0x1.295033f7a8e3ep-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=8){
if(r.integer<15>()<=7){
if(r.integer<54>()<=3){
return 0x1.83d70a3d70a3dp+3;
}else{
if(r.integer<6>()<=43){
if(r.integer<8>()<=36){
return 0x0.0p+0;
}else{
return 0x1.0a3d70a3d70a4p-1;
}
}else{
if(r.integer<1>()<=84){
if(r.integer<38>()<=-1){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x1.47ae147ae147cp+2;
}
}else{
if(r.integer<8>()<=108){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}
}
}
}else{
return 0x1.351eb851eb852p+4;
}
}else{
if(r.integer<53>()<=61){
if(r.integer<5>()<=340){
if(r.integer<1>()<=64){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=64){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<30>()<=3){
return 0x1.3333333333334p-1;
}else{
if(r.integer<0>()<=1653){
if(r.integer<5>()<=335){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<31>()<=9717){
if(r.integer<46>()<=-1){
if(r.integer<3>()<=91){
if(r.integer<20>()<=57){
if(r.integer<8>()<=-78){
return 0x1.999999999999ap-3;
}else{
return 0x1.e666666666667p+2;
}
}else{
if(r.integer<20>()<=88){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=36){
return 0x1.4e147ae147ae2p+3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=284){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
if(r.integer<1>()<=75){
if(r.integer<51>()<=-104){
if(r.integer<47>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<31>()<=8050){
if(r.integer<38>()<=6){
if(r.integer<50>()<=1){
return 0x1.d0a3d70a3d70ap+3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=16){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<51>()<=-122){
if(r.integer<7>()<=28){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-1;
}
}else{
if(r.integer<20>()<=59){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=10160){
if(r.integer<53>()<=20){
if(r.integer<28>()<=0){
if(r.integer<6>()<=149){
if(r.integer<23>()<=50){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
if(r.integer<31>()<=8282){
if(r.integer<6>()<=95){
if(r.integer<43>()<=5){
if(r.integer<8>()<=-185){
if(r.integer<20>()<=31){
return 0x1.1eb851eb851ebp+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<26>()<=16){
return 0x1.999999999999ap-2;
}else{
if(r.integer<1>()<=65){
if(r.integer<20>()<=49){
if(r.integer<6>()<=11){
return 0x1.147ae147ae148p+0;
}else{
if(r.integer<25>()<=76){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=71){
if(r.integer<19>()<=46){
return 0x0.0p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<2>()<=414){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=70){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-2;
}
}
}
}else{
if(r.integer<0>()<=1421){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}
}
}else{
if(r.integer<3>()<=70){
if(r.integer<2>()<=15){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=75){
if(r.integer<43>()<=6){
if(r.integer<2>()<=39){
return 0x1.d70a3d70a3d70p-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=54){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-24){
return 0x1.999999999999ap-3;
}else{
if(r.integer<20>()<=47){
if(r.integer<31>()<=5264){
return -0x1.eb851eb851ebap-4;
}else{
if(r.integer<1>()<=57){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<4>()<=246){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=15){
return 0x1.1eb851eb851ebp-2;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<51>()<=-43){
if(r.integer<20>()<=35){
if(r.integer<3>()<=71){
if(r.integer<19>()<=62){
return 0x1.d70a3d70a3d70p-1;
}else{
if(r.integer<50>()<=-24){
return 0x0.0p+0;
}else{
return -0x1.eb851eb851ebap-4;
}
}
}else{
if(r.integer<19>()<=69){
if(r.integer<36>()<=13){
return 0x1.b851eb851eb85p+0;
}else{
if(r.integer<35>()<=1){
return 0x0.0p+0;
}else{
return 0x1.51eb851eb851fp+0;
}
}
}else{
if(r.integer<47>()<=-1){
return 0x1.47ae147ae147ap-4;
}else{
return 0x1.c28f5c28f5c2ap-1;
}
}
}
}else{
if(r.integer<20>()<=86){
if(r.integer<29>()<=9){
if(r.integer<19>()<=71){
if(r.integer<19>()<=13){
if(r.integer<30>()<=7){
return -0x1.eb851eb851ebap-4;
}else{
return 0x1.eb851eb851eb8p-3;
}
}else{
if(r.integer<5>()<=152){
return 0x1.6666666666667p+0;
}else{
return 0x1.3333333333334p-1;
}
}
}else{
if(r.integer<20>()<=59){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=50){
if(r.integer<7>()<=-43){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=9){
return 0x1.eb851eb851eb8p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=27){
if(r.integer<31>()<=4370){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=69){
return 0x1.47ae147ae147cp-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<51>()<=-64){
if(r.integer<3>()<=48){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.0000000000000p+1;
}
}
}
}else{
if(r.integer<20>()<=13){
if(r.integer<2>()<=57){
return 0x1.eb851eb851eb8p-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=72){
if(r.integer<24>()<=43){
return 0x1.eb851eb851eb8p-4;
}else{
if(r.integer<51>()<=36){
if(r.integer<19>()<=21){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=71){
return 0x1.999999999999ap-3;
}else{
if(r.integer<20>()<=41){
if(r.integer<5>()<=269){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<47>()<=1){
if(r.integer<20>()<=43){
if(r.integer<3>()<=63){
return 0x1.999999999999ap-3;
}else{
if(r.integer<0>()<=1307){
return 0x0.0p+0;
}else{
return 0x1.c28f5c28f5c2ap-1;
}
}
}else{
if(r.integer<51>()<=69){
return 0x1.6666666666667p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}
}else{
return 0x1.47ae147ae147ap-3;
}
}
}
}else{
if(r.integer<8>()<=-24){
if(r.integer<20>()<=85){
if(r.integer<15>()<=5){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=42){
return 0x1.2e147ae147ae2p+1;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<3>()<=66){
if(r.integer<1>()<=102){
if(r.integer<19>()<=23){
return 0x1.28f5c28f5c28fp+0;
}else{
if(r.integer<19>()<=85){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-1){
if(r.integer<2>()<=311){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=66){
if(r.integer<20>()<=97){
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<52>()<=64){
if(r.integer<5>()<=345){
if(r.integer<31>()<=9084){
if(r.integer<20>()<=53){
if(r.integer<10>()<=81){
if(r.integer<19>()<=47){
if(r.integer<0>()<=1997){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=41){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=51){
return 0x1.47ae147ae147ap-2;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=9368){
if(r.integer<20>()<=52){
if(r.integer<1>()<=59){
return 0x1.47ae147ae147cp-2;
}else{
if(r.integer<0>()<=1687){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=46){
if(r.integer<3>()<=39){
if(r.integer<5>()<=150){
if(r.integer<39>()<=1){
return 0x1.ccccccccccccdp+0;
}else{
return 0x1.8000000000000p+2;
}
}else{
if(r.integer<36>()<=18){
if(r.integer<10>()<=89){
if(r.integer<20>()<=46){
if(r.integer<0>()<=2409){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.47ae147ae147cp-1;
}
}else{
return 0x1.f5c28f5c28f5dp+0;
}
}else{
return 0x1.1eb851eb851ebp-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=48){
if(r.integer<6>()<=95){
return 0x1.47ae147ae147ap-4;
}else{
return 0x1.851eb851eb852p-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<30>()<=15){
if(r.integer<8>()<=84){
if(r.integer<20>()<=36){
if(r.integer<46>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=-1){
return 0x1.47ae147ae147cp-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-84){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<30>()<=3){
if(r.integer<20>()<=49){
if(r.integer<6>()<=279){
if(r.integer<6>()<=263){
return 0x1.47ae147ae147cp-2;
}else{
if(r.integer<53>()<=38){
if(r.integer<19>()<=49){
return 0x0.0p+0;
}else{
return 0x1.ea3d70a3d70a4p+3;
}
}else{
return 0x1.e3d70a3d70a3dp+3;
}
}
}else{
return 0x1.eb851eb851eb8p-4;
}
}else{
if(r.integer<31>()<=8017){
if(r.integer<35>()<=6){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=274){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=2){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<19>()<=51){
if(r.integer<36>()<=10){
if(r.integer<29>()<=11){
if(r.integer<10>()<=37){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x1.c28f5c28f5c2ap+0;
}
}else{
if(r.integer<8>()<=129){
if(r.integer<19>()<=2){
return 0x1.ae147ae147ae2p-1;
}else{
return 0x1.3333333333334p+1;
}
}else{
if(r.integer<19>()<=31){
return 0x1.e147ae147ae15p+0;
}else{
return 0x1.851eb851eb852p-1;
}
}
}
}else{
if(r.integer<55>()<=4){
if(r.integer<25>()<=210){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x1.3333333333334p+0;
}
}else{
if(r.integer<51>()<=54){
return 0x1.eb851eb851eb8p-2;
}else{
if(r.integer<47>()<=-1){
if(r.integer<30>()<=12){
if(r.integer<20>()<=63){
return 0x1.07ae147ae147bp+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<39>()<=-1){
if(r.integer<8>()<=-241){
return -0x1.999999999999ap-3;
}else{
return 0x1.28f5c28f5c28fp+0;
}
}else{
if(r.integer<30>()<=20){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=45){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<3>()<=57){
if(r.integer<5>()<=471){
if(r.integer<4>()<=149){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=4){
if(r.integer<16>()<=6){
return 0x1.47ae147ae147ap-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.47ae147ae147cp-2;
}
}
}else{
return 0x1.eb851eb851eb8p-2;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<20>()<=34){
if(r.integer<29>()<=18){
if(r.integer<52>()<=28){
return 0x1.3333333333334p-1;
}else{
if(r.integer<28>()<=0){
return 0x1.47ae147ae147ap-1;
}else{
return 0x1.70a3d70a3d70bp+0;
}
}
}else{
return 0x1.f5c28f5c28f5dp+0;
}
}else{
if(r.integer<28>()<=0){
if(r.integer<8>()<=-99){
if(r.integer<20>()<=86){
return 0x0.0p+0;
}else{
return 0x1.ae147ae147ae2p-1;
}
}else{
if(r.integer<8>()<=57){
return 0x1.47ae147ae147cp+0;
}else{
return 0x1.47ae147ae147cp-2;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=21){
return -0x1.47ae147ae147cp-3;
}else{
return 0x1.47ae147ae147ap-5;
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=14435){
if(r.integer<44>()<=13){
if(r.integer<51>()<=-23){
if(r.integer<20>()<=36){
if(r.integer<50>()<=60){
if(r.integer<19>()<=62){
if(r.integer<19>()<=10){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<53>()<=49){
if(r.integer<20>()<=2){
if(r.integer<51>()<=-37){
return -0x1.d1eb851eb851fp+1;
}else{
return -0x1.eb851eb851eb4p-3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=107){
return 0x1.0a3d70a3d70a4p-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=71){
if(r.integer<43>()<=4){
return 0x1.70a3d70a3d70bp-2;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=1){
if(r.integer<31>()<=11886){
return 0x1.851eb851eb852p-1;
}else{
if(r.integer<0>()<=2470){
return 0x0.0p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}
}else{
if(r.integer<2>()<=404){
if(r.integer<46>()<=0){
if(r.integer<5>()<=471){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x1.47ae147ae147cp-2;
}
}
}
}else{
if(r.integer<19>()<=60){
if(r.integer<30>()<=28){
if(r.integer<20>()<=87){
if(r.integer<51>()<=-161){
if(r.integer<52>()<=56){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=7){
if(r.integer<20>()<=45){
return 0x1.47ae147ae147cp-3;
}else{
if(r.integer<20>()<=76){
if(r.integer<52>()<=50){
return 0x1.1eb851eb851ebp-2;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<46>()<=-1){
return 0x1.999999999999ap-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=-108){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=19){
if(r.integer<8>()<=-36){
if(r.integer<23>()<=15){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=3){
return 0x1.28f5c28f5c28fp+0;
}else{
return -0x1.eb851eb851ebap-4;
}
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<43>()<=1){
if(r.integer<0>()<=2454){
return 0x1.c28f5c28f5c2ap+0;
}else{
return 0x1.eb851eb851eb8p-1;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<19>()<=38){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x1.5c28f5c28f5c3p-1;
}
}
}
}
}
}else{
if(r.integer<50>()<=66){
if(r.integer<51>()<=-39){
if(r.integer<19>()<=78){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=87){
if(r.integer<19>()<=31){
if(r.integer<20>()<=49){
if(r.integer<8>()<=78){
if(r.integer<20>()<=47){
if(r.integer<20>()<=3){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<19>()<=5){
if(r.integer<39>()<=-7){
return 0x1.28f5c28f5c28fp+0;
}else{
if(r.integer<55>()<=6){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-2;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<18>()<=7){
return -0x1.68f5c28f5c290p+2;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
if(r.integer<29>()<=11){
return 0x1.47ae147ae147cp-1;
}else{
if(r.integer<30>()<=11){
return 0x1.1eb851eb851ebp-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<10>()<=55){
if(r.integer<3>()<=48){
return 0x1.eb851eb851eb8p-1;
}else{
if(r.integer<19>()<=24){
return 0x1.47ae147ae147cp-3;
}else{
if(r.integer<26>()<=185){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}
}else{
if(r.integer<29>()<=14){
if(r.integer<53>()<=97){
return 0x1.eb851eb851eb8p-1;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<43>()<=5){
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<50>()<=-84){
if(r.integer<8>()<=108){
return 0x0.0p+0;
}else{
if(r.integer<39>()<=-2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=79){
if(r.integer<43>()<=6){
if(r.integer<10>()<=53){
if(r.integer<53>()<=43){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<20>()<=16){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=115){
if(r.integer<30>()<=11){
return 0x1.70a3d70a3d70bp-2;
}else{
if(r.integer<6>()<=13){
return 0x1.70a3d70a3d70bp-2;
}else{
if(r.integer<19>()<=71){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=107){
return 0x0.0p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=48){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=39){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=90){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=54){
if(r.integer<0>()<=3111){
if(r.integer<38>()<=0){
return 0x1.999999999999ap-2;
}else{
return 0x1.0000000000000p+1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-58){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<52>()<=56){
if(r.integer<0>()<=5217){
if(r.integer<53>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=3752){
return 0x1.1eb851eb851ebp-2;
}else{
if(r.integer<5>()<=335){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<31>()<=11494){
if(r.integer<52>()<=46){
return -0x1.6666666666667p+1;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.9eb851eb851ecp+1;
}
}
}else{
if(r.integer<53>()<=14){
if(r.integer<28>()<=0){
return 0x1.6666666666667p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=4317){
if(r.integer<20>()<=38){
if(r.integer<30>()<=13){
if(r.integer<10>()<=29){
if(r.integer<19>()<=51){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+0;
}
}else{
if(r.integer<6>()<=279){
if(r.integer<8>()<=108){
return 0x1.3333333333334p+1;
}else{
if(r.integer<6>()<=271){
return 0x1.eb851eb851eb8p-4;
}else{
return 0x1.5c28f5c28f5c3p+1;
}
}
}else{
if(r.integer<8>()<=-38){
return 0x1.d70a3d70a3d70p-1;
}else{
if(r.integer<20>()<=23){
return -0x1.eb851eb851ebap-4;
}else{
return 0x1.1eb851eb851ebp-2;
}
}
}
}
}else{
if(r.integer<51>()<=-49){
if(r.integer<20>()<=19){
if(r.integer<43>()<=3){
return 0x1.3333333333334p+0;
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x1.47ae147ae147cp-2;
}
}else{
if(r.integer<19>()<=82){
if(r.integer<3>()<=21){
if(r.integer<19>()<=33){
return 0x1.3d70a3d70a3d8p+0;
}else{
return 0x1.47ae147ae147cp-2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3333333333334p-1;
}
}
}
}else{
if(r.integer<3>()<=50){
if(r.integer<19>()<=54){
if(r.integer<53>()<=105){
if(r.integer<20>()<=50){
if(r.integer<8>()<=15){
return 0x1.147ae147ae148p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<36>()<=18){
if(r.integer<1>()<=99){
return 0x1.8a3d70a3d70a4p+1;
}else{
return 0x1.47ae147ae147cp+0;
}
}else{
return 0x1.47ae147ae147ap-4;
}
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<51>()<=30){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=86){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=3059){
return 0x1.147ae147ae148p+0;
}else{
return 0x1.47ae147ae147ap-4;
}
}
}
}
}else{
if(r.integer<20>()<=54){
if(r.integer<51>()<=45){
return 0x1.47ae147ae147ap-4;
}else{
return 0x1.70a3d70a3d70bp-1;
}
}else{
if(r.integer<8>()<=42){
if(r.integer<20>()<=79){
return 0x0.0p+0;
}else{
if(r.integer<28>()<=0){
return 0x1.0a3d70a3d70a4p-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=73){
if(r.integer<25>()<=256){
return 0x1.47ae147ae147ap-4;
}else{
return -0x1.eb851eb851ebap-4;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<52>()<=72){
if(r.integer<31>()<=12945){
if(r.integer<20>()<=50){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-348){
return -0x1.199999999999ap+2;
}else{
if(r.integer<36>()<=0){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<31>()<=11205){
return 0x1.8000000000000p+1;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<10>()<=299){
if(r.integer<44>()<=13){
if(r.integer<53>()<=107){
if(r.integer<51>()<=-45){
if(r.integer<20>()<=46){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=3){
return -0x1.75c28f5c28f5cp+2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=-79){
return -0x1.999999999999ap-3;
}else{
if(r.integer<35>()<=4){
if(r.integer<20>()<=48){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=34){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=85){
return 0x1.0a3d70a3d70a4p-1;
}else{
if(r.integer<19>()<=49){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=53){
if(r.integer<9>()<=94){
return -0x1.0f5c28f5c28f6p+2;
}else{
if(r.integer<31>()<=16087){
return 0x0.0p+0;
}else{
return -0x1.2666666666667p+2;
}
}
}else{
if(r.integer<50>()<=96){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_2(const BudgetResidualFeatures&r){
if(r.integer<27>()<=0){
if(r.integer<3>()<=74){
if(r.integer<53>()<=107){
if(r.integer<44>()<=16){
if(r.integer<9>()<=39){
if(r.integer<1>()<=77){
if(r.integer<53>()<=59){
if(r.integer<0>()<=852){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=280){
if(r.integer<53>()<=97){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=85){
if(r.integer<5>()<=275){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<10>()<=45){
if(r.integer<52>()<=48){
return 0x0.0p+0;
}else{
if(r.integer<28>()<=0){
if(r.integer<4>()<=117){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=6901){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
if(r.integer<23>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=12273){
return 0x0.0p+0;
}else{
return 0x1.eb851eb851eb8p-4;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<52>()<=6){
if(r.integer<52>()<=1){
if(r.integer<5>()<=277){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=275){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=59){
if(r.integer<0>()<=966){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=89){
if(r.integer<5>()<=275){
if(r.integer<8>()<=45){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=52){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=6034){
if(r.integer<1>()<=75){
if(r.integer<43>()<=4){
if(r.integer<52>()<=28){
if(r.integer<36>()<=10){
if(r.integer<53>()<=176){
if(r.integer<31>()<=4121){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<31>()<=4634){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=114){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<36>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=66){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<36>()<=0){
if(r.integer<31>()<=10214){
if(r.integer<1>()<=75){
if(r.integer<52>()<=28){
if(r.integer<31>()<=7747){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7650){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=8149){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<35>()<=4){
if(r.integer<8>()<=105){
if(r.integer<35>()<=0){
if(r.integer<1>()<=32){
return -0x1.0000000000000p+0;
}else{
if(r.integer<1>()<=82){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=15){
if(r.integer<43>()<=2){
if(r.integer<38>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=65){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
return -0x1.0000000000000p+0;
}
}
}else{
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=1){
if(r.integer<33>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<43>()<=2){
if(r.integer<35>()<=1){
if(r.integer<52>()<=52){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=273){
if(r.integer<43>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=4292){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<1>()<=81){
if(r.integer<31>()<=8251){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=6){
if(r.integer<8>()<=108){
if(r.integer<50>()<=-40){
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
return -0x1.eb851eb851eb7p-3;
}
}
}else{
if(r.integer<8>()<=-102){
if(r.integer<50>()<=-11){
if(r.integer<43>()<=3){
return -0x1.eb851eb851eb8p-3;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.999999999999ap-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=50){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<35>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=111){
if(r.integer<43>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=1){
return -0x1.851eb851eb852p-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<35>()<=6){
if(r.integer<0>()<=3571){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=-42){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<23>()<=29){
if(r.integer<3>()<=88){
if(r.integer<9>()<=42){
if(r.integer<28>()<=0){
if(r.integer<46>()<=0){
if(r.integer<0>()<=532){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<31>()<=8670){
if(r.integer<50>()<=-3){
if(r.integer<3>()<=87){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=3294){
return -0x1.d17d2738e3c98p-4;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.3acb51e545ae1p+4;
}
}else{
if(r.integer<1>()<=93){
return -0x1.eb851eb851ebap-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<26>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=93){
if(r.integer<8>()<=-42){
if(r.integer<20>()<=87){
return 0x0.0p+0;
}else{
return 0x1.1fbe76c8b4395p+2;
}
}else{
if(r.integer<20>()<=61){
return 0x1.f5c28f5c28f5dp+2;
}else{
if(r.integer<0>()<=2028){
return 0x1.147ae147ae148p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-7){
return 0x1.c28f5c28f5c2ap+3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<19>()<=39){
if(r.integer<47>()<=-1){
if(r.integer<17>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=1268){
return 0x1.205c80322e30bp-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=21){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=3028){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5468){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<46>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=107){
if(r.integer<5>()<=307){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=7){
if(r.integer<1>()<=113){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=-36){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=7747){
if(r.integer<44>()<=16){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=271){
if(r.integer<8>()<=-257){
if(r.integer<35>()<=2){
return -0x1.3333333333334p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<7>()<=2){
if(r.integer<30>()<=2){
if(r.integer<50>()<=-2){
return 0x1.b333333333334p+1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=1){
if(r.integer<50>()<=3){
return 0x1.1db22d0e56042p+4;
}else{
return 0x1.0624dd2f1a9fep-2;
}
}else{
if(r.integer<1>()<=84){
return 0x1.0a7ef9db22d0fp+4;
}else{
return -0x1.23d70a3d70a3ep+1;
}
}
}
}else{
if(r.integer<1>()<=62){
if(r.integer<46>()<=-1){
if(r.integer<20>()<=90){
if(r.integer<8>()<=-22){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=61){
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
return 0x1.2e147ae147ae2p+2;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.0000000000000p+1;
}
}else{
if(r.integer<31>()<=8706){
if(r.integer<3>()<=79){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=149){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=8317){
if(r.integer<3>()<=78){
if(r.integer<4>()<=291){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=83){
if(r.integer<50>()<=6){
if(r.integer<3>()<=88){
if(r.integer<29>()<=0){
return 0x1.810624dd2f1aap-2;
}else{
if(r.integer<19>()<=43){
return 0x1.70a3d70a3d70bp-1;
}else{
return 0x1.24bc6a7ef9db2p+4;
}
}
}else{
if(r.integer<26>()<=194){
return -0x1.eb851eb851ebap-4;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
if(r.integer<6>()<=145){
if(r.integer<31>()<=4288){
if(r.integer<17>()<=6){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=86){
if(r.integer<19>()<=40){
if(r.integer<39>()<=0){
if(r.integer<51>()<=-33){
if(r.integer<0>()<=966){
return -0x1.c8e7a4459571fp-3;
}else{
if(r.integer<2>()<=132){
return -0x1.eb851eb851ebap-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.0a3d70a3d70a3p-1;
}
}else{
return 0x1.5c28f5c28f5c3p-1;
}
}else{
if(r.integer<3>()<=91){
if(r.integer<31>()<=5900){
if(r.integer<0>()<=1548){
return 0x1.3333333333334p+1;
}else{
return 0x1.2d0e560418937p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=24){
return 0x1.70a3d70a3d70bp-2;
}else{
if(r.integer<47>()<=-1){
if(r.integer<31>()<=6698){
return 0x1.6e147ae147ae2p+2;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<50>()<=18){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=7070){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.47ae147ae147cp-3;
}
}
}
}
}
}
}
}else{
if(r.integer<51>()<=-13){
return 0x1.0000000000000p+1;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<39>()<=-2){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=290){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<20>()<=52){
if(r.integer<52>()<=10){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=36){
if(r.integer<1>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-47){
if(r.integer<3>()<=105){
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.78d4fdf3b645bp-2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
if(r.integer<19>()<=64){
if(r.integer<0>()<=640){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=21){
return 0x1.5c2b5f6486be8p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=49){
if(r.integer<39>()<=-2){
if(r.integer<1>()<=65){
return 0x0.0p+0;
}else{
return 0x1.6147ae147ae15p+2;
}
}else{
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=34){
if(r.integer<28>()<=0){
if(r.integer<19>()<=14){
if(r.integer<36>()<=10){
if(r.integer<29>()<=9){
if(r.integer<6>()<=268){
return 0x1.3333333333334p-1;
}else{
if(r.integer<19>()<=5){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.7ae147ae147afp+0;
}
}
}else{
if(r.integer<46>()<=1){
if(r.integer<31>()<=5765){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
return -0x1.a9fbe76c8b43ap-4;
}
}
}else{
return 0x1.645a1cac08313p-1;
}
}
}else{
return -0x1.0624dd2f1a9fbp-6;
}
}else{
if(r.integer<20>()<=87){
if(r.integer<30>()<=9){
if(r.integer<47>()<=-1){
return 0x1.051eb851eb852p+3;
}else{
if(r.integer<20>()<=17){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=34){
return 0x1.c28f5c28f5c2ap+0;
}else{
return 0x1.47ae147ae147ap-3;
}
}
}
}else{
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-30){
return 0x1.999999999999ap+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=11){
return 0x1.5c28f5c28f5c3p+1;
}else{
if(r.integer<46>()<=1){
if(r.integer<46>()<=-1){
return 0x1.a8f5c28f5c290p+1;
}else{
return 0x1.70a3d70a3d70ap-2;
}
}else{
return 0x1.c624dd2f1a9fcp+2;
}
}
}
}
}
}else{
if(r.integer<20>()<=17){
if(r.integer<4>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-21){
if(r.integer<20>()<=2){
if(r.integer<14>()<=6){
return -0x1.374bc6a7ef9dcp-3;
}else{
return -0x1.3333333333334p+3;
}
}else{
if(r.integer<20>()<=12){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=18){
if(r.integer<53>()<=20){
return 0x0.0p+0;
}else{
if(r.integer<23>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8251){
return -0x1.89374bc6a7efap-6;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=62){
if(r.integer<8>()<=21){
if(r.integer<19>()<=49){
if(r.integer<20>()<=49){
if(r.integer<53>()<=20){
if(r.integer<20>()<=45){
if(r.integer<19>()<=44){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<25>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=4){
if(r.integer<29>()<=11){
return 0x1.0000000000000p+1;
}else{
if(r.integer<44>()<=10){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap+0;
}
}
}else{
if(r.integer<38>()<=1){
if(r.integer<24>()<=43){
if(r.integer<6>()<=130){
return 0x0.0p+0;
}else{
return 0x1.eb851eb851eb8p-2;
}
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}else{
if(r.integer<20>()<=35){
if(r.integer<3>()<=61){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=22){
return -0x1.242aab990f892p-8;
}else{
if(r.integer<3>()<=108){
return 0x1.604189374bc6bp+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}
}
}else{
if(r.integer<47>()<=0){
if(r.integer<51>()<=-13){
if(r.integer<31>()<=9581){
if(r.integer<30>()<=12){
if(r.integer<19>()<=75){
if(r.integer<30>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=2){
return 0x1.47ae147ae147cp-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<23>()<=44){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=57){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=9){
return 0x1.f8d4fdf3b645ap+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=25){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=31){
if(r.integer<0>()<=1384){
return 0x1.147ae147ae148p+1;
}else{
return 0x1.ced916872b020p-1;
}
}else{
return 0x1.a9fbe76c8b438p-3;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=10997){
if(r.integer<19>()<=51){
if(r.integer<29>()<=9){
if(r.integer<36>()<=18){
if(r.integer<38>()<=6){
if(r.integer<35>()<=1){
if(r.integer<44>()<=13){
if(r.integer<19>()<=7){
if(r.integer<51>()<=48){
if(r.integer<39>()<=-1){
return -0x1.70a3d70a3d70bp-2;
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
if(r.integer<50>()<=-21){
return 0x1.0000000000000p+0;
}else{
return 0x1.6872b020c49c0p-4;
}
}
}else{
if(r.integer<8>()<=42){
if(r.integer<19>()<=14){
if(r.integer<53>()<=38){
return -0x1.eb851eb851eb8p-3;
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<6>()<=368){
if(r.integer<43>()<=4){
if(r.integer<54>()<=6){
return 0x1.999999999999ap-1;
}else{
if(r.integer<5>()<=483){
return 0x1.cac083126e980p-5;
}else{
return 0x1.1eb851eb851ebp+1;
}
}
}else{
if(r.integer<5>()<=367){
return 0x1.5c28f5c28f5c3p+1;
}else{
return 0x1.c28f5c28f5c2ap-1;
}
}
}else{
return 0x1.999999999999ap+0;
}
}
}else{
if(r.integer<39>()<=-2){
return 0x1.851eb851eb852p+1;
}else{
if(r.integer<19>()<=33){
if(r.integer<50>()<=-28){
if(r.integer<10>()<=55){
return 0x1.916872b020c4ap+0;
}else{
return 0x1.5c28f5c28f5c2p-1;
}
}else{
if(r.integer<20>()<=81){
return 0x1.1eb851eb851ebp-2;
}else{
return -0x1.eb851eb851ebap-4;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x1.6666666666667p+0;
}
}else{
if(r.integer<38>()<=1){
if(r.integer<39>()<=7){
if(r.integer<5>()<=137){
if(r.integer<1>()<=90){
if(r.integer<5>()<=49){
if(r.integer<1>()<=73){
return 0x1.c28f5c28f5c2ap-1;
}else{
if(r.integer<5>()<=18){
if(r.integer<2>()<=341){
return -0x1.604189374bc6cp-2;
}else{
return 0x1.1eb851eb851ebp+0;
}
}else{
if(r.integer<19>()<=44){
return 0x1.03d70a3d70a3ep+3;
}else{
return 0x1.47ae147ae147ap-3;
}
}
}
}else{
if(r.integer<1>()<=89){
if(r.integer<8>()<=-73){
return 0x1.16872b020c49bp+1;
}else{
return 0x1.3b645a1cac084p-1;
}
}else{
return -0x1.0a3d70a3d70a4p-1;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<51>()<=126){
if(r.integer<19>()<=4){
return 0x1.8f5c28f5c28f6p+0;
}else{
return 0x1.116872b020c4ap+1;
}
}else{
if(r.integer<19>()<=29){
return 0x1.23d70a3d70a3ep+1;
}else{
return 0x1.eb851eb851eb4p-4;
}
}
}else{
if(r.integer<39>()<=0){
if(r.integer<1>()<=94){
return 0x1.0f5c28f5c28f6p+1;
}else{
return 0x1.851eb851eb852p-1;
}
}else{
if(r.integer<1>()<=91){
return 0x1.87ae147ae147cp+2;
}else{
return 0x1.47ae147ae147bp-2;
}
}
}
}
}else{
if(r.integer<19>()<=13){
if(r.integer<5>()<=274){
if(r.integer<53>()<=45){
return -0x1.8b758ff8eaecbp-5;
}else{
return 0x1.8000000000000p+1;
}
}else{
if(r.integer<8>()<=21){
return -0x1.0e5604189374bp-2;
}else{
return 0x1.1eb851eb851ebp+0;
}
}
}else{
if(r.integer<29>()<=2){
return 0x1.deb851eb851ecp+2;
}else{
return 0x1.0a3d70a3d70a4p+1;
}
}
}
}else{
if(r.integer<8>()<=63){
return 0x1.8f5c28f5c28f6p+0;
}else{
return -0x1.374bc6a7ef9ddp-3;
}
}
}else{
if(r.integer<8>()<=36){
if(r.integer<29>()<=1){
if(r.integer<7>()<=15){
return 0x1.eb851eb851eb8p-1;
}else{
return -0x1.0a3d70a3d70a4p-1;
}
}else{
return 0x1.3d70a3d70a3d7p+0;
}
}else{
if(r.integer<19>()<=36){
return 0x1.89374bc6a7efap-4;
}else{
return -0x1.eb851eb851eb8p-3;
}
}
}
}
}else{
if(r.integer<3>()<=100){
return 0x0.0p+0;
}else{
return -0x1.89374bc6a7efap-5;
}
}
}else{
if(r.integer<7>()<=19){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
if(r.integer<20>()<=41){
if(r.integer<30>()<=9){
if(r.integer<51>()<=-68){
if(r.integer<47>()<=0){
if(r.integer<47>()<=-1){
return 0x1.eb851eb851eb7p-3;
}else{
if(r.integer<50>()<=-40){
return 0x1.3b645a1cac084p-1;
}else{
if(r.integer<35>()<=4){
if(r.integer<46>()<=-1){
return 0x1.ba5e353f7ced8p-3;
}else{
return 0x1.2b020c49ba5e3p+0;
}
}else{
return 0x1.6c8b439581063p+0;
}
}
}
}else{
return 0x1.2189374bc6a7fp+3;
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<8>()<=48){
return 0x0.0p+0;
}else{
return 0x1.05a1cac083127p+3;
}
}else{
if(r.integer<20>()<=14){
if(r.integer<55>()<=9){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<43>()<=1){
return 0x1.70a3d70a3d70bp-1;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
if(r.integer<44>()<=2){
return 0x1.26e978d4fdf3bp-2;
}else{
return 0x1.89374bc6a7ef4p-6;
}
}
}
}
}else{
if(r.integer<51>()<=-80){
if(r.integer<19>()<=18){
return 0x1.eb851eb851eb8p-4;
}else{
if(r.integer<20>()<=20){
return 0x1.5c28f5c28f5c3p-1;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<29>()<=15){
if(r.integer<55>()<=3){
return 0x1.a9fbe76c8b43ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=55){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=6){
return -0x1.db22d0e56041ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<30>()<=15){
if(r.integer<20>()<=49){
if(r.integer<53>()<=47){
return -0x1.eb851eb851ebap-4;
}else{
if(r.integer<30>()<=10){
if(r.integer<46>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.645a1cac08312p-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=49){
if(r.integer<26>()<=81){
if(r.integer<25>()<=26){
if(r.integer<17>()<=3){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
if(r.integer<19>()<=3){
return -0x1.6872b020c49bbp-3;
}else{
if(r.integer<20>()<=61){
return 0x1.395810624dd30p+0;
}else{
if(r.integer<33>()<=3){
return 0x1.1eb851eb851ebp-2;
}else{
if(r.integer<38>()<=0){
return 0x1.89374bc6a7efap-6;
}else{
return -0x1.26e978d4fdf3cp-4;
}
}
}
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<31>()<=4669){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<26>()<=52){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<0>()<=1421){
return 0x1.5c28f5c28f5c3p-1;
}else{
if(r.integer<43>()<=4){
if(r.integer<20>()<=91){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=60){
return 0x1.020c49ba5e354p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<8>()<=-68){
if(r.integer<7>()<=-40){
return -0x1.89374bc6a7efap-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-56){
return 0x1.cac083126e978p-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=101){
if(r.integer<3>()<=47){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=95){
if(r.integer<30>()<=14){
if(r.integer<20>()<=49){
if(r.integer<31>()<=3443){
if(r.integer<6>()<=362){
if(r.integer<20>()<=18){
return -0x1.eb851eb851ebap-4;
}else{
if(r.integer<4>()<=337){
return -0x1.eb851eb851ebap-4;
}else{
return 0x1.eb851eb851eb8p-2;
}
}
}else{
return 0x1.1eb851eb851ebp-2;
}
}else{
if(r.integer<30>()<=3){
if(r.integer<44>()<=16){
if(r.integer<32>()<=3){
if(r.integer<43>()<=5){
return 0x1.6872b020c49bap-1;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<2>()<=93){
if(r.integer<44>()<=1){
return 0x1.6872b020c49bap-1;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x1.189374bc6a7efp+0;
}
}
}else{
return 0x1.54fdf3b645a1dp+3;
}
}else{
if(r.integer<8>()<=-32){
if(r.integer<19>()<=77){
if(r.integer<33>()<=10){
if(r.integer<52>()<=30){
return 0x1.999999999999ap-1;
}else{
return 0x1.ced916872b020p+0;
}
}else{
return 0x1.020c49ba5e354p-1;
}
}else{
if(r.integer<0>()<=1439){
if(r.integer<26>()<=130){
return 0x0.0p+0;
}else{
return -0x1.eb851eb851ebap-4;
}
}else{
if(r.integer<47>()<=0){
if(r.integer<43>()<=5){
if(r.integer<1>()<=48){
if(r.integer<20>()<=37){
return 0x1.5810624dd2f1bp+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.26e978d4fdf3ap-3;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<30>()<=9){
return 0x1.8d4fdf3b645a2p+2;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}
}
}else{
if(r.integer<20>()<=12){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<19>()<=86){
if(r.integer<43>()<=5){
if(r.integer<43>()<=0){
return 0x1.47ae147ae147cp-3;
}else{
if(r.integer<47>()<=0){
return 0x1.1a9fbe76c8b43p+0;
}else{
if(r.integer<4>()<=339){
return 0x1.78d4fdf3b645bp-2;
}else{
return -0x1.eb851eb851ebap-4;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.7ef9db22d0e56p+0;
}
}
}
}
}
}else{
if(r.integer<10>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=39){
if(r.integer<53>()<=65){
return 0x1.1eb851eb851ebp+0;
}else{
return 0x1.26e978d4fdf3bp-2;
}
}else{
if(r.integer<20>()<=92){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}
}
}else{
if(r.integer<44>()<=7){
if(r.integer<29>()<=16){
if(r.integer<20>()<=49){
if(r.integer<0>()<=1851){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=59){
return 0x0.0p+0;
}else{
return -0x1.89374bc6a7efap-6;
}
}
}else{
if(r.integer<19>()<=87){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-24){
return 0x0.0p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}
}
}else{
if(r.integer<43>()<=5){
return 0x1.47ae147ae147cp-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=12){
if(r.integer<44>()<=16){
if(r.integer<43>()<=5){
if(r.integer<4>()<=137){
if(r.integer<3>()<=72){
if(r.integer<35>()<=4){
return -0x1.89374bc6a7ef4p-6;
}else{
return 0x1.ae147ae147ae2p-1;
}
}else{
if(r.integer<20>()<=37){
if(r.integer<5>()<=439){
if(r.integer<35>()<=3){
return 0x1.0a3d70a3d70a4p-1;
}else{
return 0x1.978d4fdf3b646p+0;
}
}else{
return 0x1.db22d0e560418p+0;
}
}else{
return 0x1.cac083126e97ap-4;
}
}
}else{
if(r.integer<47>()<=0){
if(r.integer<4>()<=146){
if(r.integer<7>()<=-20){
return -0x1.ba5e353f7cedap-3;
}else{
return 0x1.47ae147ae147ap-4;
}
}else{
return 0x1.5810624dd2f1bp-2;
}
}else{
if(r.integer<8>()<=81){
return 0x1.4083126e978d5p+1;
}else{
if(r.integer<20>()<=13){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<3>()<=70){
return 0x1.c28f5c28f5c2ap-2;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}
}
}else{
if(r.integer<6>()<=30){
return 0x1.1eb851eb851ebp-2;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
if(r.integer<30>()<=1){
if(r.integer<6>()<=279){
return 0x1.d26e978d4fdf4p+3;
}else{
return -0x1.a9fbe76c8b43ap-4;
}
}else{
if(r.integer<31>()<=4813){
return 0x1.e76c8b4395810p+2;
}else{
return 0x1.6a7ef9db22d0fp+0;
}
}
}
}else{
if(r.integer<25>()<=80){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=84){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=105){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=73){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}
}
}
}else{
if(r.integer<52>()<=39){
if(r.integer<6>()<=36){
if(r.integer<43>()<=5){
if(r.integer<14>()<=4){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<6>()<=12){
return 0x1.1eb851eb851ebp-1;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=18){
return 0x1.70a3d70a3d70bp-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=141){
if(r.integer<20>()<=74){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=92){
if(r.integer<19>()<=84){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<53>()<=105){
if(r.integer<44>()<=13){
if(r.integer<3>()<=15){
if(r.integer<19>()<=45){
if(r.integer<31>()<=14298){
return 0x1.74bc6a7ef9db3p-1;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
return 0x1.6872b020c49bap-4;
}
}else{
if(r.integer<43>()<=3){
if(r.integer<19>()<=69){
if(r.integer<8>()<=24){
if(r.integer<20>()<=41){
if(r.integer<1>()<=44){
if(r.integer<19>()<=50){
if(r.integer<19>()<=22){
return 0x1.4bc6a7ef9db24p-1;
}else{
return 0x1.0624dd2f1aa00p-7;
}
}else{
return 0x1.3f7ced916872cp+0;
}
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<20>()<=76){
if(r.integer<24>()<=18){
return -0x1.0624dd2f1a9fcp-5;
}else{
return 0x1.5810624dd2f1bp-3;
}
}else{
if(r.integer<52>()<=68){
return 0x1.eb851eb851eb8p-1;
}else{
return 0x1.4fdf3b645a1cbp-2;
}
}
}
}else{
if(r.integer<19>()<=32){
if(r.integer<3>()<=46){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x1.604189374bc6bp-1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=77){
return -0x1.0624dd2f1a9fcp-5;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=-95){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<3>()<=34){
if(r.integer<8>()<=33){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}else{
if(r.integer<20>()<=52){
if(r.integer<30>()<=9){
return 0x1.010624dd2f1aap+1;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}else{
if(r.integer<1>()<=43){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}
}
}
}else{
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=33){
if(r.integer<19>()<=39){
return 0x1.147ae147ae148p+0;
}else{
return 0x1.a9fbe76c8b43ap-2;
}
}else{
if(r.integer<8>()<=-42){
if(r.integer<20>()<=24){
return 0x1.c28f5c28f5c2ap-1;
}else{
if(r.integer<9>()<=68){
return 0x1.eb851eb851eb8p-2;
}else{
return 0x1.ba5e353f7ced8p-3;
}
}
}else{
if(r.integer<20>()<=88){
if(r.integer<20>()<=16){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=59){
if(r.integer<1>()<=23){
return 0x1.a1cac083126eap-1;
}else{
if(r.integer<19>()<=3){
return -0x1.ba5e353f7cedap-3;
}else{
return 0x1.b22d0e560418ap-2;
}
}
}else{
if(r.integer<1>()<=94){
return 0x0.0p+0;
}else{
return 0x1.3f7ced916872bp-1;
}
}
}
}else{
if(r.integer<14>()<=4){
return 0x1.cac083126e977p-3;
}else{
return -0x1.eb851eb851ebap-4;
}
}
}
}
}
}else{
if(r.integer<20>()<=48){
if(r.integer<19>()<=51){
if(r.integer<1>()<=103){
if(r.integer<31>()<=15121){
if(r.integer<23>()<=24){
if(r.integer<30>()<=7){
return 0x1.147ae147ae148p+0;
}else{
return 0x1.26e978d4fdf3bp-2;
}
}else{
return 0x1.0624dd2f1aa00p-7;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=117){
return 0x1.47ae147ae147cp-5;
}else{
if(r.integer<43>()<=3){
if(r.integer<6>()<=410){
return 0x1.0624dd2f1aa00p-7;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}else{
if(r.integer<50>()<=63){
if(r.integer<43>()<=4){
if(r.integer<35>()<=4){
if(r.integer<35>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<23>()<=44){
return 0x1.999999999999ap-2;
}else{
return -0x1.47ae147ae147cp-2;
}
}
}
}else{
if(r.integer<7>()<=-80){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<46>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=351){
if(r.integer<35>()<=5){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-137){
return 0x1.f3b645a1cac08p-2;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=14167){
if(r.integer<19>()<=50){
if(r.integer<1>()<=107){
if(r.integer<43>()<=5){
if(r.integer<30>()<=4){
return -0x1.89374bc6a7efap-6;
}else{
if(r.integer<43>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-82){
if(r.integer<51>()<=-211){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=58){
return 0x0.0p+0;
}else{
return -0x1.ccccccccccccdp+0;
}
}
}
}else{
if(r.integer<7>()<=-95){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=69){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_3(const BudgetResidualFeatures&r){
if(r.integer<1>()<=75){
if(r.integer<3>()<=75){
if(r.integer<53>()<=101){
if(r.integer<44>()<=16){
if(r.integer<52>()<=39){
if(r.integer<53>()<=61){
if(r.integer<52>()<=9){
if(r.integer<51>()<=-39){
if(r.integer<5>()<=483){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=4164){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=0){
if(r.integer<1>()<=33){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=286){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=35){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
if(r.integer<7>()<=-50){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=13299){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-1;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=6){
if(r.integer<52>()<=1){
if(r.integer<5>()<=277){
if(r.integer<1>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=284){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=59){
if(r.integer<0>()<=911){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=280){
if(r.integer<4>()<=93){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=7104){
if(r.integer<43>()<=4){
if(r.integer<52>()<=28){
if(r.integer<31>()<=5666){
if(r.integer<36>()<=10){
if(r.integer<44>()<=16){
if(r.integer<10>()<=174){
if(r.integer<31>()<=4121){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-110){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=373){
if(r.integer<8>()<=-108){
if(r.integer<47>()<=7){
if(r.integer<52>()<=15){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=5732){
if(r.integer<36>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=39){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<8>()<=-377){
if(r.integer<42>()<=128){
if(r.integer<35>()<=3){
if(r.integer<5>()<=362){
if(r.integer<31>()<=8424){
return -0x1.a3d70a3d70a3dp+0;
}else{
return -0x1.c28f5c28f5c2ap+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return -0x1.ae147ae147ae0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=4){
if(r.integer<5>()<=152){
if(r.integer<8>()<=-105){
if(r.integer<35>()<=0){
return -0x1.999999999999ap-2;
}else{
if(r.integer<7>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=10006){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<35>()<=1){
if(r.integer<43>()<=1){
if(r.integer<31>()<=9453){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=258){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=9955){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=434){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=39){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<8>()<=-38){
if(r.integer<20>()<=29){
if(r.integer<47>()<=-1){
if(r.integer<43>()<=5){
if(r.integer<6>()<=276){
if(r.integer<20>()<=24){
if(r.integer<6>()<=44){
if(r.integer<50>()<=27){
return -0x1.d14e3bcd35a87p-3;
}else{
if(r.integer<0>()<=1583){
return 0x1.97f62b6ae7d57p-2;
}else{
return 0x1.d7dbf487fcb94p-3;
}
}
}else{
return 0x1.7ced916872b02p-1;
}
}else{
return -0x1.205bc01a36e33p-6;
}
}else{
return -0x1.bda5119ce0760p-3;
}
}else{
if(r.integer<43>()<=6){
if(r.integer<19>()<=71){
if(r.integer<19>()<=4){
return -0x1.07c84b5dcc63fp-2;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.0624dd2f1a9fdp-4;
}
}else{
return 0x1.6872b020c49bbp-3;
}
}
}else{
if(r.integer<3>()<=103){
if(r.integer<46>()<=-1){
if(r.integer<43>()<=4){
if(r.integer<51>()<=-78){
return 0x1.8adab9f559b3dp-1;
}else{
return 0x1.b9f559b3d07c8p+0;
}
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
if(r.integer<44>()<=16){
if(r.integer<5>()<=351){
if(r.integer<35>()<=2){
if(r.integer<0>()<=3163){
if(r.integer<1>()<=18){
return 0x1.03126e978d4fep+1;
}else{
return 0x1.df3b645a1cac0p-1;
}
}else{
return 0x1.7c1bda5119ce7p-5;
}
}else{
if(r.integer<53>()<=47){
return 0x1.0624dd2f1a9fdp-6;
}else{
if(r.integer<50>()<=19){
return -0x1.26e978d4fdf3dp-4;
}else{
if(r.integer<6>()<=454){
return 0x1.9c779a6b50b10p+0;
}else{
return 0x1.5a858793dd97fp-1;
}
}
}
}
}else{
return 0x1.9930be0ded289p+0;
}
}else{
return 0x1.2bb98c7e28241p+3;
}
}
}else{
if(r.integer<35>()<=2){
if(r.integer<5>()<=345){
if(r.integer<10>()<=133){
return 0x1.d7dbf487fcb94p-3;
}else{
if(r.integer<43>()<=4){
if(r.integer<6>()<=420){
return -0x1.0a3d70a3d70a5p-1;
}else{
return 0x1.6872b020c49bcp-4;
}
}else{
return 0x1.bda5119ce075dp-5;
}
}
}else{
if(r.integer<20>()<=24){
if(r.integer<0>()<=2060){
return -0x1.0624dd2f1aa33p-7;
}else{
return 0x1.32617c1bda512p-1;
}
}else{
return 0x1.ff2e48e8a71e0p-5;
}
}
}else{
if(r.integer<46>()<=-1){
return 0x1.47ae147ae147ap-3;
}else{
return 0x1.15b573eab367ap-1;
}
}
}
}
}else{
if(r.integer<20>()<=85){
if(r.integer<1>()<=70){
if(r.integer<20>()<=36){
if(r.integer<47>()<=-1){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<3>()<=101){
if(r.integer<46>()<=-1){
return 0x1.d7dbf487fcb9ap-6;
}else{
return 0x1.23a29c779a6b5p+0;
}
}else{
if(r.integer<44>()<=2){
return 0x1.6872b020c49bap-3;
}else{
return -0x1.0624dd2f1aa00p-6;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<20>()<=75){
if(r.integer<6>()<=420){
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-105){
if(r.integer<35>()<=6){
if(r.integer<35>()<=4){
if(r.integer<5>()<=257){
if(r.integer<35>()<=0){
return -0x1.3333333333334p+1;
}else{
return -0x1.82a9930be0deep-2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=30){
return 0x1.999999999999ap-3;
}else{
return -0x1.70a3d70a3d70cp+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=47){
return 0x1.1eb851eb851ebp-2;
}else{
if(r.integer<8>()<=-129){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=-110){
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return -0x1.0624dd2f1a9fdp-5;
}
}else{
if(r.integer<55>()<=0){
return -0x1.0624dd2f1a9fcp-5;
}else{
if(r.integer<13>()<=7){
return 0x1.ff2e48e8a71ddp-5;
}else{
return 0x1.4fdf3b645a1cbp-2;
}
}
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<10>()<=71){
if(r.integer<55>()<=9){
if(r.integer<35>()<=4){
if(r.integer<19>()<=23){
if(r.integer<20>()<=50){
return 0x1.0be0ded288ce7p-1;
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
if(r.integer<25>()<=218){
return 0x0.0p+0;
}else{
return 0x1.a43fe5c91d14fp-1;
}
}
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
return 0x1.1eb851eb851ebp-2;
}
}else{
if(r.integer<19>()<=68){
if(r.integer<19>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=45){
if(r.integer<6>()<=276){
return 0x1.89374bc6a7efap-1;
}else{
return -0x1.16872b020c49cp-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=93){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=54){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<33>()<=5){
if(r.integer<3>()<=95){
if(r.integer<19>()<=15){
return -0x1.89374bc6a7efap-3;
}else{
if(r.integer<38>()<=0){
if(r.integer<5>()<=33){
return 0x1.6d916872b020cp+1;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return 0x1.f727fe5a832c5p+0;
}
}
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<0>()<=993){
return -0x1.9023977734080p-3;
}else{
if(r.integer<19>()<=3){
return -0x1.a9fbe76c8b43ap-4;
}else{
if(r.integer<19>()<=62){
if(r.integer<19>()<=21){
if(r.integer<36>()<=10){
return 0x1.c6a7ef9db22d0p+0;
}else{
return -0x1.c432ca57a786dp-4;
}
}else{
return 0x1.51eb851eb851fp+1;
}
}else{
if(r.integer<47>()<=1){
return 0x1.89374bc6a7efcp-6;
}else{
return 0x1.5c28f5c28f5c3p+1;
}
}
}
}
}
}
}else{
if(r.integer<46>()<=-1){
if(r.integer<10>()<=97){
return 0x1.0f5c28f5c28f6p+2;
}else{
if(r.integer<31>()<=11131){
if(r.integer<38>()<=6){
return 0x1.e978d4fdf3b64p+0;
}else{
return -0x1.89374bc6a7f34p-5;
}
}else{
return 0x1.eb851eb851eb8p-3;
}
}
}else{
if(r.integer<47>()<=0){
if(r.integer<1>()<=64){
if(r.integer<8>()<=-50){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<0>()<=1494){
if(r.integer<3>()<=90){
return 0x1.ccccccccccccdp+0;
}else{
return 0x1.b645a1cac0832p+1;
}
}else{
if(r.integer<19>()<=61){
return 0x1.47ae147ae147cp+0;
}else{
return 0x1.eb851eb851eb8p-4;
}
}
}
}else{
if(r.integer<3>()<=85){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=39){
return 0x1.013a92a305532p-1;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<44>()<=17){
if(r.integer<20>()<=13){
if(r.integer<47>()<=-1){
if(r.integer<3>()<=97){
if(r.integer<8>()<=33){
return 0x0.0p+0;
}else{
return 0x1.c8b4395810625p+1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=76){
if(r.integer<19>()<=39){
if(r.integer<51>()<=-19){
if(r.integer<20>()<=1){
return -0x1.ec226809d4952p+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=72){
return -0x1.89374bc6a7f00p-6;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=64){
if(r.integer<8>()<=24){
if(r.integer<19>()<=49){
if(r.integer<8>()<=-24){
return -0x1.89374bc6a7efap-6;
}else{
if(r.integer<20>()<=49){
if(r.integer<20>()<=45){
if(r.integer<19>()<=2){
return -0x1.758e219652bd4p-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<25>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=6){
if(r.integer<46>()<=-1){
return 0x1.d3f7ced916874p+1;
}else{
if(r.integer<7>()<=31){
if(r.integer<14>()<=5){
return 0x1.1ccb7547b69eep+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=8895){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=35){
if(r.integer<39>()<=-2){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<3>()<=99){
if(r.integer<43>()<=4){
return 0x1.401a36e2eb1c4p+1;
}else{
return 0x1.e4f765fd8adadp-5;
}
}else{
return 0x1.cac083126e97ap-2;
}
}
}else{
if(r.integer<50>()<=42){
if(r.integer<8>()<=-24){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<43>()<=2){
if(r.integer<3>()<=100){
if(r.integer<47>()<=0){
return 0x1.999999999999ap-3;
}else{
if(r.integer<20>()<=47){
return -0x1.5b573eab367a1p-4;
}else{
return 0x1.eb851eb851eb8p-4;
}
}
}else{
if(r.integer<19>()<=83){
if(r.integer<38>()<=6){
if(r.integer<20>()<=50){
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=59){
if(r.integer<51>()<=36){
return 0x0.0p+0;
}else{
return 0x1.851eb851eb852p-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=64){
return 0x0.0p+0;
}else{
return -0x1.205bc01a36e2fp-4;
}
}
}else{
if(r.integer<10>()<=79){
if(r.integer<38>()<=-1){
return 0x1.147ae147ae148p+0;
}else{
if(r.integer<6>()<=39){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.22d0e56041893p-1;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=3474){
if(r.integer<19>()<=79){
if(r.integer<3>()<=90){
return 0x1.1eb851eb851ebp-1;
}else{
if(r.integer<51>()<=48){
if(r.integer<20>()<=49){
if(r.integer<20>()<=44){
return 0x0.0p+0;
}else{
return -0x1.3333333333334p+0;
}
}else{
if(r.integer<5>()<=36){
return 0x1.652bd3c361134p+0;
}else{
if(r.integer<23>()<=51){
if(r.integer<16>()<=6){
return 0x1.14e3bcd35a858p-1;
}else{
return -0x1.374bc6a7ef9dcp-3;
}
}else{
return 0x1.87fcb923a29c8p+0;
}
}
}
}else{
return 0x1.2a305532617c2p-2;
}
}
}else{
if(r.integer<10>()<=65){
return 0x1.eb851eb851eb8p-1;
}else{
return 0x1.5810624dd2f1bp-2;
}
}
}else{
if(r.integer<35>()<=2){
if(r.integer<53>()<=234){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<46>()<=-1){
if(r.integer<3>()<=99){
return -0x1.6872b020c49bbp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=18){
return 0x1.3a92a30553262p-8;
}else{
if(r.integer<19>()<=86){
if(r.integer<51>()<=81){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.0624dd2f1a9fdp-6;
}
}
}
}else{
if(r.integer<0>()<=1618){
return 0x1.1eb851eb851ebp+0;
}else{
if(r.integer<19>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<3>()<=89){
if(r.integer<7>()<=7){
if(r.integer<19>()<=11){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=51){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8781){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=22){
if(r.integer<1>()<=58){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=477){
if(r.integer<10>()<=73){
if(r.integer<19>()<=1){
return -0x1.0624dd2f1a9fcp-5;
}else{
if(r.integer<3>()<=92){
return 0x1.0000000000000p+0;
}else{
if(r.integer<51>()<=60){
if(r.integer<33>()<=5){
if(r.integer<16>()<=4){
return -0x1.eb851eb851ebap-4;
}else{
return 0x1.eb87f29b22e08p-8;
}
}else{
if(r.integer<1>()<=67){
return 0x1.89374bc6a7ef4p-6;
}else{
return 0x1.b4395810624ddp+0;
}
}
}else{
if(r.integer<36>()<=5){
return 0x1.28f5c28f5c28fp+0;
}else{
return 0x1.6872b020c49bap-2;
}
}
}
}
}else{
return 0x1.de69ad42c3c9dp-4;
}
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
if(r.integer<8>()<=-34){
return 0x1.5c28f5c28f5c3p-1;
}else{
if(r.integer<43>()<=5){
if(r.integer<10>()<=37){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=51){
if(r.integer<39>()<=-1){
if(r.integer<7>()<=32){
return 0x1.5c28f5c28f5c3p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<55>()<=9){
if(r.integer<7>()<=34){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=91){
if(r.integer<1>()<=48){
if(r.integer<51>()<=39){
return 0x1.a36e2eb1c432dp-8;
}else{
return -0x1.a36e2eb1c432dp-6;
}
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=2923){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<20>()<=61){
if(r.integer<3>()<=93){
if(r.integer<8>()<=21){
if(r.integer<51>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=41){
return 0x0.0p+0;
}else{
return 0x1.4b294eb10865ap+3;
}
}
}else{
if(r.integer<20>()<=51){
if(r.integer<6>()<=279){
return 0x1.7ac710cb295eap+3;
}else{
if(r.integer<20>()<=49){
return -0x1.fbe76c8b4395ap-3;
}else{
return 0x1.87ef9db22d0e5p+4;
}
}
}else{
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x1.74395810624ddp+2;
}
}
}
}else{
if(r.integer<51>()<=33){
if(r.integer<20>()<=49){
if(r.integer<20>()<=40){
if(r.integer<19>()<=82){
if(r.integer<19>()<=64){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return 0x1.7ae147ae147afp+0;
}
}else{
return -0x1.0624dd2f1a9fbp-7;
}
}else{
if(r.integer<19>()<=51){
return 0x1.8d013a92a3056p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=285){
if(r.integer<0>()<=3771){
if(r.integer<3>()<=104){
return 0x1.41205bc01a36fp+0;
}else{
if(r.integer<20>()<=40){
return 0x1.eb851eb851eb8p-4;
}else{
return 0x1.2b020c49ba5e3p-1;
}
}
}else{
if(r.integer<6>()<=278){
return 0x1.70a3d70a3d70bp-2;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
if(r.integer<20>()<=49){
return -0x1.0624dd2f1a9fcp-3;
}else{
return 0x1.999999999999ap-2;
}
}
}
}
}else{
if(r.integer<19>()<=26){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=314){
return 0x1.6f0068db8bac8p-7;
}else{
return 0x1.5a1cac083126fp+0;
}
}
}else{
if(r.integer<50>()<=60){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<24>()<=31){
if(r.integer<53>()<=105){
if(r.integer<44>()<=13){
if(r.integer<31>()<=8251){
if(r.integer<50>()<=-4){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=-1){
if(r.integer<1>()<=92){
if(r.integer<53>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=41){
if(r.integer<53>()<=24){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=101){
if(r.integer<36>()<=10){
if(r.integer<20>()<=49){
return 0x1.97f62b6ae7d55p-2;
}else{
return 0x1.9930be0ded288p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=50){
if(r.integer<10>()<=85){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<43>()<=2){
return 0x1.a858793dd97f7p-2;
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
return 0x1.89374bc6a7efap-1;
}
}
}
}
}else{
if(r.integer<8>()<=69){
if(r.integer<28>()<=0){
if(r.integer<19>()<=50){
if(r.integer<20>()<=48){
return 0x1.a36e2eb1c432dp-8;
}else{
return 0x1.2d0e560418937p+0;
}
}else{
if(r.integer<19>()<=85){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=77){
if(r.integer<20>()<=38){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=59){
return 0x1.999999999999ap-1;
}else{
return 0x1.0624dd2f1a9fbp-3;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<55>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=85){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=25){
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x1.15b573eab367ap-1;
}
}else{
return 0x1.cac083126e97ap-2;
}
}
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<50>()<=-70){
if(r.integer<19>()<=95){
if(r.integer<19>()<=48){
return 0x1.e9e1b089a0275p-1;
}else{
return 0x1.930be0ded288dp-3;
}
}else{
return 0x1.98c7e28240b78p+0;
}
}else{
if(r.integer<6>()<=279){
if(r.integer<5>()<=307){
if(r.integer<50>()<=27){
if(r.integer<9>()<=8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<31>()<=4955){
if(r.integer<1>()<=91){
return 0x1.a8f5c28f5c290p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=59){
if(r.integer<19>()<=41){
if(r.integer<0>()<=591){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=46){
if(r.integer<0>()<=1818){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=1687){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=2332){
return 0x1.0e3bcd35a8587p+2;
}else{
return 0x1.0c49ba5e353f8p+0;
}
}
}
}
}else{
if(r.integer<20>()<=48){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=4634){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1248){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<1>()<=100){
if(r.integer<27>()<=0){
if(r.integer<31>()<=7817){
if(r.integer<1>()<=89){
if(r.integer<36>()<=9){
if(r.integer<44>()<=18){
if(r.integer<43>()<=5){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5934){
return 0x1.18d4fdf3b645ap+3;
}else{
return 0x1.4fdf3b645a1cbp-2;
}
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<38>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<36>()<=18){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<9>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=28){
if(r.integer<50>()<=-70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=9674){
if(r.integer<2>()<=476){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}else{
return -0x1.26e978d4fdf3cp-4;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}else{
if(r.integer<19>()<=47){
if(r.integer<38>()<=-2){
return -0x1.16872b020c49bp-3;
}else{
if(r.integer<5>()<=155){
if(r.integer<1>()<=92){
if(r.integer<38>()<=1){
return 0x1.e24dd2f1a9fbfp+1;
}else{
return 0x1.89374bc6a7ef4p-5;
}
}else{
if(r.integer<39>()<=1){
return 0x1.2a305532617c2p-1;
}else{
return 0x1.5a1cac083126fp+1;
}
}
}else{
if(r.integer<5>()<=271){
return -0x1.47ae147ae147ap-4;
}else{
if(r.integer<5>()<=383){
return 0x1.020c49ba5e354p+0;
}else{
if(r.integer<5>()<=411){
return -0x1.999999999999ap-3;
}else{
return 0x1.f3b645a1cac08p-2;
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=2){
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=307){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=41){
if(r.integer<28>()<=0){
if(r.integer<20>()<=86){
if(r.integer<19>()<=85){
if(r.integer<39>()<=0){
if(r.integer<10>()<=19){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<4>()<=173){
if(r.integer<20>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<15>()<=3){
return 0x1.5c28f5c28f5c3p-1;
}else{
return -0x1.edf29ff54afa0p-5;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=60){
return 0x1.7c41deb9fee10p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<38>()<=1){
if(r.integer<53>()<=32){
if(r.integer<47>()<=-1){
return 0x1.999999999999ap-3;
}else{
if(r.integer<19>()<=95){
if(r.integer<55>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=4884){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<3>()<=61){
return 0x0.0p+0;
}else{
return 0x1.5810624dd2f1ap-3;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=62){
return 0x1.80e2f0364760ep-2;
}else{
return 0x1.5d63886594af5p+0;
}
}
}else{
return 0x1.1eb851eb851ebp+2;
}
}
}else{
if(r.integer<19>()<=5){
if(r.integer<39>()<=-1){
return -0x1.2d77318fc5049p-5;
}else{
if(r.integer<14>()<=4){
return 0x1.f7ced916872b0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<46>()<=6){
if(r.integer<26>()<=249){
if(r.integer<5>()<=271){
if(r.integer<1>()<=101){
return 0x1.5e29c67576a34p+1;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<25>()<=133){
return 0x1.999999999999ap-2;
}else{
return -0x1.6f0068db8bac8p-5;
}
}
}else{
return 0x1.47ae147ae147cp+0;
}
}else{
return 0x1.5ef4aaa7f2badp+3;
}
}
}
}else{
if(r.integer<31>()<=5198){
if(r.integer<19>()<=35){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=155){
return 0x1.a9fbe76c8b43ap-3;
}else{
return 0x1.77ac0b9e5aec8p+1;
}
}
}else{
if(r.integer<20>()<=50){
if(r.integer<14>()<=4){
if(r.integer<5>()<=37){
return -0x1.412bcb01469eep-5;
}else{
if(r.integer<7>()<=-11){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-58){
if(r.integer<31>()<=14167){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=9717){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<7>()<=-40){
if(r.integer<53>()<=89){
if(r.integer<20>()<=53){
if(r.integer<44>()<=16){
if(r.integer<50>()<=-47){
if(r.integer<20>()<=30){
return -0x1.a36e2eb1c432dp-6;
}else{
if(r.integer<8>()<=33){
if(r.integer<3>()<=42){
return 0x1.47ae147ae147cp-3;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<19>()<=84){
return 0x1.a36e2eb1c4300p-8;
}else{
return 0x1.ef9db22d0e560p-1;
}
}
}
}else{
return 0x1.0624dd2f1a9fdp-6;
}
}else{
if(r.integer<3>()<=60){
if(r.integer<10>()<=43){
return -0x1.1eb851eb851ecp-2;
}else{
return 0x1.e1b089a027525p-3;
}
}else{
return 0x1.e83e425aee632p+0;
}
}
}else{
if(r.integer<1>()<=106){
if(r.integer<20>()<=90){
if(r.integer<8>()<=27){
if(r.integer<53>()<=43){
return -0x1.999999999999ap-3;
}else{
return 0x1.4395810624dd4p-1;
}
}else{
if(r.integer<19>()<=16){
return 0x1.916872b020c4ap+0;
}else{
return 0x1.ff2e48e8a71ddp-2;
}
}
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<19>()<=45){
if(r.integer<19>()<=4){
return 0x1.999999999999ap-2;
}else{
return 0x1.eb851eb851eb8p-4;
}
}else{
if(r.integer<28>()<=0){
if(r.integer<10>()<=69){
return 0x1.a5e353f7ced92p-1;
}else{
return 0x1.26e978d4fdf3bp-2;
}
}else{
return -0x1.6872b020c49c0p-4;
}
}
}
}
}else{
if(r.integer<19>()<=49){
if(r.integer<1>()<=93){
if(r.integer<38>()<=-2){
return -0x1.0624dd2f1a9fbp-4;
}else{
if(r.integer<53>()<=93){
return -0x1.3333333333334p-1;
}else{
return 0x1.28f5c28f5c28fp+0;
}
}
}else{
if(r.integer<1>()<=103){
if(r.integer<36>()<=18){
if(r.integer<39>()<=0){
return 0x1.999999999999ap-3;
}else{
return 0x1.6872b020c49bbp-1;
}
}else{
if(r.integer<1>()<=99){
return -0x1.0624dd2f1a9fcp-5;
}else{
return 0x1.ba5e353f7cedap-3;
}
}
}else{
if(r.integer<35>()<=3){
if(r.integer<31>()<=11131){
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=455){
return 0x1.47ae147ae147cp-2;
}else{
return -0x1.26e978d4fdf3bp-4;
}
}
}
}else{
if(r.integer<50>()<=-39){
if(r.integer<43>()<=4){
if(r.integer<44>()<=10){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=50){
return 0x1.1eb851eb851ebp-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=37){
if(r.integer<8>()<=102){
return -0x1.cac083126e978p-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}
}
}else{
if(r.integer<51>()<=-92){
if(r.integer<19>()<=62){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=78){
if(r.integer<1>()<=109){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.a9fbe76c8b43ap-4;
}
}
}
}
}else{
if(r.integer<7>()<=-3){
if(r.integer<36>()<=18){
if(r.integer<7>()<=-17){
if(r.integer<31>()<=2071){
return -0x1.4e3bcd35a858ap-3;
}else{
if(r.integer<1>()<=83){
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=62){
if(r.integer<51>()<=90){
if(r.integer<47>()<=1){
if(r.integer<10>()<=63){
if(r.integer<20>()<=32){
if(r.integer<4>()<=126){
return 0x1.f3b645a1cac08p-2;
}else{
if(r.integer<50>()<=-31){
if(r.integer<20>()<=13){
return 0x0.0p+0;
}else{
return 0x1.013a92a305533p-2;
}
}else{
if(r.integer<5>()<=345){
if(r.integer<1>()<=89){
return 0x0.0p+0;
}else{
return -0x1.a9fbe76c8b43ap-4;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=42){
return 0x1.89374bc6a7efcp-6;
}else{
return 0x1.19652bd3c3612p+0;
}
}
}else{
if(r.integer<19>()<=56){
if(r.integer<20>()<=37){
if(r.integer<53>()<=93){
if(r.integer<6>()<=32){
return -0x1.78d4fdf3b645ap-3;
}else{
return 0x1.b22d0e560418ap-2;
}
}else{
return 0x1.020c49ba5e354p+0;
}
}else{
if(r.integer<19>()<=28){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=281){
if(r.integer<31>()<=6235){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<26>()<=200){
return -0x1.0624dd2f1a9fcp-5;
}else{
return 0x1.eb851eb851eb8p-2;
}
}
}else{
if(r.integer<53>()<=75){
return 0x1.b573eab367a10p-2;
}else{
if(r.integer<7>()<=-30){
return 0x1.0624dd2f1aa00p-6;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<51>()<=45){
if(r.integer<3>()<=71){
return 0x1.47ae147ae147cp+0;
}else{
return 0x1.710cb295e9e1cp+3;
}
}else{
if(r.integer<3>()<=67){
return 0x1.26e978d4fdf3bp-2;
}else{
return -0x1.24dd2f1a9fbe8p+0;
}
}
}else{
if(r.integer<51>()<=45){
return 0x0.0p+0;
}else{
return 0x1.78d4fdf3b645ap-1;
}
}
}
}else{
if(r.integer<47>()<=-2){
if(r.integer<3>()<=65){
return 0x1.604189374bc6bp-2;
}else{
return 0x1.1566cf41f212ep+3;
}
}else{
if(r.integer<20>()<=10){
return 0x1.cac083126e97ap-5;
}else{
if(r.integer<50>()<=-39){
return 0x1.bda5119ce075ap-4;
}else{
return 0x1.f3b645a1cac08p-2;
}
}
}
}
}else{
if(r.integer<5>()<=383){
if(r.integer<31>()<=7950){
return 0x1.47ae147ae147ap-4;
}else{
if(r.integer<53>()<=230){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=-28){
if(r.integer<19>()<=25){
return 0x1.47ae147ae147ap-2;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return -0x1.cd60cd1d16b45p-4;
}
}
}
}
}
}
}else{
if(r.integer<47>()<=-7){
if(r.integer<31>()<=5700){
return 0x1.fbd0bf922daecp+2;
}else{
return 0x1.0a3d70a3d70a3p-1;
}
}else{
if(r.integer<30>()<=0){
if(r.integer<31>()<=2791){
return -0x1.5c28f5c28f5c4p-1;
}else{
if(r.integer<50>()<=-9){
if(r.integer<26>()<=230){
return 0x1.eb851eb851eb8p+0;
}else{
return -0x1.4395810624dd4p-1;
}
}else{
return -0x1.eb851eb851ebap-2;
}
}
}else{
if(r.integer<19>()<=41){
if(r.integer<39>()<=0){
if(r.integer<6>()<=44){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=59){
return -0x1.47ae147ae147cp-3;
}else{
if(r.integer<2>()<=217){
return 0x1.0a3d70a3d70a4p-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x1.3333333333334p+0;
}
}else{
if(r.integer<1>()<=79){
if(r.integer<38>()<=1){
return 0x0.0p+0;
}else{
return 0x1.0000000000000p+0;
}
}else{
if(r.integer<50>()<=-6){
return 0x1.999999999999ap-2;
}else{
return 0x1.af837b4a2339dp+3;
}
}
}
}
}
}
}else{
if(r.integer<1>()<=85){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=16){
if(r.integer<19>()<=51){
if(r.integer<1>()<=99){
if(r.integer<43>()<=5){
if(r.integer<24>()<=54){
return -0x1.47ae147ae147cp-4;
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}else{
return 0x1.89374bc6a7ef4p-6;
}
}else{
if(r.integer<7>()<=-18){
if(r.integer<26>()<=227){
return 0x0.0p+0;
}else{
return 0x1.78d4fdf3b645bp-2;
}
}else{
return 0x1.d5810624dd2f2p+2;
}
}
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}
}
}else{
if(r.integer<38>()<=-2){
if(r.integer<1>()<=81){
return -0x1.23d70a3d70a3ep+1;
}else{
return 0x1.9c0ebedfa4400p-1;
}
}else{
if(r.integer<53>()<=51){
return -0x1.e846dcca357d7p-4;
}else{
if(r.integer<50>()<=-5){
return -0x1.d0e5604189377p+0;
}else{
if(r.integer<15>()<=5){
return 0x1.448e8a71de69cp+4;
}else{
if(r.integer<38>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.2ebedfa43fe5dp+3;
}
}
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_4(const BudgetResidualFeatures&r){
if(r.integer<44>()<=13){
if(r.integer<3>()<=74){
if(r.integer<53>()<=97){
if(r.integer<1>()<=87){
if(r.integer<9>()<=39){
if(r.integer<53>()<=59){
if(r.integer<0>()<=852){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-31){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=280){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=36){
if(r.integer<52>()<=48){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-40){
if(r.integer<35>()<=3){
if(r.integer<3>()<=40){
return 0x0.0p+0;
}else{
return -0x1.a36e2eb1c432fp-9;
}
}else{
if(r.integer<38>()<=1){
if(r.integer<14>()<=6){
return -0x1.a36e2eb1c432fp-9;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=64){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<4>()<=66){
if(r.integer<1>()<=14){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=32){
if(r.integer<4>()<=3){
return 0x1.0624dd2f1a9fdp-7;
}else{
if(r.integer<20>()<=49){
if(r.integer<19>()<=49){
if(r.integer<19>()<=44){
if(r.integer<20>()<=1){
if(r.integer<31>()<=8856){
return 0x1.1eb851eb851ecp-2;
}else{
if(r.integer<3>()<=40){
return -0x1.dc5d63886594cp+1;
}else{
return -0x1.876c8b4395810p+3;
}
}
}else{
if(r.integer<20>()<=47){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=63){
if(r.integer<38>()<=1){
if(r.integer<0>()<=1721){
if(r.integer<10>()<=29){
if(r.integer<39>()<=0){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.47ae147ae147cp+0;
}
}else{
if(r.integer<46>()<=-1){
return 0x1.2a9930be0ded3p+0;
}else{
if(r.integer<50>()<=-21){
if(r.integer<35>()<=4){
if(r.integer<55>()<=2){
return 0x1.91ef0ffb7c70fp-1;
}else{
if(r.integer<15>()<=2){
return 0x1.02de00d1b7176p-3;
}else{
if(r.integer<50>()<=-38){
return 0x1.13404ea4a8c13p-3;
}else{
return -0x1.0624dd2f1a9fdp-5;
}
}
}
}else{
return 0x1.5cabe5ee6e206p+0;
}
}else{
return -0x1.406036970db11p-5;
}
}
}
}
}else{
if(r.integer<19>()<=47){
if(r.integer<19>()<=11){
if(r.integer<33>()<=8){
if(r.integer<20>()<=88){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<35>()<=5){
if(r.integer<13>()<=4){
return -0x1.fc8f32378ab0dp-6;
}else{
return 0x1.495182a9930bfp+0;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
return 0x1.78d4fdf3b645ap-3;
}
}else{
if(r.integer<44>()<=1){
if(r.integer<36>()<=6){
if(r.integer<1>()<=94){
return 0x1.8000000000000p+1;
}else{
if(r.integer<3>()<=65){
return 0x1.a786c226809d5p-1;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
if(r.integer<32>()<=7){
return 0x0.0p+0;
}else{
return 0x1.dd2f1a9fbe76dp+0;
}
}
}else{
if(r.integer<1>()<=109){
if(r.integer<13>()<=8){
if(r.integer<53>()<=12){
return -0x1.0624dd2f1a9fcp-4;
}else{
if(r.integer<55>()<=1){
return 0x1.bd3c36113404fp+0;
}else{
if(r.integer<0>()<=1046){
return 0x1.1ccd393c775aap+0;
}else{
if(r.integer<3>()<=59){
if(r.integer<39>()<=-1){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}
}else{
return 0x1.cc8de2ac3222ap-1;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<19>()<=88){
if(r.integer<51>()<=-41){
if(r.integer<19>()<=85){
if(r.integer<47>()<=-1){
if(r.integer<4>()<=428){
return 0x1.3a92a30553262p-8;
}else{
return -0x1.16872b020c49cp-3;
}
}else{
if(r.integer<7>()<=-45){
return 0x1.0624dd2f1a9fbp-3;
}else{
if(r.integer<6>()<=444){
if(r.integer<1>()<=105){
if(r.integer<8>()<=-75){
if(r.integer<53>()<=83){
return -0x1.0ff972474538fp-3;
}else{
return 0x1.63f141205bc00p+0;
}
}else{
if(r.integer<35>()<=5){
return 0x1.04189374bc6a8p+0;
}else{
return 0x1.89374bc6a7efcp-6;
}
}
}else{
return 0x1.cb923a29c779ap+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=7411){
return -0x1.a9fbe76c8b43ap-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=75){
if(r.integer<51>()<=66){
if(r.integer<19>()<=49){
if(r.integer<5>()<=150){
if(r.integer<0>()<=1439){
return -0x1.bad637e247de0p-2;
}else{
return -0x1.6b11c6d1e108cp-3;
}
}else{
if(r.integer<25>()<=244){
if(r.integer<25>()<=208){
return 0x0.0p+0;
}else{
return -0x1.9652bd3c36114p-2;
}
}else{
return 0x1.7dbf487fcb924p-2;
}
}
}else{
if(r.integer<53>()<=61){
if(r.integer<36>()<=18){
if(r.integer<53>()<=39){
if(r.integer<17>()<=4){
if(r.integer<19>()<=63){
return 0x1.47ae147ae147cp-2;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x1.fbe76c8b43958p-3;
}
}else{
if(r.integer<5>()<=37){
if(r.integer<4>()<=313){
return -0x1.205bc01a36e2fp-5;
}else{
return -0x1.3404ea4a8c157p-4;
}
}else{
return -0x1.205bc01a36e2fp-6;
}
}
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<5>()<=56){
return -0x1.d29dc725c3defp-6;
}else{
return -0x1.26e978d4fdf3bp-3;
}
}
}
}else{
if(r.integer<20>()<=20){
if(r.integer<1>()<=100){
return 0x1.064ece9a2c669p-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=66){
return -0x1.205bc01a36e2fp-6;
}else{
if(r.integer<6>()<=432){
return 0x1.7f62b6ae7d567p-3;
}else{
return 0x1.5df6555c52e74p-2;
}
}
}
}
}else{
if(r.integer<1>()<=100){
if(r.integer<7>()<=-25){
if(r.integer<39>()<=-7){
return -0x1.a027525460aa7p-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.c9e8a35478f9fp-2;
}
}else{
if(r.integer<31>()<=7070){
return 0x1.851eb851eb852p-1;
}else{
if(r.integer<38>()<=1){
if(r.integer<8>()<=33){
return -0x1.205bc01a36e2fp-6;
}else{
return 0x1.2599ed7c6fbd3p-2;
}
}else{
return 0x1.2eb1c432ca57bp+0;
}
}
}
}
}
}else{
if(r.integer<8>()<=33){
if(r.integer<7>()<=-37){
return -0x1.83f91e646f154p-6;
}else{
if(r.integer<44>()<=4){
return 0x1.999999999999ap-2;
}else{
return -0x1.3a92a30553264p-8;
}
}
}else{
if(r.integer<3>()<=54){
if(r.integer<35>()<=5){
return 0x1.c28f5c28f5c2ap-2;
}else{
return 0x1.6666666666667p+0;
}
}else{
return 0x1.ae536501e2585p+0;
}
}
}
}else{
if(r.integer<44>()<=1){
if(r.integer<19>()<=51){
if(r.integer<1>()<=103){
if(r.integer<38>()<=-2){
if(r.integer<23>()<=19){
return 0x1.14e3bcd35a858p+0;
}else{
return -0x1.b089a02752547p-4;
}
}else{
if(r.integer<3>()<=59){
if(r.integer<38>()<=1){
return 0x1.73ffac1d29dc8p+0;
}else{
return 0x1.604189374bc6ap-2;
}
}else{
if(r.integer<8>()<=45){
if(r.integer<32>()<=1){
return 0x1.6d0e560418938p+2;
}else{
return 0x1.1eb851eb851ebp-1;
}
}else{
return -0x1.0c2c20b48cde1p-4;
}
}
}
}else{
if(r.integer<3>()<=59){
if(r.integer<43>()<=4){
if(r.integer<25>()<=4){
return 0x1.199999999999ap+1;
}else{
return 0x1.2253111f0c34cp-2;
}
}else{
return 0x1.a858793dd97f7p-1;
}
}else{
if(r.integer<0>()<=2060){
return 0x1.a36e2eb1c432dp-8;
}else{
return -0x1.54c985f06f695p-3;
}
}
}
}else{
if(r.integer<8>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=85){
if(r.integer<3>()<=45){
return -0x1.205bc01a36e2fp-6;
}else{
return 0x1.613d31b9b66fap-2;
}
}else{
return 0x1.f3b645a1cac08p-2;
}
}
}
}else{
if(r.integer<46>()<=1){
if(r.integer<3>()<=56){
if(r.integer<19>()<=49){
if(r.integer<43>()<=4){
if(r.integer<43>()<=2){
return 0x1.404ea4a8c154cp-1;
}else{
if(r.integer<36>()<=13){
if(r.integer<31>()<=8352){
if(r.integer<5>()<=145){
return 0x1.c91d14e3bcd37p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
if(r.integer<18>()<=9){
return -0x1.3a92a30553262p-6;
}else{
return -0x1.6f0068db8bac8p-3;
}
}
}else{
return -0x1.4af4f0d844d02p-3;
}
}
}else{
if(r.integer<35>()<=4){
return 0x1.9652bd3c36114p-1;
}else{
return 0x1.cac083126e97ap-3;
}
}
}else{
if(r.integer<19>()<=85){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-24){
return 0x0.0p+0;
}else{
return 0x1.a1cac083126eap-2;
}
}
}
}else{
if(r.integer<39>()<=0){
if(r.integer<36>()<=17){
if(r.integer<4>()<=167){
return -0x1.bda5119ce0760p-4;
}else{
if(r.integer<4>()<=195){
if(r.integer<55>()<=7){
return -0x1.a36e2eb1c4334p-8;
}else{
return 0x1.930be0ded288dp-2;
}
}else{
if(r.integer<54>()<=0){
return -0x1.4e3bcd35a858ap-3;
}else{
if(r.integer<16>()<=4){
if(r.integer<20>()<=61){
return 0x1.9e83e425aee64p-2;
}else{
if(r.integer<2>()<=298){
return -0x1.d495182a9930dp-3;
}else{
return 0x1.e4f765fd8adadp-5;
}
}
}else{
if(r.integer<20>()<=68){
return -0x1.07055e5a12a02p-3;
}else{
return -0x1.89374bc6a7efap-6;
}
}
}
}
}
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}else{
return 0x1.8fc504816f007p-3;
}
}
}else{
return 0x1.15b573eab367ap-1;
}
}
}
}
}
}else{
if(r.integer<1>()<=85){
if(r.integer<31>()<=7915){
if(r.integer<43>()<=4){
if(r.integer<5>()<=340){
if(r.integer<31>()<=4485){
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=16){
if(r.integer<51>()<=-107){
if(r.integer<35>()<=4){
if(r.integer<31>()<=5700){
if(r.integer<51>()<=-128){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=409){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<2>()<=78){
if(r.integer<3>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=78){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=39){
if(r.integer<50>()<=-29){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=54){
if(r.integer<9>()<=38){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=10055){
if(r.integer<53>()<=188){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.47ae147ae147cp-2;
}
}
}else{
if(r.integer<53>()<=156){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=10055){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=9537){
if(r.integer<19>()<=49){
if(r.integer<1>()<=95){
if(r.integer<36>()<=18){
if(r.integer<5>()<=383){
return 0x1.f6fd21ff2e48fp-1;
}else{
if(r.integer<5>()<=439){
if(r.integer<31>()<=8970){
return -0x1.6872b020c49bap-3;
}else{
return 0x1.42c3c9eecbfb2p-1;
}
}else{
if(r.integer<5>()<=477){
return 0x1.d41743e963dc4p-1;
}else{
return 0x1.6f0068db8bab4p-6;
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<31>()<=8599){
return -0x1.61e4f765fd8acp-5;
}else{
return 0x1.54c985f06f694p-6;
}
}else{
return 0x1.a36e2eb1c432fp-8;
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<8>()<=96){
if(r.integer<5>()<=455){
if(r.integer<39>()<=-1){
return 0x1.47ae147ae147ap-5;
}else{
if(r.integer<43>()<=4){
if(r.integer<42>()<=128){
return 0x1.32617c1bda512p-2;
}else{
return 0x1.1eb851eb851ebp+0;
}
}else{
return 0x1.db22d0e56041ap-1;
}
}
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<19>()<=33){
if(r.integer<39>()<=-7){
return 0x1.f141205bc01a4p-1;
}else{
if(r.integer<10>()<=103){
return -0x1.3a92a30553262p-3;
}else{
return 0x1.16872b020c49cp-3;
}
}
}else{
if(r.integer<3>()<=56){
return -0x1.47ae147ae147cp-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=-40){
return 0x0.0p+0;
}else{
return 0x1.bbadc0980b242p-3;
}
}
}
}else{
if(r.integer<8>()<=138){
if(r.integer<19>()<=61){
if(r.integer<8>()<=-126){
return 0x1.54c985f06f694p-5;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=36){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=105){
if(r.integer<2>()<=178){
return 0x1.26e978d4fdf3bp-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=88){
if(r.integer<31>()<=3443){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-25){
return 0x1.5b573eab367a1p-2;
}else{
return 0x1.6666666666667p+0;
}
}
}
}
}else{
if(r.integer<31>()<=13030){
if(r.integer<50>()<=-71){
if(r.integer<50>()<=-80){
if(r.integer<43>()<=5){
if(r.integer<20>()<=32){
if(r.integer<3>()<=20){
if(r.integer<19>()<=31){
return 0x1.94af4f0d844d0p-1;
}else{
if(r.integer<19>()<=91){
return 0x0.0p+0;
}else{
return 0x1.4fdf3b645a1cbp-2;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-152){
if(r.integer<19>()<=63){
return 0x1.47ae147ae147cp-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<35>()<=0){
return -0x1.0624dd2f1a9fdp-7;
}else{
if(r.integer<17>()<=5){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
return -0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=60){
if(r.integer<35>()<=4){
if(r.integer<1>()<=107){
if(r.integer<39>()<=-7){
return 0x1.916872b020c4ap-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=99){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=44){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<51>()<=-45){
if(r.integer<1>()<=91){
if(r.integer<20>()<=19){
if(r.integer<43>()<=5){
if(r.integer<3>()<=100){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-60){
if(r.integer<0>()<=1457){
return -0x1.67caea747d807p-3;
}else{
if(r.integer<38>()<=0){
return 0x1.4bdba0a52695ap+0;
}else{
return 0x1.7342edbb59ddcp-1;
}
}
}else{
return 0x1.f727136a400fcp+0;
}
}
}else{
if(r.integer<35>()<=2){
if(r.integer<5>()<=345){
if(r.integer<28>()<=0){
if(r.integer<43>()<=4){
if(r.integer<19>()<=63){
return -0x1.2ad81adea8978p-5;
}else{
return -0x1.a9fbe76c8b438p-3;
}
}else{
return 0x1.c62a1b5c7cd8ap-2;
}
}else{
if(r.integer<1>()<=60){
return 0x1.28e0c9d9d3458p-2;
}else{
if(r.integer<2>()<=266){
return 0x1.70a3d70a3d70bp-2;
}else{
return -0x1.26e978d4fdf3cp-4;
}
}
}
}else{
if(r.integer<1>()<=81){
return 0x1.19f7f8ca8198fp-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=6){
if(r.integer<39>()<=-2){
return 0x1.1a75cd0bb6ed7p-3;
}else{
return 0x1.2ccf6be37de93p-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=71){
if(r.integer<19>()<=7){
return -0x1.30164840e171ap-3;
}else{
return 0x1.5ca6ca03c4b00p-4;
}
}else{
if(r.integer<43>()<=6){
if(r.integer<46>()<=0){
return -0x1.a36e2eb1c432dp-5;
}else{
return 0x1.8e757928e0c9ep-2;
}
}else{
if(r.integer<54>()<=4){
return -0x1.205bc01a36e2fp-5;
}else{
return 0x1.2599ed7c6fbd3p-2;
}
}
}
}
}else{
if(r.integer<1>()<=71){
if(r.integer<20>()<=85){
if(r.integer<20>()<=36){
if(r.integer<47>()<=-1){
if(r.integer<51>()<=-51){
return -0x1.cd5f99c38b04dp-7;
}else{
return -0x1.cac083126e97ap-4;
}
}else{
if(r.integer<3>()<=102){
if(r.integer<35>()<=2){
if(r.integer<5>()<=367){
return 0x0.0p+0;
}else{
return 0x1.2e72da122fad7p-1;
}
}else{
return 0x1.4eb9a176ddacfp-1;
}
}else{
if(r.integer<2>()<=520){
return 0x1.89374bc6a7efap-5;
}else{
return 0x1.bda5119ce0760p-2;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<42>()<=128){
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=18){
return -0x1.98f1d3ed527e4p-7;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-173){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<19>()<=68){
if(r.integer<6>()<=36){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=28){
return 0x1.47ae147ae147cp-2;
}else{
return 0x1.47ae147ae147cp-5;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<5>()<=283){
if(r.integer<35>()<=2){
if(r.integer<10>()<=99){
if(r.integer<1>()<=67){
return 0x1.47ae147ae147cp-2;
}else{
return -0x1.4af4f0d844d01p-3;
}
}else{
if(r.integer<50>()<=28){
return 0x1.1eb851eb851ebp-2;
}else{
return -0x1.4cec41dd1a220p-4;
}
}
}else{
if(r.integer<0>()<=1753){
return 0x1.5c28f5c28f5c3p-1;
}else{
if(r.integer<10>()<=206){
return 0x0.0p+0;
}else{
return 0x1.78d4fdf3b645ap-2;
}
}
}
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<38>()<=6){
if(r.integer<50>()<=0){
if(r.integer<30>()<=0){
if(r.integer<0>()<=1046){
return 0x1.84ac9f86a25acp-5;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=89){
return 0x1.45460aa64c2f8p+3;
}else{
if(r.integer<39>()<=0){
return 0x0.0p+0;
}else{
return 0x1.590ea9e6eeb70p+3;
}
}
}
}else{
if(r.integer<19>()<=65){
if(r.integer<5>()<=271){
if(r.integer<1>()<=85){
if(r.integer<31>()<=7950){
if(r.integer<3>()<=83){
if(r.integer<5>()<=29){
return 0x1.399bd1cabb70dp+2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<17>()<=4){
return 0x1.872b020c49ba6p+0;
}else{
return 0x1.38ef34d6a161fp+1;
}
}
}else{
if(r.integer<39>()<=0){
return -0x1.4fdf3b645a1cbp-2;
}else{
return 0x1.999999999999ap-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=87){
if(r.integer<51>()<=-89){
return 0x1.a9fbe76c8b434p-4;
}else{
return -0x1.0f4837826a6a0p-2;
}
}else{
if(r.integer<19>()<=11){
if(r.integer<18>()<=4){
return -0x1.19ce075f6fd23p-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=89){
if(r.integer<31>()<=4077){
return 0x1.5e3fbbd7b2032p+2;
}else{
if(r.integer<51>()<=-128){
if(r.integer<31>()<=5091){
return 0x1.d57bc7f77af60p+1;
}else{
return -0x1.385c67dfe32a7p+0;
}
}else{
return -0x1.c5ac471b4784dp+0;
}
}
}else{
if(r.integer<47>()<=0){
if(r.integer<43>()<=4){
if(r.integer<8>()<=-58){
if(r.integer<5>()<=367){
if(r.integer<35>()<=2){
if(r.integer<3>()<=102){
return 0x0.0p+0;
}else{
return -0x1.26e978d4fdf3cp-4;
}
}else{
if(r.integer<35>()<=6){
return 0x1.eb851eb851eb8p-4;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.0624dd2f1a9fdp-6;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=75){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=7070){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<3>()<=82){
return 0x1.1d2f1a9fbe76dp+2;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}
}else{
if(r.integer<3>()<=78){
if(r.integer<20>()<=83){
if(r.integer<20>()<=38){
return 0x1.b8bac710cb297p-1;
}else{
if(r.integer<6>()<=410){
return 0x0.0p+0;
}else{
return 0x1.16872b020c49bp-1;
}
}
}else{
return 0x1.5c28f5c28f5c3p-1;
}
}else{
if(r.integer<31>()<=5125){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=107){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=7104){
if(r.integer<29>()<=8){
if(r.integer<28>()<=0){
if(r.integer<19>()<=87){
if(r.integer<53>()<=8){
return -0x1.856c9f41cd0c0p-5;
}else{
if(r.integer<3>()<=90){
if(r.integer<52>()<=3){
if(r.integer<30>()<=4){
if(r.integer<18>()<=9){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.33a53b8e4b87cp+4;
}
}else{
if(r.integer<20>()<=59){
if(r.integer<3>()<=75){
if(r.integer<31>()<=2631){
return -0x1.16872b020c49cp-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=89){
return 0x1.e24dd2f1a9fbfp+1;
}else{
if(r.integer<29>()<=2){
return 0x1.ef6a033a6f1acp+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<14>()<=3){
if(r.integer<5>()<=345){
if(r.integer<29>()<=1){
return 0x1.2e978d4fdf3b7p+3;
}else{
return 0x1.78d4fdf3b645bp-3;
}
}else{
if(r.integer<16>()<=3){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.851eb851eb852p+0;
}
}
}else{
if(r.integer<53>()<=20){
return -0x1.0dda7bcd0e386p-4;
}else{
if(r.integer<39>()<=-1){
if(r.integer<51>()<=-33){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<29>()<=1){
return 0x1.3cac083126e98p+3;
}else{
return 0x1.cac083126e97ap-1;
}
}
}else{
if(r.integer<1>()<=76){
if(r.integer<30>()<=1){
return 0x1.0624dd2f1aa00p-6;
}else{
if(r.integer<3>()<=78){
return -0x1.eb851eb851ebap-4;
}else{
return -0x1.0cb295e9e1b09p-4;
}
}
}else{
if(r.integer<50>()<=-7){
if(r.integer<10>()<=31){
return 0x1.88a7d83af36a8p-1;
}else{
if(r.integer<7>()<=-16){
return 0x1.5c4ab46587bcap-2;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
return 0x1.02a8c97ef9db3p+1;
}
}
}
}
}
}
}
}else{
if(r.integer<53>()<=61){
if(r.integer<0>()<=1307){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<38>()<=-2){
return 0x1.4000000000000p+2;
}else{
if(r.integer<1>()<=88){
if(r.integer<52>()<=5){
if(r.integer<30>()<=1){
return 0x0.0p+0;
}else{
return 0x1.d95d4e8fb00bdp+3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-7){
return 0x1.95810624dd2f2p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=0){
if(r.integer<31>()<=4485){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=86){
if(r.integer<38>()<=1){
if(r.integer<20>()<=1){
if(r.integer<51>()<=-11){
if(r.integer<2>()<=220){
return -0x1.7ed53524ca0fap-5;
}else{
return -0x1.750b0f27bb2ffp+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=6){
if(r.integer<3>()<=103){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=52){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=52){
if(r.integer<20>()<=11){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=117){
if(r.integer<8>()<=30){
return 0x0.0p+0;
}else{
return 0x1.19ce075f6fd23p-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<0>()<=3875){
if(r.integer<52>()<=6){
if(r.integer<52>()<=0){
if(r.integer<24>()<=37){
if(r.integer<19>()<=87){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=3939){
return 0x0.0p+0;
}else{
return 0x1.0000000000000p+0;
}
}
}else{
if(r.integer<6>()<=279){
if(r.integer<6>()<=264){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=280){
if(r.integer<0>()<=1786){
if(r.integer<24>()<=42){
if(r.integer<31>()<=4328){
if(r.integer<16>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=6267){
if(r.integer<13>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=7){
return 0x1.65501bb850eb4p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<53>()<=105){
if(r.integer<53>()<=59){
if(r.integer<52>()<=9){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=6){
if(r.integer<29>()<=10){
if(r.integer<20>()<=35){
return 0x1.a1acf5dda389dp+2;
}else{
if(r.integer<19>()<=43){
if(r.integer<52>()<=12){
return 0x1.c283d0426604fp+1;
}else{
if(r.integer<19>()<=11){
return -0x1.2368b6b2b4245p-3;
}else{
return 0x1.b1bc4386022bcp+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=284){
if(r.integer<7>()<=-41){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=95){
if(r.integer<51>()<=-64){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=29){
if(r.integer<19>()<=74){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=5534){
if(r.integer<30>()<=7){
if(r.integer<29>()<=7){
if(r.integer<30>()<=4){
return 0x1.ead227828220ap+2;
}else{
return 0x1.5c28f5c28f5c3p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=29){
if(r.integer<5>()<=261){
if(r.integer<31>()<=6400){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=11654){
return 0x0.0p+0;
}else{
return 0x1.1eb851eb851ebp-1;
}
}
}else{
if(r.integer<30>()<=13){
if(r.integer<29>()<=18){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=8970){
if(r.integer<36>()<=17){
if(r.integer<3>()<=72){
if(r.integer<31>()<=6568){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=85){
if(r.integer<52>()<=69){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.6f0068db8bac8p-3;
}
}
}
}
}
}else{
if(r.integer<53>()<=38){
if(r.integer<28>()<=0){
if(r.integer<19>()<=4){
if(r.integer<30>()<=15){
return -0x1.b328b6d86ec18p-4;
}else{
return -0x1.e2584f4c6e6dcp-6;
}
}else{
if(r.integer<20>()<=90){
if(r.integer<19>()<=85){
if(r.integer<39>()<=0){
return -0x1.0624dd2f1aa00p-6;
}else{
if(r.integer<20>()<=29){
return -0x1.0624dd2f1a9fbp-7;
}else{
return 0x1.0ff972474538fp+1;
}
}
}else{
if(r.integer<31>()<=7615){
return 0x1.e8a71de69ad44p+1;
}else{
return 0x1.851eb851eb852p-1;
}
}
}else{
if(r.integer<47>()<=-1){
return 0x1.89374bc6a7ef7p-2;
}else{
if(r.integer<47>()<=7){
return 0x1.0d024444cf744p+3;
}else{
return 0x1.3f7ced9168727p-2;
}
}
}
}
}else{
if(r.integer<19>()<=6){
if(r.integer<5>()<=134){
return -0x1.fbe76c8b4395ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<2>()<=462){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=47){
if(r.integer<30>()<=3){
if(r.integer<6>()<=279){
if(r.integer<6>()<=263){
return 0x1.f8a0902de00d4p-3;
}else{
if(r.integer<30>()<=1){
return 0x1.6bbecaab8a5cfp+3;
}else{
return 0x1.a83e425aee632p+2;
}
}
}else{
if(r.integer<10>()<=79){
return -0x1.19ce075f6fd22p+0;
}else{
if(r.integer<6>()<=285){
return 0x1.d2f1a9fbe76c8p-1;
}else{
return -0x1.59b3d07c84b5fp-2;
}
}
}
}else{
if(r.integer<6>()<=284){
if(r.integer<51>()<=-43){
if(r.integer<19>()<=72){
if(r.integer<31>()<=7650){
if(r.integer<47>()<=7){
if(r.integer<30>()<=6){
return 0x1.d7dbf487fcb95p-7;
}else{
return 0x1.41205bc01a36fp+0;
}
}else{
return 0x1.56c0d6f544bb2p+2;
}
}else{
if(r.integer<20>()<=12){
if(r.integer<53>()<=47){
return -0x1.119ce075f6fd3p-2;
}else{
return 0x1.47ae147ae147cp+0;
}
}else{
if(r.integer<3>()<=99){
if(r.integer<7>()<=57){
return 0x1.3333333333334p-1;
}else{
return 0x1.c2f837b4a233ap+1;
}
}else{
return 0x1.0d5a5b9628cbap-3;
}
}
}
}else{
if(r.integer<1>()<=41){
return 0x1.fce3150dae3e7p-1;
}else{
if(r.integer<52>()<=27){
if(r.integer<6>()<=272){
return -0x1.19ce075f6fd23p-4;
}else{
return -0x1.e69ad42c3c9f0p-2;
}
}else{
if(r.integer<5>()<=466){
if(r.integer<30>()<=15){
if(r.integer<20>()<=32){
return 0x1.075f6fd21ff2fp+0;
}else{
return -0x1.5810624dd2f1cp-3;
}
}else{
if(r.integer<35>()<=4){
return -0x1.0624dd2f1a9fdp-4;
}else{
return 0x1.8201cd5f99c39p-2;
}
}
}else{
return 0x1.7ced916872b02p-1;
}
}
}
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<30>()<=9){
return 0x1.58b2e9ccb7d42p+2;
}else{
if(r.integer<19>()<=74){
if(r.integer<55>()<=4){
if(r.integer<24>()<=24){
return 0x1.3a92a30553262p-1;
}else{
if(r.integer<19>()<=52){
return 0x1.c779a6b50b0f2p-3;
}else{
return -0x1.ae924f227d02ap-3;
}
}
}else{
if(r.integer<1>()<=44){
return 0x1.916872b020c4ap-2;
}else{
return -0x1.0cb295e9e1b09p-4;
}
}
}else{
return 0x1.47ae147ae147cp-1;
}
}
}else{
if(r.integer<30>()<=9){
if(r.integer<20>()<=21){
return -0x1.6fa82e87d2c7dp-2;
}else{
return 0x1.61e4f765fd8adp-3;
}
}else{
if(r.integer<6>()<=269){
if(r.integer<53>()<=43){
if(r.integer<26>()<=112){
return -0x1.3404ea4a8c155p-2;
}else{
return 0x1.47ae147ae147ap-4;
}
}else{
return 0x1.0385c67dfe32ap-2;
}
}else{
return 0x1.a36e2eb1c4385p-10;
}
}
}
}
}else{
if(r.integer<3>()<=46){
return 0x1.2c7b890d5a5b8p-2;
}else{
return -0x1.a9fbe76c8b43ap-4;
}
}
}
}else{
if(r.integer<53>()<=95){
if(r.integer<29>()<=20){
if(r.integer<6>()<=266){
return 0x1.10624dd2f1a9fp+0;
}else{
if(r.integer<19>()<=48){
if(r.integer<36>()<=10){
if(r.integer<30>()<=26){
if(r.integer<6>()<=278){
if(r.integer<19>()<=11){
if(r.integer<30>()<=10){
return -0x1.70a3d70a3d70bp-2;
}else{
return 0x1.54c985f06f694p-4;
}
}else{
return 0x1.0624dd2f1a9fbp-1;
}
}else{
if(r.integer<5>()<=383){
return 0x1.6872b020c49bbp+0;
}else{
return -0x1.d14e3bcd35a87p-4;
}
}
}else{
if(r.integer<31>()<=12606){
return 0x1.1dd1a21ea3593p+1;
}else{
return 0x1.66cf41f212d77p-2;
}
}
}else{
return 0x1.82a9930be0dedp-4;
}
}else{
if(r.integer<53>()<=47){
return -0x1.4526793dca4e8p-4;
}else{
if(r.integer<19>()<=94){
return 0x1.3dd97f62b6ae7p-3;
}else{
return 0x1.16872b020c49bp+0;
}
}
}
}
}else{
if(r.integer<0>()<=1737){
return -0x1.6872b020c49bbp-4;
}else{
if(r.integer<1>()<=34){
if(r.integer<6>()<=279){
return -0x1.13404ea4a8c17p-4;
}else{
if(r.integer<19>()<=11){
return 0x1.318fc504816f0p+0;
}else{
return 0x1.b5c7cd898b2eap-3;
}
}
}else{
if(r.integer<26>()<=98){
if(r.integer<25>()<=18){
return 0x1.7785729b280f1p-2;
}else{
if(r.integer<2>()<=123){
return -0x1.a027525460aa7p-3;
}else{
return 0x1.ba5e353f7cedap-3;
}
}
}else{
return 0x1.54c985f06f694p-2;
}
}
}
}
}else{
if(r.integer<29>()<=7){
if(r.integer<19>()<=47){
if(r.integer<5>()<=151){
return 0x1.24dd2f1a9fbe7p+1;
}else{
return 0x1.3c36113404ea5p-2;
}
}else{
return 0x1.eb851eb851ebap-4;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=7615){
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=6400){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=31){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<0>()<=5068){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=10674){
if(r.integer<52>()<=29){
return -0x1.374bc6a7ef9dcp-3;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.999999999999ap+0;
}
}
}else{
if(r.integer<50>()<=21){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=362){
if(r.integer<35>()<=4){
if(r.integer<43>()<=4){
if(r.integer<51>()<=-336){
if(r.integer<31>()<=11494){
return -0x1.4f3775b813018p+0;
}else{
return -0x1.7e5753a3ec030p+2;
}
}else{
if(r.integer<31>()<=13712){
if(r.integer<20>()<=51){
if(r.integer<30>()<=4){
if(r.integer<6>()<=280){
return 0x1.bbd7b2031ceafp+2;
}else{
return -0x1.2ca57a786c227p-1;
}
}else{
return -0x1.a36e2eb1c4334p-10;
}
}else{
return -0x1.89374bc6a7ef4p-6;
}
}else{
return -0x1.a2c669057d177p-3;
}
}
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}else{
if(r.integer<43>()<=2){
if(r.integer<35>()<=6){
if(r.integer<20>()<=20){
return 0x1.ab4b72c5197a0p+0;
}else{
return 0x1.844d013a92a30p-2;
}
}else{
if(r.integer<51>()<=-256){
return -0x1.23d70a3d70a3ep+1;
}else{
if(r.integer<24>()<=22){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<51>()<=-183){
return 0x1.999999999999ap-2;
}else{
return -0x1.9a6b50b0f27bcp-1;
}
}else{
if(r.integer<38>()<=1){
if(r.integer<43>()<=5){
if(r.integer<20>()<=49){
return 0x1.47ae147ae147cp-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.cac083126e978p-4;
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<20>()<=39){
if(r.integer<2>()<=298){
return 0x1.1eb851eb851ebp-2;
}else{
return 0x1.e76c8b4395810p-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_5(const BudgetResidualFeatures&r){
if(r.integer<53>()<=103){
if(r.integer<44>()<=13){
if(r.integer<53>()<=55){
if(r.integer<0>()<=852){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=0){
if(r.integer<31>()<=4485){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=186){
if(r.integer<15>()<=5){
return 0x0.0p+0;
}else{
return 0x1.d2e9796f5dbbfp+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<20>()<=87){
if(r.integer<19>()<=67){
if(r.integer<20>()<=64){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=3294){
return -0x1.89374bc6a7efcp-4;
}else{
if(r.integer<29>()<=10){
if(r.integer<26>()<=88){
return -0x1.9652bd3c36114p-4;
}else{
if(r.integer<15>()<=6){
if(r.integer<9>()<=28){
return 0x1.f212d77318fc7p-6;
}else{
return -0x1.ceaf251c193b5p-4;
}
}else{
return 0x1.172ef0ae53650p-2;
}
}
}else{
if(r.integer<31>()<=13712){
if(r.integer<8>()<=54){
if(r.integer<4>()<=102){
return 0x1.3a92a30553267p-8;
}else{
return -0x1.2d77318fc5048p-5;
}
}else{
return 0x1.cd5f99c38b04cp-9;
}
}else{
return 0x1.6238da3c21188p-2;
}
}
}
}
}else{
if(r.integer<29>()<=11){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=75){
return -0x1.72474538ef34dp-3;
}else{
if(r.integer<51>()<=-33){
if(r.integer<54>()<=1){
return 0x1.ab5c39bcba300p+0;
}else{
if(r.integer<6>()<=23){
return -0x1.192641b328b6fp-3;
}else{
return 0x1.8706d45ffecf7p-1;
}
}
}else{
if(r.integer<36>()<=9){
if(r.integer<14>()<=6){
return 0x1.f3b645a1cac08p-2;
}else{
return -0x1.cac083126e97ap-4;
}
}else{
return -0x1.d7dbf487fcb94p-6;
}
}
}
}
}else{
if(r.integer<1>()<=16){
if(r.integer<2>()<=120){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<30>()<=11){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=89){
if(r.integer<14>()<=8){
if(r.integer<0>()<=993){
return -0x1.4af81603f6a50p-4;
}else{
if(r.integer<36>()<=10){
return 0x0.0p+0;
}else{
return 0x1.2da25e4f5c8a7p-2;
}
}
}else{
if(r.integer<50>()<=24){
return 0x1.3a92a30553267p-8;
}else{
return 0x1.3b645a1cac083p-1;
}
}
}else{
if(r.integer<7>()<=24){
if(r.integer<53>()<=22){
return 0x1.551d68c692f6fp-2;
}else{
return 0x1.afe1da7b0b392p+0;
}
}else{
if(r.integer<0>()<=1094){
return -0x1.3e11564e10ef9p-7;
}else{
if(r.integer<20>()<=43){
return 0x1.eadd590c0ad04p-1;
}else{
return -0x1.3dd97f62b6ae7p-3;
}
}
}
}
}
}else{
if(r.integer<31>()<=8282){
if(r.integer<2>()<=75){
if(r.integer<30>()<=58){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=30){
if(r.integer<51>()<=48){
if(r.integer<35>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=457){
return 0x1.0624dd2f1a9f3p-7;
}else{
return -0x1.b9135e3edc19ap-9;
}
}
}else{
return -0x1.58fb43d89ce4cp-4;
}
}else{
return 0x1.60956c0d6f545p-2;
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<50>()<=68){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-34){
if(r.integer<1>()<=54){
if(r.integer<54>()<=3){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<47>()<=0){
return 0x1.1ccb7d41743eap+1;
}else{
if(r.integer<54>()<=4){
return 0x1.851eb851eb852p+0;
}else{
return -0x1.65d3996fa82e8p-4;
}
}
}
}else{
if(r.integer<29>()<=13){
if(r.integer<51>()<=-9){
if(r.integer<5>()<=151){
if(r.integer<14>()<=5){
return 0x1.cfe186cc3eb2cp+1;
}else{
return 0x1.b90ea9e6eeb70p-2;
}
}else{
if(r.integer<31>()<=5799){
return -0x1.3db1a1823604fp-3;
}else{
return 0x1.35fc3b4f61670p-2;
}
}
}else{
return -0x1.f75104d551d6ap-5;
}
}else{
if(r.integer<47>()<=0){
if(r.integer<39>()<=-1){
if(r.integer<3>()<=91){
return -0x1.cac083126e97ap-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<23>()<=12){
return 0x1.4d940789613d4p-1;
}else{
if(r.integer<15>()<=3){
return -0x1.0624dd2f1aa00p-5;
}else{
if(r.integer<52>()<=57){
return 0x1.c28f5c28f5c2ap-2;
}else{
return -0x1.d7dbf487fcb95p-6;
}
}
}
}
}else{
return -0x1.47ae147ae1480p-5;
}
}
}
}
}
}else{
if(r.integer<31>()<=13712){
if(r.integer<52>()<=57){
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=41){
if(r.integer<52>()<=35){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=1653){
if(r.integer<6>()<=463){
if(r.integer<23>()<=58){
if(r.integer<50>()<=31){
if(r.integer<18>()<=8){
if(r.integer<3>()<=72){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=23){
return 0x1.7ced916872b02p-1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<16>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<55>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=17){
if(r.integer<20>()<=49){
return -0x1.22749f0e4da0ap-3;
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<16>()<=5){
return 0x1.18548a9bcfd4cp+0;
}else{
return 0x1.84c271fff79c8p-1;
}
}
}
}else{
if(r.integer<7>()<=46){
if(r.integer<19>()<=77){
if(r.integer<20>()<=94){
if(r.integer<15>()<=5){
if(r.integer<0>()<=1818){
if(r.integer<31>()<=8149){
return 0x0.0p+0;
}else{
return -0x1.bbcf4e874c900p-3;
}
}else{
if(r.integer<0>()<=1917){
return 0x1.4f8b588e368f3p-11;
}else{
return -0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.fddebd9018e74p-4;
}
}else{
if(r.integer<5>()<=27){
return 0x0.0p+0;
}else{
return -0x1.9652bd3c3611ap-4;
}
}
}else{
if(r.integer<3>()<=88){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8706){
if(r.integer<0>()<=1737){
return -0x1.3a92a30553262p-8;
}else{
if(r.integer<20>()<=23){
return 0x1.1d8e864020818p+0;
}else{
if(r.integer<33>()<=6){
return 0x1.5810624dd2f1bp-2;
}else{
return -0x1.6f0068db8bacdp-6;
}
}
}
}else{
return -0x1.d7dbf487fcb92p-6;
}
}
}
}
}
}
}
}else{
if(r.integer<4>()<=3){
return 0x1.a36e2eb1c432fp-8;
}else{
if(r.integer<20>()<=69){
if(r.integer<20>()<=49){
if(r.integer<19>()<=49){
if(r.integer<19>()<=44){
if(r.integer<54>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=97){
return -0x1.2d77318fc5048p-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=21){
if(r.integer<3>()<=89){
if(r.integer<43>()<=3){
if(r.integer<32>()<=5){
if(r.integer<33>()<=5){
return 0x1.35a858793dd98p-2;
}else{
return -0x1.a36e2eb1c432cp-6;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
return -0x1.4f8b588e368f0p-6;
}
}else{
if(r.integer<39>()<=-2){
return -0x1.07b784662bae1p-4;
}else{
if(r.integer<19>()<=65){
return 0x1.475a31a4bdba1p+0;
}else{
return 0x1.bd1ed9dfdac67p-5;
}
}
}
}else{
if(r.integer<51>()<=-37){
if(r.integer<23>()<=41){
if(r.integer<31>()<=7682){
return -0x1.9b90ea9e6eeb7p-3;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.26e978d4fdf3cp-4;
}
}else{
if(r.integer<14>()<=8){
return 0x0.0p+0;
}else{
return 0x1.cd5f99c38b04cp-9;
}
}
}
}
}else{
if(r.integer<19>()<=18){
if(r.integer<1>()<=89){
if(r.integer<20>()<=59){
if(r.integer<6>()<=46){
return 0x0.0p+0;
}else{
return 0x1.a9fbe76c8b43ap-2;
}
}else{
if(r.integer<14>()<=6){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
return 0x1.bf727136a4010p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=37){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=98){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=9495){
return -0x1.1dbca9691a75dp-5;
}else{
if(r.integer<6>()<=40){
return 0x1.0624dd2f1a9fdp-7;
}else{
return -0x1.b866e43aa79bcp-6;
}
}
}
}
}
}
}
}else{
if(r.integer<20>()<=1){
return -0x1.d269595feda67p+2;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=284){
if(r.integer<0>()<=1834){
if(r.integer<50>()<=-30){
if(r.integer<51>()<=57){
if(r.integer<55>()<=3){
return 0x0.0p+0;
}else{
return 0x1.4f8b588e368f3p-11;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=57){
if(r.integer<50>()<=36){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=95){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=2){
if(r.integer<26>()<=269){
return 0x0.0p+0;
}else{
return 0x1.0000000000000p+0;
}
}else{
if(r.integer<53>()<=97){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<52>()<=39){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=7882){
if(r.integer<19>()<=77){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=13607){
if(r.integer<6>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.a9fbe76c8b43ap-2;
}
}
}
}else{
if(r.integer<44>()<=0){
if(r.integer<10>()<=101){
return 0x1.44cbe1eb4202dp-4;
}else{
if(r.integer<29>()<=17){
return -0x1.0cb295e9e1b07p-4;
}else{
if(r.integer<19>()<=51){
return 0x1.de69ad42c3c9fp-3;
}else{
return -0x1.89374bc6a7efap-6;
}
}
}
}else{
if(r.integer<20>()<=97){
if(r.integer<3>()<=104){
return 0x1.3660e51d25aaap-8;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.26e978d4fdf3bp-4;
}
}
}
}
}else{
if(r.integer<1>()<=75){
if(r.integer<20>()<=52){
if(r.integer<7>()<=68){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=379){
return 0x1.4d72799a1fd27p-7;
}else{
return 0x1.633482be8bc17p-2;
}
}
}else{
if(r.integer<31>()<=8458){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=477){
if(r.integer<3>()<=73){
return 0x0.0p+0;
}else{
if(r.integer<23>()<=53){
if(r.integer<20>()<=84){
if(r.integer<8>()<=-58){
return -0x1.a36e2eb1c432dp-6;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
return -0x1.98f1d3ed527e4p-7;
}
}
}
}else{
if(r.integer<50>()<=26){
if(r.integer<44>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=39){
if(r.integer<52>()<=9){
if(r.integer<53>()<=4){
if(r.integer<31>()<=4991){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=13){
return 0x1.d750b5fdc7da0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=453){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=55){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<19>()<=12){
if(r.integer<31>()<=4884){
if(r.integer<30>()<=16){
return -0x1.01943fa6731b2p-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return -0x1.fd9ba1b1960fdp-7;
}else{
if(r.integer<6>()<=261){
if(r.integer<30>()<=9){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<30>()<=10){
if(r.integer<47>()<=-1){
if(r.integer<19>()<=72){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=6){
return 0x1.21ef73c0c1fc9p+3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=82){
if(r.integer<31>()<=4742){
return -0x1.e353f7ced916ap-2;
}else{
if(r.integer<23>()<=45){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1046){
return 0x1.3822d747efdbep+1;
}else{
if(r.integer<4>()<=386){
if(r.integer<3>()<=76){
return 0x0.0p+0;
}else{
return 0x1.5cfed3a299f9dp+1;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<0>()<=1670){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=12){
if(r.integer<25>()<=161){
if(r.integer<54>()<=5){
return 0x1.87160956c0d70p-1;
}else{
return -0x1.2d77318fc5048p-5;
}
}else{
return -0x1.355475a31a4bep-5;
}
}else{
return 0x1.ad42c3c9eecc0p-2;
}
}
}
}
}else{
if(r.integer<52>()<=29){
if(r.integer<27>()<=0){
if(r.integer<19>()<=80){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=32){
if(r.integer<51>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=3){
if(r.integer<53>()<=16){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
if(r.integer<2>()<=462){
if(r.integer<20>()<=63){
if(r.integer<3>()<=94){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=11205){
if(r.integer<6>()<=260){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=37){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=36){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=190){
return 0x1.999999999999ap-3;
}else{
return -0x1.205bc01a36e2fp-4;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=280){
if(r.integer<52>()<=7){
if(r.integer<7>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-60){
if(r.integer<47>()<=7){
if(r.integer<53>()<=95){
if(r.integer<43>()<=4){
if(r.integer<20>()<=72){
if(r.integer<30>()<=8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=40){
return 0x0.0p+0;
}else{
return 0x1.70a3d70a3d70bp-2;
}
}
}else{
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<30>()<=4){
if(r.integer<17>()<=3){
return 0x1.6b1c432ca57a7p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=28){
if(r.integer<30>()<=2){
if(r.integer<29>()<=13){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-48){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=39){
if(r.integer<2>()<=108){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=51){
return 0x0.0p+0;
}else{
if(r.integer<13>()<=0){
return 0x1.3333333333334p+0;
}else{
if(r.integer<47>()<=7){
if(r.integer<10>()<=47){
return 0x1.4f0d844d013a8p-1;
}else{
if(r.integer<4>()<=263){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=6835){
return 0x1.f7ced916872b0p-1;
}else{
return 0x1.2c27a63736ce0p-3;
}
}
}
}else{
if(r.integer<14>()<=6){
return 0x1.b5c7cd898b2eap-3;
}else{
return -0x1.eb851eb851ebap-4;
}
}
}
}
}
}else{
if(r.integer<33>()<=4){
if(r.integer<50>()<=35){
return 0x1.7f4128bf3bea7p-4;
}else{
if(r.integer<0>()<=2637){
return 0x1.999999999999ap-2;
}else{
if(r.integer<31>()<=14167){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return -0x1.35fc3b4f61673p-3;
}
}else{
return 0x1.6d0917d6b65a9p-2;
}
}
}
}else{
if(r.integer<23>()<=49){
if(r.integer<29>()<=15){
if(r.integer<20>()<=60){
if(r.integer<53>()<=79){
if(r.integer<8>()<=-54){
return -0x1.5e4a38327674dp-2;
}else{
if(r.integer<47>()<=7){
if(r.integer<0>()<=1867){
return 0x1.999999999999ap-1;
}else{
if(r.integer<0>()<=2060){
return -0x1.815a07b352a84p-5;
}else{
return 0x1.bc87db2b34614p-2;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.eb851eb851ebap-4;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<20>()<=76){
if(r.integer<31>()<=7514){
return 0x0.0p+0;
}else{
return 0x1.394317acc4ef7p-4;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<7>()<=54){
if(r.integer<6>()<=270){
if(r.integer<28>()<=0){
return -0x1.999999999999ap-3;
}else{
return -0x1.16872b020c49bp-2;
}
}else{
if(r.integer<2>()<=432){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<0>()<=2271){
return 0x1.ac9afe1da7b0ap-1;
}else{
return -0x1.1a543f1c7581ap-4;
}
}
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=5198){
if(r.integer<30>()<=9){
return 0x1.47ae147ae147ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=28){
if(r.integer<8>()<=39){
if(r.integer<5>()<=307){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7514){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<30>()<=3){
if(r.integer<20>()<=36){
if(r.integer<23>()<=45){
return 0x1.d0f840181e03fp+2;
}else{
return 0x1.6d1e108c3f3e0p+0;
}
}else{
return 0x1.b573eab367a10p-2;
}
}else{
if(r.integer<35>()<=4){
if(r.integer<2>()<=12){
return 0x1.e0370cdc8754fp-1;
}else{
if(r.integer<25>()<=58){
if(r.integer<51>()<=-45){
if(r.integer<20>()<=75){
if(r.integer<6>()<=263){
return -0x1.8bf7f06705c8ap-3;
}else{
return 0x1.3404ea4a8c155p-2;
}
}else{
return 0x1.1e646f1561912p+0;
}
}else{
if(r.integer<5>()<=378){
return -0x1.60956c0d6f546p-2;
}else{
return -0x1.61e4f765fd8b0p-5;
}
}
}else{
if(r.integer<10>()<=77){
return 0x1.c4113c68661adp-2;
}else{
if(r.integer<19>()<=19){
return 0x1.b7bf1e8e60807p-2;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return -0x1.148fd9fd36f80p-3;
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=5765){
if(r.integer<29>()<=7){
if(r.integer<44>()<=13){
if(r.integer<3>()<=75){
if(r.integer<38>()<=6){
if(r.integer<3>()<=74){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=63){
return 0x0.0p+0;
}else{
return -0x1.2d77318fc5049p-5;
}
}
}else{
if(r.integer<23>()<=40){
return 0x0.0p+0;
}else{
return 0x1.6666666666667p+0;
}
}
}else{
if(r.integer<3>()<=88){
if(r.integer<52>()<=4){
if(r.integer<29>()<=2){
if(r.integer<31>()<=3211){
return 0x1.52dba4d6e47dcp+3;
}else{
return -0x1.0624dd2f1a9e7p-4;
}
}else{
if(r.integer<31>()<=4121){
if(r.integer<3>()<=77){
return 0x1.1a176ddaceee0p+1;
}else{
return 0x1.2d5bab21815a0p+4;
}
}else{
return 0x1.d87724fa8b4bdp+2;
}
}
}else{
if(r.integer<14>()<=4){
if(r.integer<29>()<=3){
return 0x1.0a2339c0ebedfp+2;
}else{
return 0x1.26e978d4fdf3bp-2;
}
}else{
if(r.integer<36>()<=0){
if(r.integer<15>()<=6){
return -0x1.a9fbe76c8b43ap-4;
}else{
return 0x1.adea897635e75p-7;
}
}else{
if(r.integer<8>()<=-175){
if(r.integer<35>()<=3){
return 0x1.6c226809d4952p+1;
}else{
return 0x1.374bc6a7ef9dap-2;
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<8>()<=102){
return 0x1.355475a31a4bfp-4;
}else{
return -0x1.1148fd9fd36f8p-2;
}
}else{
return 0x1.70a3d70a3d70ap-2;
}
}
}
}
}
}else{
if(r.integer<17>()<=3){
if(r.integer<36>()<=9){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=4206){
return -0x1.16ebd4cfd08cdp-6;
}else{
if(r.integer<5>()<=280){
return 0x0.0p+0;
}else{
return 0x1.538ef34d6a162p+1;
}
}
}
}else{
if(r.integer<1>()<=89){
if(r.integer<53>()<=133){
if(r.integer<33>()<=9){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<3>()<=69){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=10){
return 0x1.61e4f765fd8aep+1;
}else{
if(r.integer<43>()<=2){
return 0x1.872b020c49ba6p+1;
}else{
if(r.integer<39>()<=-1){
return 0x1.978d4fdf3b646p+1;
}else{
if(r.integer<10>()<=144){
return -0x1.0624dd2f1a9fdp-1;
}else{
return 0x1.70a3d70a3d70ap-1;
}
}
}
}
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<43>()<=4){
if(r.integer<52>()<=28){
if(r.integer<53>()<=174){
if(r.integer<31>()<=4485){
if(r.integer<36>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-107){
if(r.integer<36>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<36>()<=10){
if(r.integer<31>()<=4777){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-176){
if(r.integer<31>()<=3371){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<36>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=3){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<5>()<=340){
if(r.integer<35>()<=4){
if(r.integer<8>()<=-108){
if(r.integer<6>()<=454){
if(r.integer<0>()<=4368){
if(r.integer<0>()<=2545){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=2){
if(r.integer<43>()<=1){
if(r.integer<6>()<=263){
return -0x1.999999999999ap-3;
}else{
if(r.integer<31>()<=9955){
if(r.integer<50>()<=-27){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.c28f5c28f5c2ap-2;
}
}
}else{
if(r.integer<43>()<=3){
if(r.integer<6>()<=274){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<33>()<=6){
if(r.integer<43>()<=1){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<35>()<=1){
if(r.integer<31>()<=9046){
if(r.integer<50>()<=-28){
return 0x0.0p+0;
}else{
return -0x1.28f5c28f5c28fp+0;
}
}else{
if(r.integer<50>()<=-49){
return -0x1.999999999999ap-1;
}else{
return -0x1.566cf41f212d8p+2;
}
}
}else{
if(r.integer<50>()<=14){
return -0x1.db22d0e56040dp-3;
}else{
if(r.integer<31>()<=10737){
if(r.integer<50>()<=49){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return -0x1.5c28f5c28f5c3p+0;
}
}
}
}
}else{
if(r.integer<0>()<=2653){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=2){
if(r.integer<36>()<=9){
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=20){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=75){
if(r.integer<6>()<=362){
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8781){
if(r.integer<51>()<=325){
return 0x0.0p+0;
}else{
return 0x1.d7dbf487fcb94p-6;
}
}else{
return -0x1.5810624dd2f1bp-2;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=8387){
if(r.integer<23>()<=31){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<29>()<=7){
if(r.integer<44>()<=13){
if(r.integer<54>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=58){
if(r.integer<9>()<=39){
if(r.integer<52>()<=25){
if(r.integer<52>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=146){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=6){
if(r.integer<51>()<=-110){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<3>()<=75){
if(r.integer<31>()<=8895){
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=13){
if(r.integer<31>()<=6868){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<23>()<=32){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=75){
return 0x0.0p+0;
}else{
return 0x1.d7dbf487fcb94p-7;
}
}
}
}
}else{
if(r.integer<50>()<=-42){
if(r.integer<8>()<=111){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<55>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<51>()<=-119){
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8491){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<35>()<=2){
if(r.integer<55>()<=4){
if(r.integer<50>()<=30){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=260){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=5){
if(r.integer<32>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=-96){
if(r.integer<39>()<=-7){
return -0x1.70a3d70a3d70bp-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<19>()<=51){
if(r.integer<29>()<=13){
if(r.integer<36>()<=18){
if(r.integer<38>()<=6){
if(r.integer<20>()<=49){
if(r.integer<51>()<=147){
if(r.integer<31>()<=7309){
if(r.integer<47>()<=7){
if(r.integer<17>()<=5){
if(r.integer<20>()<=41){
if(r.integer<19>()<=8){
return 0x1.48fd9fd36f7e4p-3;
}else{
return 0x1.141205bc01a37p+0;
}
}else{
if(r.integer<5>()<=149){
return 0x1.0d306a2b17050p+0;
}else{
return -0x1.91bc558644524p-3;
}
}
}else{
return 0x1.6fe2e6ea85448p+0;
}
}else{
return 0x1.04588a04d1202p+3;
}
}else{
if(r.integer<39>()<=0){
if(r.integer<19>()<=24){
if(r.integer<51>()<=126){
if(r.integer<50>()<=-88){
return 0x1.f1843c3a42f1fp-1;
}else{
return 0x1.8611fd5885d34p-4;
}
}else{
return 0x1.5c52e72da1230p-1;
}
}else{
return 0x1.6f0068db8bac7p-1;
}
}else{
if(r.integer<29>()<=1){
return 0x1.f3fe9fadafd12p+2;
}else{
if(r.integer<19>()<=11){
return 0x1.898b2e9ccb7d4p-2;
}else{
return 0x1.460aa64c2f838p+0;
}
}
}
}
}else{
if(r.integer<39>()<=-2){
if(r.integer<1>()<=93){
if(r.integer<1>()<=64){
return 0x0.0p+0;
}else{
return 0x1.ddcc63f141205p+2;
}
}else{
return 0x1.a6b50b0f27bb4p-2;
}
}else{
if(r.integer<19>()<=21){
if(r.integer<47>()<=-2){
if(r.integer<7>()<=-34){
return 0x1.758e219652bd4p-3;
}else{
return 0x1.76ea99694f49cp+2;
}
}else{
return 0x1.5e9e1b089a028p-2;
}
}else{
if(r.integer<55>()<=3){
if(r.integer<52>()<=53){
return 0x1.63886594af4f0p-1;
}else{
return -0x1.d7dbf487fcb92p-5;
}
}else{
if(r.integer<44>()<=16){
if(r.integer<55>()<=10){
return -0x1.1d14e3bcd35a8p-3;
}else{
return 0x1.eecbfb15b573dp-3;
}
}else{
return 0x1.1d68c692f6e83p-2;
}
}
}
}
}
}else{
if(r.integer<26>()<=71){
return -0x1.54c985f06f69ap-6;
}else{
if(r.integer<53>()<=129){
if(r.integer<26>()<=157){
if(r.integer<20>()<=90){
if(r.integer<3>()<=45){
return -0x1.59b3d07c84b5dp-2;
}else{
return 0x1.148fd9fd36f73p-4;
}
}else{
return 0x1.28f5c28f5c28fp+0;
}
}else{
if(r.integer<31>()<=4485){
return -0x1.89374bc6a7efdp-3;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
if(r.integer<29>()<=1){
if(r.integer<39>()<=-1){
if(r.integer<2>()<=233){
return 0x1.366277c45cbbcp+3;
}else{
return 0x1.32ca57a786c23p+1;
}
}else{
if(r.integer<8>()<=132){
if(r.integer<39>()<=0){
return 0x1.999999999999ap-1;
}else{
return 0x1.85d8d79d0a677p+3;
}
}else{
if(r.integer<36>()<=6){
return 0x1.0678c0053e2d3p-2;
}else{
return -0x1.88e368f084620p-2;
}
}
}
}else{
if(r.integer<4>()<=267){
if(r.integer<6>()<=37){
return 0x1.47ae147ae147ap-4;
}else{
return 0x1.1f2dc2b0ea183p-1;
}
}else{
return 0x1.78d4fdf3b645bp-3;
}
}
}
}
}
}else{
if(r.integer<3>()<=100){
if(r.integer<52>()<=12){
return -0x1.89374bc6a7efap-4;
}else{
if(r.integer<44>()<=17){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.fbe76c8b4395ap-2;
}
}
}else{
if(r.integer<1>()<=65){
return 0x0.0p+0;
}else{
return -0x1.6b11c6d1e108dp-4;
}
}
}
}else{
if(r.integer<29>()<=9){
if(r.integer<7>()<=15){
if(r.integer<24>()<=40){
return -0x1.37f38c5436b90p-4;
}else{
return -0x1.1a543f1c75819p-4;
}
}else{
return 0x1.b328b6d86ec18p-4;
}
}else{
return 0x1.23a29c779a6b5p-3;
}
}
}else{
if(r.integer<30>()<=9){
if(r.integer<20>()<=49){
if(r.integer<46>()<=-1){
if(r.integer<50>()<=31){
return 0x1.1eb851eb851ebp-2;
}else{
return -0x1.758e219652bd4p-4;
}
}else{
if(r.integer<44>()<=16){
if(r.integer<35>()<=2){
if(r.integer<5>()<=351){
return -0x1.a36e2eb1c4334p-10;
}else{
if(r.integer<4>()<=325){
return 0x1.16d2aa5c5f7c7p-1;
}else{
if(r.integer<19>()<=37){
return 0x1.18d25edd05293p-2;
}else{
return -0x1.16872b020c49bp-3;
}
}
}
}else{
if(r.integer<51>()<=-191){
if(r.integer<43>()<=5){
return 0x1.14057082491afp+0;
}else{
return 0x1.e1d2178f68be4p-5;
}
}else{
return 0x1.3f7ced916872cp-2;
}
}
}else{
if(r.integer<30>()<=1){
return 0x1.2999dcb5781c7p+3;
}else{
return 0x1.4083126e978d5p+1;
}
}
}
}else{
if(r.integer<20>()<=87){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-137){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=111){
if(r.integer<19>()<=10){
if(r.integer<39>()<=-7){
return -0x1.31876188b1140p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=16087){
if(r.integer<20>()<=25){
if(r.integer<39>()<=-1){
return 0x1.d7dbf487fcb90p-7;
}else{
if(r.integer<52>()<=106){
return 0x1.1d14e3bcd35a8p-2;
}else{
return 0x1.cf4e874c8ffbap-1;
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<1>()<=107){
if(r.integer<35>()<=2){
if(r.integer<5>()<=345){
if(r.integer<0>()<=6159){
return 0x0.0p+0;
}else{
return -0x1.f333333333334p+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
return 0x1.ff2e48e8a71e0p-5;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=4){
if(r.integer<5>()<=460){
if(r.integer<43>()<=6){
if(r.integer<8>()<=90){
if(r.integer<7>()<=-43){
return 0x1.6666666666667p+0;
}else{
if(r.integer<19>()<=34){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
return -0x1.ea35935fc3b50p-5;
}
}else{
if(r.integer<35>()<=1){
if(r.integer<5>()<=345){
return -0x1.3c9abb01c92dfp-2;
}else{
return 0x1.a9fbe76c8b43ap-4;
}
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=63){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return -0x1.98c7e28240b78p-1;
}
}
}else{
if(r.integer<19>()<=24){
if(r.integer<20>()<=28){
return -0x1.a36e2eb1c4334p-10;
}else{
if(r.integer<50>()<=-79){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return 0x1.d7dbf487fcb92p-7;
}
}
}
}else{
if(r.integer<50>()<=-82){
return -0x1.4af4f0d844d02p-3;
}else{
if(r.integer<20>()<=38){
return -0x1.a36e2eb1c4334p-10;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=17){
if(r.integer<46>()<=-1){
if(r.integer<1>()<=74){
if(r.integer<31>()<=3939){
return -0x1.65d3996fa82e8p-4;
}else{
return -0x1.ff2e48e8a71dfp-5;
}
}else{
return 0x1.eb851eb851eb8p-4;
}
}else{
if(r.integer<44>()<=16){
if(r.integer<10>()<=142){
if(r.integer<15>()<=3){
return -0x1.a36e2eb1c432cp-5;
}else{
return 0x1.3a92a30553267p-8;
}
}else{
if(r.integer<25>()<=68){
return 0x0.0p+0;
}else{
return 0x1.ca7d6733ebbfdp-4;
}
}
}else{
if(r.integer<30>()<=2){
return 0x1.dd712a0ec7430p+2;
}else{
if(r.integer<5>()<=335){
return 0x1.999999999999ap-3;
}else{
return 0x1.be76c8b439582p-1;
}
}
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<35>()<=0){
if(r.integer<8>()<=-123){
if(r.integer<36>()<=0){
if(r.integer<33>()<=5){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return -0x1.a36e2eb1c432ap-8;
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.6872b020c49bap-4;
}
}else{
if(r.integer<36>()<=3){
return 0x0.0p+0;
}else{
return 0x1.3a92a30553262p-5;
}
}
}else{
if(r.integer<23>()<=31){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<50>()<=-89){
return -0x1.999999999999ap-3;
}else{
if(r.integer<51>()<=120){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.22fad6cb53501p-2;
}
}
}
}else{
if(r.integer<52>()<=39){
if(r.integer<6>()<=62){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}
}else{
if(r.integer<20>()<=84){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_6(const BudgetResidualFeatures&r){
if(r.integer<53>()<=99){
if(r.integer<44>()<=13){
if(r.integer<31>()<=6801){
if(r.integer<53>()<=59){
if(r.integer<0>()<=852){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=0){
if(r.integer<31>()<=5566){
return 0x0.0p+0;
}else{
return 0x1.dc4537bf6cbfap-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=27){
if(r.integer<0>()<=1365){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=85){
if(r.integer<31>()<=5468){
return 0x1.4cec41dd1a220p-5;
}else{
if(r.integer<19>()<=22){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=92){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=433){
if(r.integer<23>()<=43){
return 0x0.0p+0;
}else{
return 0x1.6b11c6d1e108dp-1;
}
}else{
return -0x1.eb851eb851ebap-4;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=2631){
if(r.integer<30>()<=3){
return -0x1.a654f681eebb5p-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=284){
if(r.integer<29>()<=10){
if(r.integer<19>()<=87){
if(r.integer<46>()<=1){
if(r.integer<50>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=272){
return 0x0.0p+0;
}else{
return 0x1.6331a6c91a4c0p-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<30>()<=13){
return 0x1.5eb7457c0b135p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=48){
return 0x0.0p+0;
}else{
return -0x1.43bf727136a40p-4;
}
}
}
}
}
}else{
if(r.integer<5>()<=284){
if(r.integer<6>()<=95){
if(r.integer<7>()<=36){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=4){
if(r.integer<7>()<=30){
if(r.integer<14>()<=4){
if(r.integer<50>()<=23){
return 0x0.0p+0;
}else{
return 0x1.f752b2547b827p-1;
}
}else{
if(r.integer<17>()<=6){
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<4>()<=257){
return 0x1.70a3d70a3d70bp-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<14>()<=4){
return -0x1.b66f9335d24a4p-3;
}else{
return 0x1.cac083126e977p-5;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<7>()<=-38){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=-57){
if(r.integer<20>()<=49){
if(r.integer<2>()<=99){
if(r.integer<3>()<=22){
return 0x1.4f8b588e368f3p-11;
}else{
if(r.integer<31>()<=8563){
return -0x1.cd44c1d0f047fp-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=15121){
if(r.integer<50>()<=-73){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=49){
if(r.integer<1>()<=73){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=102){
if(r.integer<36>()<=13){
if(r.integer<20>()<=96){
return 0x1.93ab430f49492p-1;
}else{
return -0x1.526d8b1dd5d40p-4;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<46>()<=0){
if(r.integer<6>()<=453){
if(r.integer<54>()<=3){
if(r.integer<0>()<=2561){
return 0x1.0624dd2f1a9fdp-7;
}else{
if(r.integer<17>()<=7){
return 0x1.387160956c0d8p-1;
}else{
return -0x1.59d2036d72ca3p-6;
}
}
}else{
if(r.integer<26>()<=58){
return -0x1.cb6192c20f03cp-3;
}else{
return -0x1.1d3671ac14c67p-7;
}
}
}else{
if(r.integer<20>()<=54){
return 0x1.3ce2df5dc9090p+0;
}else{
if(r.integer<10>()<=61){
return 0x1.3293d102bc72fp-3;
}else{
return 0x1.7e711f270cb44p-1;
}
}
}
}else{
return 0x1.0fa73cf04b572p-1;
}
}
}
}else{
if(r.integer<3>()<=18){
if(r.integer<53>()<=83){
return 0x0.0p+0;
}else{
return -0x1.f09b082ea2aaap-11;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=-40){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=4){
if(r.integer<51>()<=-39){
if(r.integer<20>()<=36){
if(r.integer<50>()<=76){
if(r.integer<30>()<=8){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=5){
if(r.integer<5>()<=417){
return 0x1.be76c8b439582p-1;
}else{
return 0x1.84bf1701a444fp+0;
}
}else{
if(r.integer<6>()<=54){
return -0x1.98d6fbfab7c20p-5;
}else{
return 0x1.0247021d10b20p+0;
}
}
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<13>()<=0){
return 0x1.7bb73083558a8p-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<15>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=153){
if(r.integer<3>()<=111){
return 0x0.0p+0;
}else{
return -0x1.88a3a81054e20p-4;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<0>()<=2530){
return 0x1.30f99d0f6fdf8p+0;
}else{
return 0x1.40ae45f908950p-2;
}
}
}else{
if(r.integer<1>()<=36){
if(r.integer<51>()<=-47){
if(r.integer<20>()<=94){
if(r.integer<33>()<=6){
if(r.integer<19>()<=35){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=25){
if(r.integer<29>()<=8){
if(r.integer<9>()<=35){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=1737){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<35>()<=1){
if(r.integer<24>()<=19){
if(r.integer<1>()<=62){
if(r.integer<31>()<=11277){
return -0x1.03d64e55ce68bp-6;
}else{
if(r.integer<36>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=7){
return -0x1.d7dbf487fcb95p-6;
}else{
return 0x1.561fc745a44f0p-3;
}
}
}
}else{
if(r.integer<5>()<=373){
if(r.integer<29>()<=5){
if(r.integer<8>()<=51){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3feba85a26bcdp-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=79){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=49){
if(r.integer<23>()<=32){
return 0x1.d323fee2c98e7p-3;
}else{
return 0x1.cbfb15b573eacp+0;
}
}else{
return 0x1.4841b83134557p-4;
}
}
}
}
}
}else{
if(r.integer<4>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<51>()<=-62){
if(r.integer<20>()<=34){
if(r.integer<7>()<=66){
return 0x0.0p+0;
}else{
return 0x1.50c366f27d608p-1;
}
}else{
if(r.integer<20>()<=88){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<26>()<=237){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=36){
return 0x0.0p+0;
}else{
if(r.integer<16>()<=0){
return -0x1.585a3428fc78ap-5;
}else{
return -0x1.a36e2eb1c432dp-6;
}
}
}
}
}
}
}
}
}else{
if(r.integer<52>()<=7){
if(r.integer<5>()<=286){
if(r.integer<31>()<=4031){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-70){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=279){
if(r.integer<6>()<=265){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=42){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<8>()<=-44){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=4077){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=43){
if(r.integer<52>()<=29){
if(r.integer<13>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<28>()<=0){
if(r.integer<20>()<=89){
if(r.integer<19>()<=90){
if(r.integer<5>()<=439){
if(r.integer<10>()<=47){
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<54>()<=3){
if(r.integer<1>()<=53){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=114){
return -0x1.999999999999ap-3;
}else{
return 0x1.e7967caea7480p-6;
}
}
}else{
if(r.integer<23>()<=53){
return 0x0.0p+0;
}else{
return -0x1.57689ca18bd67p-4;
}
}
}
}else{
return 0x1.1eb851eb851ebp-2;
}
}else{
if(r.integer<3>()<=39){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=62){
return -0x1.00a393ee5eedfp-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=72){
if(r.integer<39>()<=0){
if(r.integer<31>()<=7550){
return 0x1.5ca6ca03c4b0dp-2;
}else{
if(r.integer<0>()<=1867){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-1;
}
}
}else{
return -0x1.f53825e13b18cp-7;
}
}else{
return 0x1.2b020c49ba5e3p+0;
}
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-35){
return 0x1.ff0c19e9b611ap+2;
}else{
if(r.integer<29>()<=15){
return 0x1.4b8b10092ad15p+1;
}else{
if(r.integer<20>()<=95){
return -0x1.4e3bcd35a8585p-4;
}else{
return 0x1.8ac556f88bd74p+2;
}
}
}
}
}
}else{
if(r.integer<20>()<=63){
if(r.integer<2>()<=462){
if(r.integer<3>()<=94){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=47){
if(r.integer<20>()<=49){
if(r.integer<10>()<=21){
return 0x0.0p+0;
}else{
return -0x1.0624dd2f1a9fbp-6;
}
}else{
if(r.integer<6>()<=279){
if(r.integer<7>()<=50){
return 0x1.ee78183f91e64p-1;
}else{
return -0x1.f212d77318fc5p-4;
}
}else{
return 0x1.1b994e1a3f467p+3;
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<43>()<=0){
return -0x1.89374bc6a7efap-4;
}else{
return 0x1.6872b020c49bbp-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<53>()<=59){
if(r.integer<52>()<=28){
if(r.integer<31>()<=4920){
if(r.integer<30>()<=7){
if(r.integer<8>()<=45){
return 0x0.0p+0;
}else{
return 0x1.13f7ced916873p+2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=66){
if(r.integer<5>()<=97){
if(r.integer<26>()<=164){
if(r.integer<6>()<=270){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.47ae147ae147cp-2;
}
}else{
if(r.integer<19>()<=21){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<36>()<=7){
return 0x1.714b9cb6848bfp-2;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}
}else{
if(r.integer<3>()<=77){
if(r.integer<9>()<=42){
if(r.integer<5>()<=274){
if(r.integer<51>()<=-62){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=56){
if(r.integer<1>()<=78){
return 0x0.0p+0;
}else{
return -0x1.1be6e653868fep-4;
}
}else{
if(r.integer<1>()<=76){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=78){
return 0x0.0p+0;
}else{
return 0x1.7bb2fec56d5d0p+0;
}
}
}
}
}else{
if(r.integer<3>()<=11){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<4>()<=120){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<23>()<=27){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=477){
if(r.integer<30>()<=1){
return 0x1.a5e353f7ced90p+1;
}else{
return 0x1.999999999999ap-3;
}
}else{
return -0x1.13404ea4a8c16p-5;
}
}
}
}
}else{
if(r.integer<8>()<=54){
if(r.integer<31>()<=3211){
return -0x1.a858793dd97f7p-2;
}else{
if(r.integer<26>()<=18){
return 0x1.054ac29bf162bp+0;
}else{
if(r.integer<36>()<=18){
if(r.integer<9>()<=18){
return 0x1.14bf0995aaf79p+2;
}else{
if(r.integer<26>()<=102){
return 0x1.d495182a9930cp-3;
}else{
if(r.integer<47>()<=7){
if(r.integer<51>()<=-51){
if(r.integer<30>()<=6){
if(r.integer<13>()<=0){
return -0x1.d0fa58f7121acp-2;
}else{
if(r.integer<2>()<=237){
return -0x1.78d4fdf3b645ap-2;
}else{
return 0x1.8a86d71f36264p-3;
}
}
}else{
if(r.integer<25>()<=77){
return -0x1.9c17225b749adp-5;
}else{
return 0x1.5810624dd2f1ap-2;
}
}
}else{
if(r.integer<15>()<=6){
if(r.integer<31>()<=9410){
if(r.integer<2>()<=192){
return 0x1.74f3c7e359000p-3;
}else{
return 0x1.d7b2031ceaf25p+0;
}
}else{
return 0x1.d9b86d9a374e4p-2;
}
}else{
if(r.integer<31>()<=8706){
return -0x1.36a400fba8827p-2;
}else{
return 0x1.2fcac8e68e3efp-1;
}
}
}
}else{
if(r.integer<30>()<=9){
if(r.integer<20>()<=50){
if(r.integer<29>()<=8){
return 0x1.1b2d4d4024b34p+2;
}else{
return 0x1.13a8a3f8982cbp+3;
}
}else{
if(r.integer<16>()<=3){
return 0x1.19299cb17c0e7p-1;
}else{
return -0x1.c193b3a68b19dp-4;
}
}
}else{
return 0x1.92641b328b6d8p-2;
}
}
}
}
}else{
if(r.integer<13>()<=7){
return -0x1.1361dc93ea2d3p-3;
}else{
return 0x1.f00abf76a2f48p-2;
}
}
}
}
}else{
if(r.integer<30>()<=3){
if(r.integer<47>()<=-1){
if(r.integer<20>()<=49){
return 0x1.f10c11863a414p+2;
}else{
return 0x1.00e6afcce1c5ap-5;
}
}else{
if(r.integer<17>()<=0){
return -0x1.f3b645a1cac0ap-2;
}else{
if(r.integer<20>()<=51){
return -0x1.43e963dc486afp+0;
}else{
return 0x1.5c52e72da1230p-2;
}
}
}
}else{
if(r.integer<19>()<=18){
if(r.integer<3>()<=44){
return 0x1.cb6ba3bd090a5p-1;
}else{
if(r.integer<35>()<=5){
if(r.integer<0>()<=2242){
if(r.integer<26>()<=76){
return 0x1.57eaa2a0a9580p+0;
}else{
return 0x1.ef62f9ca5bd95p-1;
}
}else{
return -0x1.5ca6ca03c4b0ap-5;
}
}else{
return -0x1.50dae3e6c4c5cp-3;
}
}
}else{
if(r.integer<20>()<=73){
if(r.integer<43>()<=0){
return -0x1.6c53e63121e10p-3;
}else{
if(r.integer<43>()<=5){
if(r.integer<20>()<=30){
if(r.integer<24>()<=16){
return 0x1.00cbd7da4708bp-2;
}else{
return -0x1.7aa40b0ca37c7p-4;
}
}else{
if(r.integer<3>()<=42){
if(r.integer<19>()<=77){
if(r.integer<31>()<=13204){
return -0x1.e98dcdb37c99ap-3;
}else{
return 0x1.cad4a50862a50p-3;
}
}else{
return 0x1.186a5a10ed8e1p-1;
}
}else{
return 0x1.96597338dcc07p-2;
}
}
}else{
if(r.integer<1>()<=51){
return -0x1.d1d4738a3b57dp-3;
}else{
return 0x1.dd4fd1cf6b0cdp-5;
}
}
}
}else{
if(r.integer<1>()<=54){
return -0x1.eff9f87f023eap-4;
}else{
if(r.integer<26>()<=260){
if(r.integer<35>()<=6){
return -0x1.54c985f06f69ap-6;
}else{
return -0x1.ac79702e6644dp-2;
}
}else{
return 0x1.96d0917d6b65ap-1;
}
}
}
}
}
}
}
}
}
}
}else{
if(r.integer<3>()<=75){
if(r.integer<1>()<=75){
if(r.integer<31>()<=6267){
if(r.integer<43>()<=4){
if(r.integer<52>()<=28){
if(r.integer<36>()<=10){
if(r.integer<10>()<=176){
if(r.integer<31>()<=4121){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=16){
if(r.integer<53>()<=107){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=148){
if(r.integer<35>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<31>()<=4634){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=-104){
if(r.integer<31>()<=3570){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5666){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<5>()<=139){
if(r.integer<52>()<=54){
if(r.integer<31>()<=10214){
if(r.integer<52>()<=15){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8670){
if(r.integer<1>()<=25){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-161){
if(r.integer<3>()<=24){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<51>()<=150){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<1>()<=73){
return -0x1.4bc6a7ef9db24p+0;
}else{
if(r.integer<38>()<=0){
return -0x1.2e536501e2583p+1;
}else{
return 0x1.28f5c28f5c28fp+0;
}
}
}
}else{
if(r.integer<31>()<=10491){
if(r.integer<53>()<=137){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=90){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=2){
if(r.integer<9>()<=64){
return -0x1.2b020c49ba5e3p+0;
}else{
return -0x1.0624dd2f1a9fdp-7;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<2>()<=144){
if(r.integer<6>()<=362){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-1){
if(r.integer<8>()<=-117){
if(r.integer<35>()<=2){
if(r.integer<23>()<=46){
return -0x1.2b020c49ba5e3p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=46){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<4>()<=69){
if(r.integer<1>()<=15){
if(r.integer<38>()<=6){
if(r.integer<31>()<=8216){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.999999999999ap-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<9>()<=41){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<19>()<=49){
if(r.integer<1>()<=93){
if(r.integer<38>()<=-2){
if(r.integer<6>()<=142){
return 0x1.a6c92d051bc80p-9;
}else{
return -0x1.4ec204f2ae07fp-4;
}
}else{
if(r.integer<38>()<=1){
if(r.integer<14>()<=4){
if(r.integer<5>()<=269){
if(r.integer<5>()<=14){
return 0x1.00dbc81252e8ep+0;
}else{
return 0x1.60fb57fa92d8cp+2;
}
}else{
return 0x1.dfb9389b52007p-1;
}
}else{
if(r.integer<6>()<=141){
return 0x1.172ef0ae53640p-4;
}else{
if(r.integer<5>()<=383){
return 0x1.0941c8216c615p+0;
}else{
return 0x1.511dffc5479cdp-5;
}
}
}
}else{
if(r.integer<10>()<=127){
return -0x1.fd0eb3f7e9b14p-2;
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<5>()<=466){
if(r.integer<8>()<=96){
if(r.integer<43>()<=4){
if(r.integer<39>()<=-1){
if(r.integer<19>()<=19){
return -0x1.2f1a9fbe76c8bp-2;
}else{
if(r.integer<6>()<=420){
if(r.integer<35>()<=2){
return -0x1.f623076c050bap-3;
}else{
if(r.integer<51>()<=-110){
return 0x1.ed5ae1cde5d18p-3;
}else{
return 0x1.e76c8b4395810p-1;
}
}
}else{
return 0x1.61f76bdcc7ecap-1;
}
}
}else{
if(r.integer<42>()<=128){
if(r.integer<20>()<=34){
if(r.integer<5>()<=14){
return -0x1.5a228b4543004p-2;
}else{
return 0x1.1098d477bbf96p-1;
}
}else{
if(r.integer<5>()<=345){
if(r.integer<6>()<=258){
if(r.integer<35>()<=3){
if(r.integer<43>()<=1){
return -0x1.6153012ed428fp-1;
}else{
return -0x1.cffeb074a7720p-5;
}
}else{
if(r.integer<43>()<=2){
return 0x1.3333333333334p-1;
}else{
return -0x1.95feda661283ap-2;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=373){
if(r.integer<1>()<=108){
return 0x1.20b8dd2bbfa17p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=89){
if(r.integer<3>()<=13){
return 0x1.ba5e353f7cedap-2;
}else{
if(r.integer<14>()<=2){
return 0x1.6872b020c49bap-4;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
return 0x1.2ca57a786c227p-1;
}
}
}
}
}else{
if(r.integer<35>()<=0){
if(r.integer<5>()<=423){
return 0x1.6872b020c49bcp-3;
}else{
return 0x1.bc6a7ef9db22dp+0;
}
}else{
if(r.integer<5>()<=152){
return 0x1.ccccccccccccdp+0;
}else{
return 0x1.7b0f6ad70e6f4p-5;
}
}
}
}
}else{
if(r.integer<19>()<=18){
if(r.integer<39>()<=0){
return 0x1.22aa4ef3831b3p-6;
}else{
return 0x1.44a1f080303c0p+0;
}
}else{
if(r.integer<35>()<=3){
if(r.integer<43>()<=5){
if(r.integer<5>()<=367){
return 0x1.55ac03ff69015p+1;
}else{
if(r.integer<5>()<=411){
return -0x1.ce075f6fd2200p-3;
}else{
return 0x1.26bf8769ec2cfp+1;
}
}
}else{
if(r.integer<35>()<=1){
if(r.integer<5>()<=433){
if(r.integer<32>()<=3){
return 0x1.e52157689ca1ap-1;
}else{
return 0x1.f75104d551d67p-6;
}
}else{
return 0x1.b1c432ca57a78p+0;
}
}else{
return 0x1.04189374bc6a8p+1;
}
}
}else{
if(r.integer<5>()<=33){
return 0x1.9945b6c3760c0p+0;
}else{
return -0x1.3fd0d0678c007p-4;
}
}
}
}
}else{
if(r.integer<19>()<=30){
if(r.integer<43>()<=5){
if(r.integer<43>()<=3){
if(r.integer<6>()<=373){
if(r.integer<43>()<=0){
return 0x1.3b3a68b19a416p-2;
}else{
if(r.integer<35>()<=3){
if(r.integer<5>()<=362){
return -0x1.b866e43aa79bdp-6;
}else{
if(r.integer<5>()<=417){
return 0x1.f6fd21ff2e48fp-2;
}else{
if(r.integer<5>()<=455){
return -0x1.02363b256ffc1p-4;
}else{
return 0x1.12ec6bce8533bp+0;
}
}
}
}else{
return 0x1.3333333333334p-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=-1){
return -0x1.e4a38327674d2p-2;
}else{
return -0x1.32b55ef1fddf3p-5;
}
}
}else{
if(r.integer<6>()<=262){
if(r.integer<19>()<=24){
return 0x1.28e0c9d9d3459p-2;
}else{
return -0x1.5b573eab3679ap-4;
}
}else{
return 0x1.6b54e2b063e08p-1;
}
}
}else{
if(r.integer<39>()<=-7){
return 0x1.dbca9691a75cdp-3;
}else{
if(r.integer<35>()<=1){
return 0x0.0p+0;
}else{
return -0x1.60956c0d6f545p-4;
}
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<3>()<=62){
return -0x1.5f45e0b4e11dcp-5;
}else{
return 0x1.dde37585be1a7p-4;
}
}else{
if(r.integer<20>()<=56){
if(r.integer<43>()<=4){
return 0x1.ce3150dae3e6dp-1;
}else{
return -0x1.16872b020c49cp-3;
}
}else{
return -0x1.2599ed7c6fbd3p-5;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<43>()<=0){
if(r.integer<55>()<=3){
if(r.integer<31>()<=11571){
return 0x1.ad6451b93037ap-4;
}else{
return -0x1.0624dd2f1a9fdp-7;
}
}else{
return -0x1.22dffed8b8933p-5;
}
}else{
if(r.integer<20>()<=49){
if(r.integer<43>()<=3){
if(r.integer<6>()<=272){
return 0x1.debd9018e7578p-2;
}else{
return 0x1.2ce032db1e9f3p+0;
}
}else{
if(r.integer<35>()<=6){
return -0x1.06c947dd0e638p-2;
}else{
return 0x1.4dbdf8f473040p-1;
}
}
}else{
if(r.integer<8>()<=-135){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.48fd9fd36f7e5p-4;
}
}
}
}else{
if(r.integer<50>()<=-80){
return -0x1.88e368f084620p-2;
}else{
if(r.integer<1>()<=99){
if(r.integer<5>()<=149){
if(r.integer<5>()<=53){
if(r.integer<8>()<=132){
return 0x1.b13165d3996fap-2;
}else{
return -0x1.714b9cb6848c0p-2;
}
}else{
return 0x1.1212513b5bf6ap-1;
}
}else{
return -0x1.c3b9fe93ef35cp-5;
}
}else{
if(r.integer<51>()<=105){
if(r.integer<1>()<=103){
return -0x1.a3f4666ec9e27p-3;
}else{
if(r.integer<20>()<=52){
if(r.integer<50>()<=-40){
return -0x1.0624dd2f1a9fbp-4;
}else{
return 0x1.90b3410a8c4b0p-2;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<5>()<=466){
if(r.integer<35>()<=4){
if(r.integer<35>()<=0){
if(r.integer<8>()<=93){
if(r.integer<19>()<=82){
if(r.integer<50>()<=-9){
if(r.integer<43>()<=2){
if(r.integer<6>()<=145){
return -0x1.10a137f38c543p-7;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.a58f7121ab4b7p-1;
}
}else{
if(r.integer<8>()<=-135){
return 0x0.0p+0;
}else{
return -0x1.a36e2eb1c4334p-9;
}
}
}else{
if(r.integer<5>()<=433){
if(r.integer<5>()<=383){
if(r.integer<5>()<=335){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=73){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.0624dd2f1a9fdp-6;
}
}else{
if(r.integer<3>()<=64){
return 0x0.0p+0;
}else{
return 0x1.205bc01a36e2fp-4;
}
}
}
}else{
if(r.integer<19>()<=97){
if(r.integer<0>()<=5105){
if(r.integer<1>()<=79){
return 0x0.0p+0;
}else{
if(r.integer<46>()<=1){
return 0x0.0p+0;
}else{
return -0x1.3d244dbd2234fp-4;
}
}
}else{
return -0x1.0cb295e9e1b09p-4;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<43>()<=0){
if(r.integer<7>()<=-38){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=95){
return 0x0.0p+0;
}else{
return 0x1.0f2968af1602ap-1;
}
}
}else{
if(r.integer<5>()<=36){
if(r.integer<7>()<=-36){
return 0x1.16872b020c49bp-2;
}else{
return 0x1.703afb7e90ffap+0;
}
}else{
if(r.integer<31>()<=8670){
if(r.integer<50>()<=-4){
return 0x1.47ae147ae147cp-2;
}else{
return -0x1.230fcf80dc338p+0;
}
}else{
if(r.integer<7>()<=-73){
return 0x1.5810624dd2f1cp-3;
}else{
if(r.integer<6>()<=264){
return -0x1.204e5420e984dp-4;
}else{
return 0x1.eb851eb851eb8p-4;
}
}
}
}
}
}else{
if(r.integer<50>()<=-91){
return -0x1.020c49ba5e354p-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<44>()<=10){
if(r.integer<3>()<=63){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<0>()<=3268){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<3>()<=91){
if(r.integer<52>()<=5){
if(r.integer<30>()<=4){
if(r.integer<30>()<=1){
if(r.integer<39>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=1){
return -0x1.26e978d4fdf3fp-4;
}else{
if(r.integer<31>()<=3789){
return 0x1.668e3ef284168p+3;
}else{
if(r.integer<19>()<=32){
return -0x1.5b573eab367a1p-4;
}else{
if(r.integer<6>()<=152){
return -0x1.b43526527a207p-6;
}else{
return 0x1.bde3fbbd7b204p+2;
}
}
}
}
}
}else{
if(r.integer<31>()<=6103){
if(r.integer<31>()<=3789){
return 0x1.2634dad31fcd3p+4;
}else{
if(r.integer<6>()<=142){
return 0x1.cdf0b93b1f90ap+2;
}else{
return 0x1.4f32378ab0c88p+3;
}
}
}else{
return 0x1.ba5e353f7cedap-2;
}
}
}else{
if(r.integer<20>()<=54){
if(r.integer<6>()<=257){
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<46>()<=-1){
if(r.integer<3>()<=89){
return 0x1.6872b020c49bbp-2;
}else{
return -0x1.15df6555c52e7p-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=91){
if(r.integer<44>()<=16){
if(r.integer<6>()<=380){
if(r.integer<26>()<=26){
return 0x1.bb7b6bb129024p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.0d85fa80643e7p-1;
}
}else{
if(r.integer<20>()<=50){
return 0x1.a9e1b089a0275p+2;
}else{
if(r.integer<51>()<=-107){
return 0x0.0p+0;
}else{
return 0x1.1db22d0e56042p+1;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<29>()<=3){
if(r.integer<39>()<=-1){
if(r.integer<51>()<=105){
return 0x1.4fa05143bf727p+0;
}else{
return 0x1.c395810624dd4p+2;
}
}else{
if(r.integer<31>()<=5799){
if(r.integer<15>()<=6){
if(r.integer<51>()<=-101){
if(r.integer<5>()<=444){
if(r.integer<13>()<=2){
return -0x1.3a92a30553267p-6;
}else{
return 0x1.27589efd86a90p+1;
}
}else{
return -0x1.844d013a92a30p-2;
}
}else{
if(r.integer<14>()<=3){
return 0x1.5916872b020c5p+1;
}else{
return -0x1.7f62b6ae7d568p-3;
}
}
}else{
if(r.integer<17>()<=6){
return 0x1.0956c0d6f544dp+1;
}else{
return 0x1.1dd1a21ea3593p+3;
}
}
}else{
return -0x1.89374bc6a7efcp-3;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<43>()<=5){
if(r.integer<31>()<=9581){
if(r.integer<6>()<=150){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=66){
if(r.integer<5>()<=58){
return -0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<4>()<=153){
if(r.integer<31>()<=11571){
return 0x1.999999999999ap-3;
}else{
if(r.integer<38>()<=-6){
return 0x1.999999999999ap-1;
}else{
return -0x1.a66cb10342aaap+2;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=132){
if(r.integer<47>()<=0){
if(r.integer<43>()<=6){
return 0x1.0f51ac9afe1cdp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=102){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=89){
return 0x1.78d4fdf3b645bp-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<23>()<=48){
if(r.integer<50>()<=71){
if(r.integer<20>()<=87){
if(r.integer<51>()<=159){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=102){
if(r.integer<47>()<=0){
return 0x1.70a3d70a3d70bp-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=6600){
if(r.integer<13>()<=6){
return 0x0.0p+0;
}else{
return 0x1.a36e2eb1c432fp-8;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<46>()<=-1){
if(r.integer<3>()<=96){
if(r.integer<2>()<=440){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=8599){
return 0x0.0p+0;
}else{
return -0x1.a36e2eb1c4334p-10;
}
}
}else{
if(r.integer<3>()<=99){
if(r.integer<50>()<=-3){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=16){
if(r.integer<51>()<=111){
if(r.integer<47>()<=-1){
if(r.integer<51>()<=-104){
return 0x0.0p+0;
}else{
return 0x1.f44ef1d59ad1dp-1;
}
}else{
if(r.integer<6>()<=142){
if(r.integer<8>()<=99){
if(r.integer<50>()<=9){
return 0x0.0p+0;
}else{
return 0x1.bc6a7ef9db22dp+0;
}
}else{
if(r.integer<31>()<=7514){
return -0x1.800a7c5ac471cp-4;
}else{
return 0x1.914a3fbf32b05p-2;
}
}
}else{
if(r.integer<51>()<=-187){
return 0x1.f94855da27284p-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<43>()<=6){
return 0x1.f3300de4c5112p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=25){
if(r.integer<47>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=5){
return -0x1.1c5fb2173ee0fp-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=0){
if(r.integer<6>()<=469){
return 0x1.de69ad42c3c9dp-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=5091){
return 0x1.e30d1592387c5p+2;
}else{
return 0x1.a29c779a6b50dp+0;
}
}
}
}else{
if(r.integer<8>()<=153){
if(r.integer<50>()<=27){
if(r.integer<7>()<=30){
if(r.integer<31>()<=14298){
if(r.integer<31>()<=8818){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.083126e978d50p+0;
}
}else{
return -0x1.cac083126e97ap-4;
}
}else{
if(r.integer<19>()<=72){
if(r.integer<1>()<=66){
if(r.integer<43>()<=4){
if(r.integer<6>()<=147){
if(r.integer<20>()<=18){
if(r.integer<0>()<=2748){
return -0x1.7f737da61e0c5p-2;
}else{
return 0x1.148fd9fd36f80p-4;
}
}else{
return -0x1.dd1a21ea35937p-5;
}
}else{
if(r.integer<6>()<=409){
if(r.integer<20>()<=35){
if(r.integer<35>()<=3){
if(r.integer<5>()<=345){
return -0x1.9157abb8800e9p-4;
}else{
if(r.integer<5>()<=494){
return 0x1.74e65bea0ba20p-2;
}else{
return -0x1.b866e43aa79bcp-3;
}
}
}else{
return 0x1.51c5c5718eb87p-2;
}
}else{
if(r.integer<8>()<=-93){
return -0x1.f7d73c9257860p-5;
}else{
return 0x1.0cb295e9e1b09p-2;
}
}
}else{
if(r.integer<10>()<=129){
if(r.integer<54>()<=1){
return -0x1.a95421c044285p-3;
}else{
return 0x1.26e978d4fdf3bp-3;
}
}else{
if(r.integer<6>()<=428){
return 0x1.33fc86cebbba5p-1;
}else{
return 0x1.8fc504816f007p-3;
}
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<47>()<=-1){
return 0x1.e97d06bbdbe3dp-2;
}else{
return 0x1.ae1628607159fp-1;
}
}else{
if(r.integer<19>()<=6){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.76577531db447p-5;
}
}
}
}else{
if(r.integer<19>()<=61){
if(r.integer<39>()<=-1){
return 0x1.4dcebfec13b9fp+0;
}else{
return 0x1.bb05faebc408dp-2;
}
}else{
if(r.integer<10>()<=148){
return -0x1.797cc39ffd610p-9;
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<54>()<=4){
if(r.integer<0>()<=2501){
return 0x1.797cc39ffd610p-7;
}else{
return -0x1.8e757928e0ca0p-8;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=42){
if(r.integer<1>()<=46){
if(r.integer<31>()<=12606){
return -0x1.4f8b588e368f6p-10;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<29>()<=7){
if(r.integer<1>()<=89){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=345){
if(r.integer<35>()<=0){
if(r.integer<51>()<=-285){
if(r.integer<43>()<=4){
return -0x1.2f09d8c6d612dp+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_7(const BudgetResidualFeatures&r){
if(r.integer<53>()<=99){
if(r.integer<44>()<=13){
if(r.integer<31>()<=6400){
if(r.integer<53>()<=59){
if(r.integer<0>()<=852){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=0){
if(r.integer<31>()<=3570){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=6){
return 0x1.0cc3e42396904p-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=27){
if(r.integer<20>()<=86){
return 0x0.0p+0;
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-20){
if(r.integer<39>()<=0){
if(r.integer<25>()<=123){
if(r.integer<52>()<=31){
return 0x1.6f0068db8bacdp-6;
}else{
return -0x1.7ad44825721fdp-3;
}
}else{
if(r.integer<3>()<=90){
if(r.integer<50>()<=-30){
return 0x1.772e9835c88e0p+0;
}else{
return -0x1.6a37ac3eb7cbcp-2;
}
}else{
return 0x1.51494d74c8362p+0;
}
}
}else{
return 0x1.6f3fd5717802dp+1;
}
}else{
if(r.integer<8>()<=-12){
return -0x1.9652bd3c36114p-5;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=2071){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=280){
if(r.integer<6>()<=95){
if(r.integer<7>()<=36){
if(r.integer<30>()<=4){
if(r.integer<19>()<=35){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=59){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=59){
if(r.integer<6>()<=46){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<16>()<=6){
if(r.integer<6>()<=31){
return 0x1.47ae147ae147cp-3;
}else{
if(r.integer<17>()<=5){
return 0x0.0p+0;
}else{
return -0x1.3404ea4a8c14dp-4;
}
}
}else{
if(r.integer<26>()<=188){
return -0x1.ff2e48e8a71dfp-4;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-38){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<19>()<=85){
if(r.integer<20>()<=85){
if(r.integer<52>()<=39){
if(r.integer<53>()<=65){
if(r.integer<8>()<=36){
if(r.integer<0>()<=1753){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<3>()<=22){
return 0x1.9fbd4a22e3dacp-9;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<13>()<=5){
if(r.integer<24>()<=31){
if(r.integer<19>()<=45){
if(r.integer<1>()<=89){
if(r.integer<3>()<=22){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=48){
if(r.integer<3>()<=98){
if(r.integer<6>()<=384){
return 0x1.4f8b588e368f3p-11;
}else{
return 0x1.66cf41f212d77p-2;
}
}else{
if(r.integer<50>()<=94){
if(r.integer<4>()<=402){
if(r.integer<23>()<=56){
return 0x1.9fbd4a22e3dacp-9;
}else{
return 0x1.690653d717a97p-4;
}
}else{
return -0x1.03d64e55ce68bp-6;
}
}else{
return 0x1.1da480a85bff3p-2;
}
}
}else{
if(r.integer<6>()<=401){
if(r.integer<0>()<=2286){
if(r.integer<16>()<=3){
return -0x1.98f1d3ed527e4p-7;
}else{
return 0x1.9fbd4a22e3dacp-9;
}
}else{
return -0x1.7a89331a08bfdp-6;
}
}else{
return -0x1.0b630a91537a0p-5;
}
}
}
}else{
if(r.integer<19>()<=3){
return -0x1.6114edcdce549p-3;
}else{
if(r.integer<1>()<=108){
if(r.integer<5>()<=155){
return 0x1.dd79c33a7cd3ap-1;
}else{
if(r.integer<31>()<=8017){
return -0x1.9817b95a29417p-2;
}else{
return 0x1.19c6b095a343ap-2;
}
}
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}
}
}else{
if(r.integer<5>()<=58){
if(r.integer<32>()<=1){
if(r.integer<16>()<=4){
return 0x1.9fbd4a22e3dacp-9;
}else{
return -0x1.4aee3adb9e20dp-7;
}
}else{
if(r.integer<2>()<=380){
return -0x1.187e7c06e19b9p-5;
}else{
if(r.integer<35>()<=1){
return 0x1.0624dd2f1a9fdp-7;
}else{
return -0x1.2aa26af9731e1p-6;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-105){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=11730){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<51>()<=-15){
if(r.integer<51>()<=-73){
if(r.integer<43>()<=4){
if(r.integer<3>()<=13){
return -0x1.c3e2427fd7510p-4;
}else{
return 0x1.4841b83134557p-4;
}
}else{
return -0x1.4f70809b9bd26p-5;
}
}else{
if(r.integer<1>()<=55){
if(r.integer<46>()<=-1){
return 0x1.c56b84886569cp+0;
}else{
if(r.integer<54>()<=3){
if(r.integer<6>()<=359){
if(r.integer<44>()<=0){
return -0x1.5810624dd2f1dp-3;
}else{
if(r.integer<1>()<=25){
return -0x1.4f70809b9bd26p-5;
}else{
if(r.integer<3>()<=105){
return 0x1.5039d43724598p-3;
}else{
return -0x1.1dbca9691a75dp-5;
}
}
}
}else{
return 0x1.bda5119ce0760p-5;
}
}else{
if(r.integer<0>()<=1786){
return -0x1.e29b6b2af145ap-4;
}else{
return 0x1.47ae147ae147cp-3;
}
}
}
}else{
if(r.integer<14>()<=5){
if(r.integer<46>()<=0){
if(r.integer<43>()<=2){
return 0x1.749781916517cp+0;
}else{
if(r.integer<43>()<=4){
return -0x1.05913978c791fp-4;
}else{
if(r.integer<36>()<=3){
return 0x1.395810624dd30p+0;
}else{
return 0x1.b089a0275254dp-5;
}
}
}
}else{
return 0x1.83bc4d22c881fp+1;
}
}else{
if(r.integer<43>()<=2){
if(r.integer<5>()<=132){
return 0x1.e20619f5748bdp-1;
}else{
if(r.integer<13>()<=4){
if(r.integer<16>()<=5){
return -0x1.d59ad1a7fde07p-3;
}else{
return 0x1.34bf246d9d924p-1;
}
}else{
if(r.integer<54>()<=4){
if(r.integer<25>()<=171){
return -0x1.6044e4359f1e7p-4;
}else{
return 0x1.56762e5a865e5p+0;
}
}else{
return 0x1.5804a3d3af3f2p+0;
}
}
}
}else{
if(r.integer<43>()<=3){
return -0x1.7c1bda5119ce0p-3;
}else{
return 0x1.055178989811ep-2;
}
}
}
}
}
}else{
if(r.integer<30>()<=21){
if(r.integer<36>()<=7){
return 0x1.fafc8b0079a27p-5;
}else{
return -0x1.6f0068db8bac8p-6;
}
}else{
return -0x1.53bd1676640a6p-4;
}
}
}
}
}else{
if(r.integer<36>()<=9){
if(r.integer<38>()<=1){
if(r.integer<51>()<=39){
if(r.integer<30>()<=9){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=80){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=46){
return 0x1.07b784662badfp-2;
}else{
return 0x1.2b020c49ba5e3p-1;
}
}
}
}
}else{
if(r.integer<1>()<=73){
if(r.integer<3>()<=108){
return 0x0.0p+0;
}else{
return 0x1.d0917d6b65a9ap+0;
}
}else{
return 0x1.8000000000000p+1;
}
}
}else{
if(r.integer<35>()<=6){
if(r.integer<51>()<=87){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=7){
return -0x1.a36e2eb1c431fp-10;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<4>()<=3){
if(r.integer<31>()<=10214){
if(r.integer<18>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=43){
return 0x1.0b417ca2120e0p-3;
}else{
return 0x1.20439759786c5p-2;
}
}
}else{
if(r.integer<31>()<=13507){
if(r.integer<52>()<=71){
if(r.integer<25>()<=4){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
return 0x1.244a6223e1867p-4;
}
}else{
if(r.integer<9>()<=19){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=53){
if(r.integer<20>()<=0){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
return -0x1.858cd20afa2f0p+2;
}
}else{
if(r.integer<52>()<=57){
return 0x0.0p+0;
}else{
if(r.integer<10>()<=35){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=5){
if(r.integer<20>()<=75){
if(r.integer<25>()<=224){
if(r.integer<18>()<=1){
return 0x1.374bc6a7ef9dap-3;
}else{
if(r.integer<25>()<=193){
if(r.integer<20>()<=49){
return -0x1.0624dd2f1a9fdp-5;
}else{
return 0x1.6c7c2a1d09fb4p-5;
}
}else{
return -0x1.c2e33eff19504p-4;
}
}
}else{
return 0x1.d7dbf487fcb92p-4;
}
}else{
if(r.integer<52>()<=69){
return -0x1.aef6f8f041460p-6;
}else{
return 0x1.797cc39ffd610p-7;
}
}
}else{
if(r.integer<19>()<=83){
if(r.integer<25>()<=200){
return -0x1.711947cfa26a4p-11;
}else{
return -0x1.29aa1d755bccbp-3;
}
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}
}
}else{
if(r.integer<3>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=4){
if(r.integer<27>()<=0){
if(r.integer<25>()<=80){
return -0x1.4f8b588e368f2p-9;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.5421c044284e0p-2;
}
}else{
if(r.integer<5>()<=272){
if(r.integer<4>()<=105){
if(r.integer<10>()<=65){
return 0x0.0p+0;
}else{
return -0x1.0187bf7c82318p-7;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=45){
if(r.integer<26>()<=251){
return 0x0.0p+0;
}else{
return 0x1.4f8b588e368f1p-8;
}
}else{
if(r.integer<31>()<=6936){
if(r.integer<50>()<=-37){
return 0x1.dc725c3dee782p-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<20>()<=67){
if(r.integer<43>()<=2){
if(r.integer<53>()<=41){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=65){
if(r.integer<3>()<=96){
return 0x1.03afb7e90ff97p+0;
}else{
if(r.integer<20>()<=62){
return 0x1.f8a0902de00d2p-2;
}else{
return -0x1.c9993ba5c87c0p-5;
}
}
}else{
if(r.integer<30>()<=24){
return 0x1.c46e846d0c9ddp-2;
}else{
if(r.integer<51>()<=-70){
return -0x1.13836a832b992p-4;
}else{
return 0x1.f212d77318fc0p-6;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=91){
if(r.integer<51>()<=39){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=22){
return -0x1.d29dc725c3defp-6;
}else{
if(r.integer<5>()<=367){
if(r.integer<25>()<=109){
return -0x1.25f7e14d8d51ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.4727dcbddb984p-9;
}
}
}
}else{
if(r.integer<19>()<=12){
return 0x1.f7cd2b975d7f4p-2;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<51>()<=-45){
if(r.integer<19>()<=86){
return 0x1.5410f94c87982p-2;
}else{
return -0x1.c490be28c51b4p-7;
}
}else{
if(r.integer<20>()<=1){
return -0x1.afa82e87d2c7cp+2;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<52>()<=9){
if(r.integer<5>()<=286){
if(r.integer<51>()<=-62){
if(r.integer<47>()<=7){
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<51>()<=-5){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=3){
return 0x1.3333333333334p+0;
}else{
if(r.integer<24>()<=42){
if(r.integer<24>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<16>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=1){
if(r.integer<31>()<=6034){
return 0x1.d767dbe1d41d8p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<9>()<=6){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-13){
if(r.integer<24>()<=45){
if(r.integer<31>()<=5125){
if(r.integer<24>()<=12){
return 0x1.e1be4a1786c85p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=265){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<51>()<=-39){
if(r.integer<50>()<=-3){
return 0x0.0p+0;
}else{
if(r.integer<15>()<=3){
if(r.integer<31>()<=5091){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=5){
return -0x1.40508ae0f2293p-4;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=43){
if(r.integer<52>()<=29){
if(r.integer<5>()<=257){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-35){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<52>()<=30){
if(r.integer<8>()<=18){
return -0x1.8611fd5885d34p-8;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=7){
if(r.integer<20>()<=97){
if(r.integer<39>()<=-1){
if(r.integer<55>()<=0){
return 0x1.47ae147ae147cp-3;
}else{
if(r.integer<9>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=6){
return -0x1.8611fd5885d34p-8;
}else{
return 0x1.52b0a6fc58abap-6;
}
}
}
}else{
if(r.integer<19>()<=2){
if(r.integer<7>()<=34){
return -0x1.7bd8be7296f64p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<16>()<=0){
if(r.integer<29>()<=23){
if(r.integer<10>()<=25){
return -0x1.d70534f326d3cp-6;
}else{
return 0x1.f66b2bc804e6fp-1;
}
}else{
return -0x1.9ce075f6fd220p-4;
}
}else{
if(r.integer<25>()<=258){
return 0x1.90f9b7e7627a4p-9;
}else{
if(r.integer<30>()<=13){
return 0x1.243137b07075bp-1;
}else{
return -0x1.ff2e48e8a71e7p-5;
}
}
}
}
}
}else{
if(r.integer<1>()<=89){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x1.f52e60f01feb4p+2;
}
}else{
return 0x1.a47583d251e1dp+3;
}
}
}else{
if(r.integer<23>()<=28){
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=14){
return 0x1.18a86d71f3627p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=63){
if(r.integer<2>()<=462){
if(r.integer<19>()<=71){
if(r.integer<20>()<=49){
if(r.integer<19>()<=49){
if(r.integer<53>()<=26){
if(r.integer<2>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=99){
if(r.integer<4>()<=210){
if(r.integer<36>()<=8){
if(r.integer<29>()<=15){
return 0x0.0p+0;
}else{
return -0x1.5e9e1b089a028p-3;
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.930be0ded288ep-3;
}
}else{
return -0x1.13404ea4a8c16p-5;
}
}
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<39>()<=-7){
return -0x1.1eb851eb851ebp-2;
}else{
if(r.integer<19>()<=61){
if(r.integer<3>()<=61){
return 0x1.851eb851eb852p-1;
}else{
if(r.integer<26>()<=201){
return 0x1.cf41f212d7732p+1;
}else{
return 0x1.0ebedfa43fe5dp+0;
}
}
}else{
if(r.integer<47>()<=7){
return -0x1.0624dd2f1aa00p-7;
}else{
return 0x1.f212d77318fc5p-1;
}
}
}
}
}
}else{
if(r.integer<19>()<=36){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
return 0x1.20902de00d1b7p+1;
}
}else{
if(r.integer<7>()<=-39){
if(r.integer<51>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<52>()<=28){
if(r.integer<5>()<=340){
if(r.integer<51>()<=-62){
if(r.integer<6>()<=271){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=3125){
return -0x1.c8216c61522a7p-4;
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=438){
if(r.integer<33>()<=1){
return -0x1.3ee5eedcc20d3p-2;
}else{
if(r.integer<33>()<=6){
return 0x1.332f01754b05bp+1;
}else{
return 0x1.cfb9e716faee7p-1;
}
}
}else{
return -0x1.52f8cb585886cp-1;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=42){
if(r.integer<32>()<=7){
return 0x1.64840e1719f80p-6;
}else{
if(r.integer<2>()<=356){
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=26){
return 0x1.3333333333334p-1;
}else{
if(r.integer<15>()<=3){
return 0x1.999999999999ap-3;
}else{
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<3>()<=74){
if(r.integer<39>()<=-1){
if(r.integer<4>()<=75){
return 0x1.89efd86a8fc0ep-2;
}else{
return -0x1.f75104d551d67p-7;
}
}else{
if(r.integer<51>()<=81){
if(r.integer<7>()<=-72){
return 0x1.1f601797cc3a0p-2;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.f53825e13b18cp-7;
}
}
}else{
if(r.integer<50>()<=51){
if(r.integer<15>()<=7){
return 0x1.47ae147ae147cp-2;
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<33>()<=9){
return 0x0.0p+0;
}else{
return -0x1.f53825e13b18cp-7;
}
}
}
}else{
if(r.integer<8>()<=57){
if(r.integer<36>()<=18){
if(r.integer<6>()<=257){
if(r.integer<55>()<=0){
return -0x1.f0f5a1016ce7ap-2;
}else{
return 0x1.3f80488fbbca7p-5;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<19>()<=70){
if(r.integer<2>()<=36){
return 0x1.fbaf38674f9a7p+0;
}else{
return 0x1.e55c0fcb4f1e4p-3;
}
}else{
if(r.integer<1>()<=57){
return 0x1.a3783facbe39ap-1;
}else{
if(r.integer<8>()<=48){
return 0x1.8ddb1f75e70d0p-3;
}else{
return 0x1.099e0e736049fp+0;
}
}
}
}else{
if(r.integer<35>()<=3){
if(r.integer<19>()<=46){
if(r.integer<19>()<=22){
if(r.integer<23>()<=35){
return 0x1.b86d9a374e4b0p-2;
}else{
return -0x1.af4379fd47130p-3;
}
}else{
if(r.integer<29>()<=22){
return 0x1.0afa2f05a708fp+1;
}else{
if(r.integer<8>()<=39){
return 0x1.1fe64f54d1e97p-1;
}else{
return -0x1.9a1fd1569f490p-3;
}
}
}
}else{
if(r.integer<53>()<=63){
return 0x1.3fca1a6ae5514p-2;
}else{
return -0x1.06cca2db61bb3p-3;
}
}
}else{
if(r.integer<29>()<=14){
if(r.integer<8>()<=-62){
return -0x1.9f2f04d049594p-3;
}else{
return 0x1.13be22e5de15fp-1;
}
}else{
return -0x1.97b919bc949b6p-3;
}
}
}
}
}else{
if(r.integer<5>()<=284){
return 0x1.ac1b7c5d48b07p-3;
}else{
if(r.integer<7>()<=-50){
return -0x1.8d2292d1ff3bcp-2;
}else{
return 0x1.239be67af3bcap-5;
}
}
}
}else{
return 0x1.62962240c79bap-5;
}
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=6267){
if(r.integer<44>()<=16){
if(r.integer<31>()<=4448){
if(r.integer<30>()<=8){
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=89){
if(r.integer<52>()<=4){
if(r.integer<17>()<=5){
return 0x1.b481110c97bdfp+3;
}else{
if(r.integer<19>()<=49){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<31>()<=3028){
return 0x1.5f94f0bd6cdd7p+3;
}else{
if(r.integer<14>()<=4){
if(r.integer<4>()<=265){
return -0x1.14c8e4e0bfc8dp+0;
}else{
return 0x1.0f8da71d0fdb3p+1;
}
}else{
return 0x1.597bd20875f00p+2;
}
}
}
}
}else{
if(r.integer<13>()<=7){
return 0x0.0p+0;
}else{
return 0x1.e9e1b089a0275p-1;
}
}
}else{
if(r.integer<38>()<=6){
return 0x0.0p+0;
}else{
return -0x1.5a807f166094bp-4;
}
}
}
}else{
if(r.integer<36>()<=17){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=28){
if(r.integer<43>()<=4){
if(r.integer<53>()<=190){
if(r.integer<51>()<=-107){
if(r.integer<5>()<=335){
if(r.integer<35>()<=0){
if(r.integer<0>()<=2060){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=111){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=60){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<9>()<=2){
if(r.integer<6>()<=279){
if(r.integer<0>()<=2012){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<30>()<=4){
if(r.integer<1>()<=92){
if(r.integer<1>()<=76){
if(r.integer<3>()<=76){
return 0x0.0p+0;
}else{
return 0x1.6666666666667p+0;
}
}else{
if(r.integer<30>()<=2){
if(r.integer<36>()<=13){
return 0x1.499a8e8d9008ep+3;
}else{
return -0x1.71f36262cba74p-1;
}
}else{
return 0x1.73411d558112fp+1;
}
}
}else{
if(r.integer<50>()<=-8){
if(r.integer<25>()<=95){
return -0x1.a72a7bd48cb4ap-2;
}else{
return 0x1.cac083126e97ap-1;
}
}else{
return -0x1.1dd9afc6a722ap-3;
}
}
}else{
if(r.integer<52>()<=29){
if(r.integer<39>()<=-7){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=9){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<3>()<=75){
if(r.integer<43>()<=4){
if(r.integer<52>()<=15){
if(r.integer<5>()<=155){
if(r.integer<47>()<=7){
if(r.integer<8>()<=-108){
if(r.integer<5>()<=143){
return 0x0.0p+0;
}else{
return -0x1.29c779a6b50b1p+1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=93){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=68){
if(r.integer<31>()<=11131){
if(r.integer<53>()<=150){
if(r.integer<44>()<=13){
if(r.integer<31>()<=7915){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=26){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=-58){
return -0x1.89374bc6a7efap-6;
}else{
if(r.integer<10>()<=127){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<50>()<=52){
if(r.integer<31>()<=8781){
if(r.integer<50>()<=-28){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=51){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<38>()<=1){
if(r.integer<51>()<=-290){
if(r.integer<50>()<=-55){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=9955){
return -0x1.47ae147ae147cp-3;
}else{
if(r.integer<36>()<=18){
return -0x1.c7ae147ae147cp+1;
}else{
if(r.integer<30>()<=22){
return 0x1.47ae147ae147cp-5;
}else{
return -0x1.303afb7e90ffap+2;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=17){
return 0x0.0p+0;
}else{
return -0x1.810624dd2f1abp-1;
}
}
}
}else{
if(r.integer<17>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=14167){
if(r.integer<51>()<=-342){
if(r.integer<36>()<=18){
return -0x1.cbb1af3a14cedp+2;
}else{
return 0x1.47ae147ae147cp-5;
}
}else{
return -0x1.eb851eb851eb7p-4;
}
}else{
return 0x1.47ae147ae147cp-3;
}
}
}else{
if(r.integer<3>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<9>()<=41){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=29){
if(r.integer<5>()<=271){
if(r.integer<31>()<=8458){
if(r.integer<1>()<=103){
if(r.integer<38>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=87){
return -0x1.0624dd2f1a9fbp-6;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=9629){
if(r.integer<35>()<=5){
if(r.integer<35>()<=0){
if(r.integer<43>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=340){
return -0x1.2d77318fc5049p-5;
}else{
if(r.integer<7>()<=31){
return 0x1.74e65bea0ba20p-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<43>()<=0){
return 0x1.d4b6a619da9cap-5;
}else{
if(r.integer<26>()<=188){
return 0x0.0p+0;
}else{
return 0x1.6872b020c49bcp-4;
}
}
}
}else{
if(r.integer<29>()<=24){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=73){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=63){
if(r.integer<5>()<=145){
return -0x1.cd60f15c7927dp-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=18){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-2;
}
}
}
}
}
}
}else{
if(r.integer<19>()<=50){
if(r.integer<29>()<=9){
if(r.integer<36>()<=10){
if(r.integer<36>()<=8){
if(r.integer<51>()<=102){
if(r.integer<19>()<=12){
return 0x1.7e4f9137cb480p-4;
}else{
if(r.integer<39>()<=0){
if(r.integer<54>()<=6){
if(r.integer<29>()<=0){
if(r.integer<36>()<=5){
return 0x1.38476f2a5a46ap-1;
}else{
return -0x1.1654d61b2a27fp+0;
}
}else{
if(r.integer<5>()<=383){
if(r.integer<5>()<=345){
if(r.integer<33>()<=7){
return 0x1.38974b35b36b4p-1;
}else{
if(r.integer<29>()<=2){
return 0x1.09e1cb6192c21p+2;
}else{
if(r.integer<6>()<=402){
return 0x1.d72f265e389a7p-1;
}else{
return 0x1.1b9f98b71b8aap+1;
}
}
}
}else{
return 0x1.ccd1d54a49d02p+0;
}
}else{
if(r.integer<0>()<=2044){
return 0x1.fe0db778a7b18p+0;
}else{
if(r.integer<5>()<=389){
return -0x1.3717c441e3d04p-1;
}else{
return 0x1.0313b0b6ec90ap-1;
}
}
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<8>()<=-201){
return 0x1.2677630dec51dp-1;
}else{
if(r.integer<47>()<=-1){
if(r.integer<43>()<=4){
return -0x1.bcec84f8f8a4dp-1;
}else{
return -0x1.12acaaee55b40p-4;
}
}else{
if(r.integer<16>()<=2){
return -0x1.0e6d810cdad9ep-1;
}else{
return 0x1.92641b328b6d8p-2;
}
}
}
}else{
return 0x1.a5e85c754bdc7p+0;
}
}
}else{
if(r.integer<29>()<=1){
return 0x1.1cbad121c6237p+3;
}else{
if(r.integer<35>()<=6){
return 0x1.c7219220ff540p+0;
}else{
return -0x1.06364ff332673p-2;
}
}
}
}
}else{
if(r.integer<19>()<=26){
if(r.integer<5>()<=493){
if(r.integer<5>()<=444){
if(r.integer<5>()<=389){
if(r.integer<55>()<=4){
if(r.integer<14>()<=0){
if(r.integer<5>()<=362){
return -0x1.41779994911c2p-3;
}else{
return 0x1.899392189bd84p+0;
}
}else{
if(r.integer<29>()<=4){
return 0x1.2f1455219a848p+1;
}else{
return 0x1.9b3d07c84b5dcp-2;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<1>()<=90){
if(r.integer<0>()<=2874){
if(r.integer<35>()<=0){
return -0x1.5e6bc621b7e0cp-2;
}else{
return -0x1.2599ed7c6fc00p-9;
}
}else{
return 0x1.3b3a68b19a415p-3;
}
}else{
return 0x1.1cb89d6adf71fp-1;
}
}else{
return -0x1.45231fbfb8e87p-3;
}
}
}else{
if(r.integer<5>()<=439){
return -0x1.414f55a8a9012p-2;
}else{
return 0x1.18eb8950763a2p-1;
}
}
}else{
if(r.integer<14>()<=7){
return 0x1.80064a9cdc444p+0;
}else{
return 0x1.188a3a81054e2p-1;
}
}
}else{
if(r.integer<5>()<=494){
return -0x1.443188384845ep-1;
}else{
return -0x1.6052502eec8cdp-9;
}
}
}else{
if(r.integer<36>()<=7){
if(r.integer<5>()<=494){
if(r.integer<5>()<=493){
if(r.integer<19>()<=46){
if(r.integer<1>()<=94){
if(r.integer<55>()<=3){
if(r.integer<35>()<=2){
if(r.integer<5>()<=444){
return -0x1.57689ca18bd67p-4;
}else{
return 0x1.632e3821af7d4p+1;
}
}else{
return 0x1.251fd4dc90ba3p+2;
}
}else{
if(r.integer<39>()<=-1){
return 0x1.4cd0fe8ab4fa5p+1;
}else{
if(r.integer<55>()<=9){
if(r.integer<0>()<=2653){
return -0x1.324d5a25e643dp-2;
}else{
return -0x1.3f72dc966e6bfp-4;
}
}else{
return 0x1.9ce075f6fd220p-2;
}
}
}
}else{
return -0x1.03785a84b0d43p-3;
}
}else{
return -0x1.0ea9e6eeb7027p-3;
}
}else{
return -0x1.506f841c59d2ep-2;
}
}else{
return 0x1.2736a5ae7ad23p-1;
}
}else{
return -0x1.1e85fd04a2fd0p-2;
}
}
}
}else{
if(r.integer<29>()<=1){
if(r.integer<14>()<=5){
return 0x1.ecf3a9049b9b2p+2;
}else{
return 0x1.8114d2f5dbb9dp+1;
}
}else{
if(r.integer<19>()<=48){
return 0x1.2a1f6347a301cp+0;
}else{
return -0x1.e83e425aee632p-2;
}
}
}
}else{
if(r.integer<39>()<=-1){
if(r.integer<8>()<=87){
if(r.integer<19>()<=18){
return -0x1.557bb27dec142p-1;
}else{
if(r.integer<24>()<=41){
return 0x1.691a75cd0bb6dp-2;
}else{
if(r.integer<31>()<=3686){
return 0x1.c79b34a44c7b0p-1;
}else{
return -0x1.cfd86fee248b5p-1;
}
}
}
}else{
if(r.integer<19>()<=11){
if(r.integer<0>()<=2637){
return 0x1.9b7612abd42e7p-3;
}else{
return -0x1.4b48d3ae685dcp-1;
}
}else{
return 0x1.1a0be51090710p+2;
}
}
}else{
if(r.integer<5>()<=152){
if(r.integer<29>()<=1){
return -0x1.ca55234803a4dp-1;
}else{
if(r.integer<15>()<=5){
return 0x1.d5454152b0a70p+0;
}else{
return -0x1.1f0c34c1a8ac6p-3;
}
}
}else{
if(r.integer<1>()<=92){
if(r.integer<31>()<=4558){
return -0x1.282b98343ecbep-3;
}else{
if(r.integer<5>()<=263){
if(r.integer<3>()<=74){
return 0x1.6f0068db8bac7p-6;
}else{
if(r.integer<43>()<=5){
return -0x1.cac083126e97ap-4;
}else{
return 0x1.040bfe3b03e2ap-8;
}
}
}else{
if(r.integer<30>()<=18){
return 0x1.2d77318fc5047p-4;
}else{
return -0x1.d232675b58ec2p-5;
}
}
}
}else{
if(r.integer<31>()<=9368){
return -0x1.602a0c430461cp-4;
}else{
return -0x1.f6b5538969f6ap-4;
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=9){
if(r.integer<46>()<=-1){
if(r.integer<1>()<=62){
if(r.integer<43>()<=6){
return -0x1.1a11233df2aa0p-4;
}else{
return -0x1.2ad81adea8977p-4;
}
}else{
return 0x1.330ff7c4c81bap-2;
}
}else{
if(r.integer<44>()<=16){
if(r.integer<26>()<=24){
return 0x1.c970f7b9e0610p-2;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<30>()<=3){
return 0x1.6c424879ec552p+2;
}else{
return 0x1.010c6f7a0b5eap+0;
}
}
}
}else{
if(r.integer<8>()<=156){
if(r.integer<52>()<=106){
if(r.integer<20>()<=19){
if(r.integer<53>()<=204){
if(r.integer<44>()<=13){
return -0x1.bc98a222d5174p-8;
}else{
if(r.integer<24>()<=16){
if(r.integer<35>()<=2){
return -0x1.4ca27001f09b2p-3;
}else{
return 0x1.91aee98cf6f3dp-2;
}
}else{
return 0x1.149334fb8a4f7p-1;
}
}
}else{
if(r.integer<31>()<=14435){
if(r.integer<43>()<=5){
if(r.integer<1>()<=40){
return 0x1.3b5bf6a0dbad4p-1;
}else{
return 0x1.7acfa9f6deef0p-2;
}
}else{
return -0x1.7b95a294141e7p-7;
}
}else{
return -0x1.bb8d8a41b7db5p-3;
}
}
}else{
if(r.integer<3>()<=16){
if(r.integer<4>()<=533){
return 0x1.5724d4f691ed2p-2;
}else{
return -0x1.1d57ff9b56323p-1;
}
}else{
if(r.integer<31>()<=13930){
return 0x1.421f5f40d8667p-14;
}else{
return -0x1.d9f4d37c1376dp-4;
}
}
}
}else{
return 0x1.8a9e54137d8b5p-2;
}
}else{
if(r.integer<24>()<=17){
if(r.integer<35>()<=5){
if(r.integer<35>()<=3){
if(r.integer<44>()<=6){
return -0x1.6052502eec7cfp-10;
}else{
return 0x1.b43526527a224p-9;
}
}else{
if(r.integer<31>()<=12522){
return 0x1.984a0e410b631p-2;
}else{
return -0x1.4f8b588e368f6p-10;
}
}
}else{
if(r.integer<43>()<=6){
return -0x1.4f8b588e368f6p-10;
}else{
return -0x1.d323fee2c98e5p-5;
}
}
}else{
if(r.integer<43>()<=3){
if(r.integer<35>()<=1){
return 0x1.8def416bdb1a7p-4;
}else{
return -0x1.92a737110e667p-12;
}
}else{
return -0x1.1904b3c3e74b0p-5;
}
}
}
}
}else{
if(r.integer<31>()<=14167){
if(r.integer<35>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-83){
if(r.integer<14>()<=9){
return -0x1.38664de7bf6c7p-2;
}else{
return 0x1.0a569b17481b3p-6;
}
}else{
if(r.integer<52>()<=70){
if(r.integer<8>()<=-153){
if(r.integer<20>()<=75){
return -0x1.47ae147ae147cp-5;
}else{
return -0x1.0624dd2f1a9fdp-7;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<23>()<=14){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return -0x1.797cc39ffd60fp-9;
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=3){
if(r.integer<46>()<=-1){
if(r.integer<1>()<=99){
return -0x1.626b2f23033a5p-4;
}else{
return 0x1.096bb98c7e283p-1;
}
}else{
if(r.integer<44>()<=16){
if(r.integer<5>()<=21){
if(r.integer<0>()<=3111){
return -0x1.c036bc54af84dp-4;
}else{
return 0x1.58bb82f86d648p-2;
}
}else{
return 0x1.2e1ef73c0c1fdp-2;
}
}else{
return 0x1.4d30d58ae16ffp+2;
}
}
}else{
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=367){
if(r.integer<35>()<=2){
if(r.integer<2>()<=482){
return 0x0.0p+0;
}else{
return -0x1.9b90ea9e6eebap-3;
}
}else{
if(r.integer<43>()<=3){
if(r.integer<6>()<=9){
return 0x1.4801f75104d55p-2;
}else{
if(r.integer<51>()<=-152){
if(r.integer<35>()<=6){
if(r.integer<30>()<=10){
return 0x1.9afe1da7b0b37p+0;
}else{
if(r.integer<24>()<=26){
if(r.integer<20>()<=18){
return 0x1.47ae147ae147cp-1;
}else{
return 0x1.b328b6d86ec18p-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.c0ca600b02934p-6;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<30>()<=10){
if(r.integer<4>()<=36){
return 0x1.f6fecf7e57f4cp-1;
}else{
return 0x1.2ad81adea8977p-2;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=12606){
if(r.integer<20>()<=75){
if(r.integer<53>()<=129){
if(r.integer<1>()<=109){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=70){
if(r.integer<13>()<=3){
return 0x1.9f8cf8a166ed7p-4;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.8fc504816f007p-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=69){
return -0x1.26e978d4fdf3cp-4;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_8(const BudgetResidualFeatures&r){
if(r.integer<53>()<=99){
if(r.integer<9>()<=19){
if(r.integer<44>()<=16){
if(r.integer<5>()<=286){
if(r.integer<10>()<=61){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1139){
if(r.integer<52>()<=3){
if(r.integer<10>()<=8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=3028){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
return -0x1.081c2e33eff18p-3;
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=0){
return 0x1.fe5c91d14e3bdp-1;
}else{
return -0x1.13404ea4a8c16p-5;
}
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<5>()<=483){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=307){
if(r.integer<51>()<=-62){
if(r.integer<50>()<=-8){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=271){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=91){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<52>()<=7){
if(r.integer<6>()<=270){
if(r.integer<51>()<=-13){
if(r.integer<24>()<=45){
if(r.integer<19>()<=70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=265){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=2){
if(r.integer<19>()<=44){
return 0x0.0p+0;
}else{
return 0x1.7f70aabda19f9p+0;
}
}else{
if(r.integer<10>()<=21){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-35){
if(r.integer<31>()<=5297){
if(r.integer<6>()<=270){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=38){
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=47){
if(r.integer<52>()<=35){
if(r.integer<31>()<=4521){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1365){
return 0x0.0p+0;
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=6103){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=9){
if(r.integer<10>()<=33){
return 0x0.0p+0;
}else{
return -0x1.fe21d96e9bbf2p-4;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=14167){
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=5){
if(r.integer<1>()<=50){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=-58){
if(r.integer<51>()<=18){
return 0x0.0p+0;
}else{
if(r.integer<46>()<=6){
if(r.integer<29>()<=1){
return -0x1.2599ed7c6fbd2p-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.5a1cac083126fp+0;
}
}
}else{
if(r.integer<4>()<=108){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<9>()<=40){
if(r.integer<5>()<=340){
if(r.integer<1>()<=99){
if(r.integer<31>()<=12858){
if(r.integer<3>()<=85){
if(r.integer<8>()<=-70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=87){
if(r.integer<26>()<=206){
if(r.integer<29>()<=1){
return 0x1.999999999999ap-1;
}else{
if(r.integer<20>()<=92){
return 0x0.0p+0;
}else{
if(r.integer<54>()<=3){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=6801){
if(r.integer<31>()<=5866){
if(r.integer<44>()<=4){
return 0x0.0p+0;
}else{
return 0x1.ae147ae147ae2p-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.4fdf3b645a1cbp-2;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<31>()<=7650){
if(r.integer<20>()<=62){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=48){
if(r.integer<13>()<=3){
if(r.integer<20>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=3){
return 0x1.78d4fdf3b645bp-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-31){
return 0x1.205bc01a36e30p-5;
}else{
return -0x1.0624dd2f1a9fbp-6;
}
}
}else{
if(r.integer<20>()<=83){
if(r.integer<0>()<=1653){
return -0x1.0624dd2f1a9fbp-6;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.0624dd2f1a9fbp-6;
}
}
}
}else{
if(r.integer<35>()<=0){
if(r.integer<7>()<=-28){
return 0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<9>()<=30){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=252){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=382){
if(r.integer<3>()<=81){
if(r.integer<4>()<=81){
return -0x1.1d3671ac14c67p-8;
}else{
return -0x1.1d3671ac14c67p-8;
}
}else{
if(r.integer<29>()<=18){
return -0x1.0624dd2f1a9fcp-5;
}else{
return 0x1.058dde7a743a7p-1;
}
}
}else{
return -0x1.1d3671ac14c67p-8;
}
}
}
}
}else{
if(r.integer<3>()<=76){
if(r.integer<44>()<=10){
if(r.integer<38>()<=1){
if(r.integer<31>()<=7138){
if(r.integer<13>()<=7){
if(r.integer<4>()<=514){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=70){
return 0x0.0p+0;
}else{
return -0x1.0ac1fae1b30ecp-9;
}
}
}else{
if(r.integer<1>()<=73){
return 0x0.0p+0;
}else{
return 0x1.4f8b588e368f1p-8;
}
}
}else{
if(r.integer<55>()<=9){
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=0){
return -0x1.908e581cf7877p-7;
}else{
if(r.integer<26>()<=244){
return 0x1.47ae147ae147cp-5;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}else{
if(r.integer<43>()<=0){
return -0x1.3b18dac258d59p-4;
}else{
if(r.integer<50>()<=-60){
return 0x1.601ffb480a5adp-2;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<46>()<=-2){
if(r.integer<19>()<=63){
if(r.integer<25>()<=210){
if(r.integer<0>()<=1949){
return 0x1.f94c06beb608cp-1;
}else{
if(r.integer<43>()<=2){
return -0x1.0ff972474538fp-2;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return -0x1.b328b6d86ec1ap-4;
}
}else{
return 0x1.25e353f7ced92p+1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=100){
if(r.integer<6>()<=46){
if(r.integer<52>()<=18){
return 0x1.5a07b352a8439p-5;
}else{
if(r.integer<6>()<=15){
if(r.integer<17>()<=8){
return 0x1.89374bc6a7efcp-6;
}else{
if(r.integer<4>()<=382){
return 0x1.88b5e8fcfb8b2p-2;
}else{
return 0x1.d8c6d612c6ac2p-1;
}
}
}else{
if(r.integer<54>()<=2){
if(r.integer<2>()<=529){
if(r.integer<13>()<=5){
if(r.integer<51>()<=81){
if(r.integer<4>()<=494){
return 0x1.82b6ff052e3d4p-8;
}else{
return -0x1.b13165d3996fap-3;
}
}else{
return -0x1.4f70809b9bd26p-5;
}
}else{
if(r.integer<35>()<=6){
if(r.integer<31>()<=5934){
return -0x1.2599ed7c6fbd3p-4;
}else{
if(r.integer<0>()<=1653){
return 0x1.573eab367a0f9p-1;
}else{
return 0x1.d1c70790edfa0p-6;
}
}
}else{
return 0x1.87724fa8b4bf9p-2;
}
}
}else{
return 0x1.4f7c3f15bf84fp-1;
}
}else{
if(r.integer<26>()<=87){
if(r.integer<52>()<=65){
if(r.integer<16>()<=10){
if(r.integer<20>()<=81){
if(r.integer<25>()<=71){
if(r.integer<26>()<=68){
return 0x1.e00d1b71758e4p-2;
}else{
return -0x1.e4f765fd8adacp-5;
}
}else{
return -0x1.0a06133f77e53p-4;
}
}else{
return -0x1.a75cd0bb6ed68p-4;
}
}else{
return -0x1.c23b7952d234dp-3;
}
}else{
if(r.integer<18>()<=3){
return 0x1.4a4d2b2bfdb4dp-5;
}else{
if(r.integer<6>()<=38){
return -0x1.0cb295e9e1b0ap-4;
}else{
return 0x1.5838a639bb0ccp-2;
}
}
}
}else{
if(r.integer<31>()<=4246){
if(r.integer<39>()<=-1){
return 0x1.5e7c8d195896ap-2;
}else{
if(r.integer<6>()<=31){
if(r.integer<15>()<=2){
return -0x1.8be2a17e892b8p-3;
}else{
return -0x1.8154f0dfe6358p-4;
}
}else{
if(r.integer<51>()<=-51){
return -0x1.e4f765fd8adadp-4;
}else{
return 0x1.8adab9f559b40p-2;
}
}
}
}else{
if(r.integer<0>()<=1494){
if(r.integer<24>()<=48){
if(r.integer<19>()<=52){
return -0x1.96fa82e87d2c8p-3;
}else{
return 0x1.6cb5350092cd0p-2;
}
}else{
if(r.integer<28>()<=0){
return 0x1.0ab7132724313p+0;
}else{
return 0x1.bb8c32a8c9b9ap-6;
}
}
}else{
if(r.integer<6>()<=33){
if(r.integer<4>()<=432){
return 0x1.8d48d35882222p-13;
}else{
return 0x1.7ad304f53246bp-3;
}
}else{
if(r.integer<19>()<=30){
if(r.integer<19>()<=17){
return -0x1.4f70809b9bd26p-5;
}else{
return -0x1.b8602e3e00ec0p-3;
}
}else{
if(r.integer<28>()<=0){
if(r.integer<29>()<=7){
if(r.integer<26>()<=197){
return -0x1.8d48d35882222p-11;
}else{
return -0x1.999999999999ap-2;
}
}else{
if(r.integer<10>()<=75){
return 0x1.14e3bcd35a858p-2;
}else{
if(r.integer<0>()<=2347){
return 0x1.44241c3efae7ap-3;
}else{
return -0x1.4f70809b9bd26p-5;
}
}
}
}else{
if(r.integer<5>()<=455){
return -0x1.76ddaceee0f40p-5;
}else{
return 0x1.64840e1719f7fp-4;
}
}
}
}
}
}
}
}
}
}
}else{
if(r.integer<30>()<=1){
if(r.integer<20>()<=42){
if(r.integer<46>()<=-2){
return -0x1.89374bc6a7efbp-3;
}else{
if(r.integer<44>()<=16){
if(r.integer<31>()<=3511){
return -0x1.e4f765fd8adadp-4;
}else{
if(r.integer<43>()<=6){
if(r.integer<36>()<=13){
return 0x1.56fa48ed14fcdp-1;
}else{
return 0x1.38f86f120692cp+0;
}
}else{
return -0x1.6575a59e8a99ap-5;
}
}
}else{
return 0x1.00945f9df548fp+3;
}
}
}else{
if(r.integer<2>()<=460){
if(r.integer<18>()<=6){
if(r.integer<5>()<=272){
if(r.integer<26>()<=191){
if(r.integer<1>()<=97){
return -0x1.ce63fba801915p-4;
}else{
return 0x1.a9fbe76c8b43ap-4;
}
}else{
if(r.integer<39>()<=0){
if(r.integer<44>()<=8){
return -0x1.03d64e55ce68bp-6;
}else{
return 0x1.62a5e785b5b70p-1;
}
}else{
return -0x1.23a29c779a6b6p-3;
}
}
}else{
if(r.integer<5>()<=362){
if(r.integer<53>()<=63){
return 0x1.90c0ad03d9a95p-2;
}else{
return -0x1.03d64e55ce68bp-6;
}
}else{
if(r.integer<1>()<=58){
return 0x1.c714fce746cbap-7;
}else{
return -0x1.e8e60807357e8p-4;
}
}
}
}else{
if(r.integer<52>()<=40){
if(r.integer<26>()<=180){
if(r.integer<52>()<=31){
return 0x1.2d77318fc5047p-3;
}else{
return 0x1.7acc4ef88b977p-2;
}
}else{
if(r.integer<16>()<=4){
return -0x1.595feda661284p-3;
}else{
return 0x1.0f21053345a7bp-1;
}
}
}else{
return -0x1.03d64e55ce68bp-6;
}
}
}else{
return 0x1.c2b445168a860p-2;
}
}
}else{
if(r.integer<55>()<=8){
if(r.integer<19>()<=42){
if(r.integer<29>()<=9){
if(r.integer<36>()<=18){
if(r.integer<39>()<=0){
if(r.integer<19>()<=5){
if(r.integer<55>()<=3){
if(r.integer<26>()<=103){
return 0x1.163d99938f697p+1;
}else{
if(r.integer<25>()<=200){
return -0x1.f0c34c1a8ac5dp-3;
}else{
return 0x1.6f3973bf147d7p+1;
}
}
}else{
if(r.integer<8>()<=39){
return -0x1.3333333333333p-1;
}else{
return -0x1.92dcff8cc9ccdp-5;
}
}
}else{
if(r.integer<31>()<=3028){
return -0x1.85f06f6944674p-2;
}else{
if(r.integer<35>()<=3){
if(r.integer<5>()<=439){
if(r.integer<43>()<=4){
if(r.integer<18>()<=1){
return 0x1.48cb4aec8d5c7p-1;
}else{
if(r.integer<6>()<=463){
if(r.integer<39>()<=-2){
if(r.integer<10>()<=71){
return 0x1.301eabbcb1ccap+1;
}else{
return -0x1.9afd46e81bde0p-4;
}
}else{
if(r.integer<3>()<=38){
if(r.integer<19>()<=21){
return 0x1.102080f657013p-1;
}else{
return -0x1.ddc1e7967caedp-3;
}
}else{
if(r.integer<16>()<=1){
return -0x1.5e50f141ede5dp-2;
}else{
return -0x1.003eea209aaa4p-2;
}
}
}
}else{
return 0x1.582f00b928f14p-1;
}
}
}else{
if(r.integer<20>()<=67){
if(r.integer<10>()<=71){
return -0x1.13353bf6fc207p-1;
}else{
return 0x1.a436d680d5a87p-1;
}
}else{
return 0x1.e80460b7d0bc5p+0;
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<15>()<=5){
return 0x1.5c28f5c28f5c3p+0;
}else{
if(r.integer<7>()<=-47){
return 0x1.a7b0b39192642p-1;
}else{
return -0x1.374bc6a7ef9ddp-3;
}
}
}else{
return -0x1.4c9322ff55d87p-3;
}
}
}else{
if(r.integer<8>()<=-56){
if(r.integer<0>()<=1704){
return -0x1.1ed9dfdac68aap-2;
}else{
if(r.integer<5>()<=150){
return 0x1.c792d1287c202p-1;
}else{
return -0x1.46796114edcdfp-2;
}
}
}else{
if(r.integer<46>()<=-1){
return 0x1.0683d2b2eace7p-1;
}else{
if(r.integer<25>()<=40){
return 0x1.eb439b15fd2f4p-3;
}else{
return 0x1.b84703ca8fdbcp+0;
}
}
}
}
}
}
}else{
if(r.integer<1>()<=74){
return -0x1.457db89283254p-2;
}else{
if(r.integer<4>()<=275){
return 0x1.aada9f1d67192p+1;
}else{
if(r.integer<43>()<=4){
if(r.integer<0>()<=1566){
return -0x1.16659d12cade0p-3;
}else{
return 0x1.c3cac58b8febap+0;
}
}else{
return 0x1.0e2089e34330dp+2;
}
}
}
}
}else{
if(r.integer<7>()<=-32){
return -0x1.369d4aff01d34p-3;
}else{
return -0x1.9652bd3c36115p-5;
}
}
}else{
if(r.integer<24>()<=37){
return 0x1.7481b21c475e7p-4;
}else{
if(r.integer<35>()<=3){
if(r.integer<43>()<=5){
if(r.integer<8>()<=78){
if(r.integer<54>()<=4){
return 0x1.75d7f3717c444p-3;
}else{
if(r.integer<32>()<=6){
return -0x1.65fbdd5b904b4p-4;
}else{
return 0x1.6674a91f489a7p-4;
}
}
}else{
return -0x1.acc342098fcbcp-5;
}
}else{
return 0x1.9e7c1b4849b4dp-2;
}
}else{
if(r.integer<10>()<=55){
if(r.integer<47>()<=-1){
return -0x1.5985f9a73cc0fp-3;
}else{
if(r.integer<13>()<=5){
return -0x1.b9f98b71b8aa0p-4;
}else{
return 0x1.288ce703afb7fp-2;
}
}
}else{
if(r.integer<4>()<=108){
return -0x1.61c00e7868c77p-2;
}else{
if(r.integer<31>()<=6568){
return 0x1.114fb39c7a1ebp-3;
}else{
if(r.integer<17>()<=2){
return -0x1.a0c8620401168p-3;
}else{
if(r.integer<0>()<=1949){
return 0x1.0dc260624066fp-2;
}else{
return -0x1.258c8183225e7p-4;
}
}
}
}
}
}
}
}
}else{
if(r.integer<3>()<=63){
if(r.integer<19>()<=96){
if(r.integer<1>()<=117){
if(r.integer<31>()<=6334){
if(r.integer<0>()<=1494){
if(r.integer<14>()<=5){
return -0x1.92641b328b6d9p-3;
}else{
return 0x1.2a0ec74320104p-2;
}
}else{
if(r.integer<26>()<=75){
return -0x1.89374bc6a7efbp-4;
}else{
if(r.integer<7>()<=-41){
return 0x1.1de19256af394p-2;
}else{
if(r.integer<2>()<=186){
return -0x1.7a38ab423889cp-4;
}else{
return 0x1.5a8deb0fadf2fp-2;
}
}
}
}
}else{
if(r.integer<31>()<=7480){
if(r.integer<24>()<=57){
if(r.integer<18>()<=6){
return -0x1.59ecdb600d86cp-5;
}else{
return -0x1.ba1463645366cp-3;
}
}else{
return 0x1.999999999999ap-3;
}
}else{
return -0x1.01bd6f61b7ab3p-6;
}
}
}else{
return 0x1.637e5499b5484p-3;
}
}else{
if(r.integer<8>()<=42){
if(r.integer<5>()<=271){
return 0x1.a121a33ddd304p-2;
}else{
return -0x1.30164840e171ap-3;
}
}else{
return 0x1.838425e15d74fp-1;
}
}
}else{
if(r.integer<20>()<=52){
if(r.integer<46>()<=-1){
if(r.integer<43>()<=4){
if(r.integer<33>()<=6){
if(r.integer<35>()<=1){
return -0x1.5f3874bb93bfap-4;
}else{
return 0x1.de69ad42c3c9fp-1;
}
}else{
return -0x1.1e7f4707fc4dcp-3;
}
}else{
return -0x1.41205bc01a370p-4;
}
}else{
if(r.integer<39>()<=-2){
if(r.integer<29>()<=26){
return -0x1.4141e9af5ba2dp-3;
}else{
if(r.integer<19>()<=75){
return -0x1.67df0c6a718dfp-4;
}else{
return 0x1.374bc6a7ef9dcp-1;
}
}
}else{
if(r.integer<52>()<=30){
if(r.integer<25>()<=200){
if(r.integer<38>()<=0){
if(r.integer<31>()<=4777){
return -0x1.0624dd2f1a9fdp-3;
}else{
if(r.integer<18>()<=5){
return 0x1.9767903211cb0p-1;
}else{
return -0x1.b71758e219654p-4;
}
}
}else{
return 0x1.89374bc6a7efap-2;
}
}else{
return 0x1.0a3d70a3d70a3p-1;
}
}else{
if(r.integer<6>()<=480){
if(r.integer<19>()<=49){
if(r.integer<10>()<=55){
return -0x1.ec629449ce804p+0;
}else{
return 0x1.db877ab324852p-4;
}
}else{
if(r.integer<5>()<=134){
if(r.integer<52>()<=35){
return 0x1.05bc01a36e2ebp+0;
}else{
if(r.integer<5>()<=52){
return 0x1.604189374bc6bp-1;
}else{
return -0x1.e0249865bcf27p-5;
}
}
}else{
if(r.integer<31>()<=7480){
if(r.integer<25>()<=197){
if(r.integer<16>()<=5){
return 0x1.0105639729270p+0;
}else{
return 0x1.0624dd2f1a9f7p-4;
}
}else{
return -0x1.16872b020c49fp-3;
}
}else{
if(r.integer<6>()<=143){
return -0x1.6f15e26a6ddcap-7;
}else{
if(r.integer<15>()<=2){
return 0x1.743632c1f42bcp-1;
}else{
return 0x1.9d7342edbb59fp+0;
}
}
}
}
}
}else{
return -0x1.97e56473471f8p-4;
}
}
}
}
}else{
if(r.integer<1>()<=41){
if(r.integer<54>()<=6){
return -0x1.333b96af038e4p-5;
}else{
return 0x1.4f8b588e368f1p-8;
}
}else{
if(r.integer<3>()<=65){
return 0x1.4af4f0d844d02p-1;
}else{
if(r.integer<5>()<=373){
if(r.integer<53>()<=55){
if(r.integer<32>()<=3){
return 0x1.4f8b588e368f1p-8;
}else{
return -0x1.999999999999ap-3;
}
}else{
if(r.integer<35>()<=3){
return 0x1.bb9cf9a06a6e4p-2;
}else{
return 0x1.cd5f99c38b034p-9;
}
}
}else{
if(r.integer<33>()<=5){
if(r.integer<15>()<=3){
return 0x1.7c1bda5119ce1p-1;
}else{
if(r.integer<18>()<=6){
return 0x1.9ac3d4f04b9b4p-6;
}else{
return -0x1.28e0c9d9d345ap-3;
}
}
}else{
return -0x1.6bb98c7e28242p-3;
}
}
}
}
}
}
}
}else{
if(r.integer<10>()<=75){
if(r.integer<36>()<=16){
if(r.integer<20>()<=94){
if(r.integer<13>()<=3){
if(r.integer<29>()<=8){
if(r.integer<20>()<=40){
return 0x1.511f77873d537p-2;
}else{
return 0x1.743709818901ap+0;
}
}else{
if(r.integer<5>()<=134){
if(r.integer<25>()<=250){
if(r.integer<24>()<=19){
return 0x1.0233b6e6b17a7p+0;
}else{
return -0x1.19db7358bd307p-5;
}
}else{
return 0x1.9f7f8ca8198f2p-1;
}
}else{
if(r.integer<17>()<=1){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.dd5d3dc8b86b2p-2;
}
}
}
}else{
if(r.integer<6>()<=54){
if(r.integer<4>()<=325){
return -0x1.192641b328b6dp-2;
}else{
return 0x1.0e0221426fe73p-5;
}
}else{
if(r.integer<20>()<=2){
return -0x1.dc4362555fadfp-4;
}else{
return 0x1.ae345b515f6e2p-3;
}
}
}
}else{
if(r.integer<16>()<=4){
return 0x1.0d59401e64555p+0;
}else{
return 0x1.e3ae90a1a3537p-3;
}
}
}else{
if(r.integer<53>()<=69){
return -0x1.1a11233df2a9ep-4;
}else{
if(r.integer<16>()<=3){
return 0x1.700e85d4c0b72p-1;
}else{
return 0x1.ec694a46752f5p-8;
}
}
}
}else{
if(r.integer<20>()<=75){
if(r.integer<20>()<=15){
if(r.integer<25>()<=106){
return -0x1.aff5fc70ff46cp-4;
}else{
if(r.integer<5>()<=362){
return -0x1.d24a06abb821ap-7;
}else{
return 0x1.b055f3a7820f8p-2;
}
}
}else{
return 0x1.839b2a9351810p-3;
}
}else{
return -0x1.a0e9eff34281ap-6;
}
}
}
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<26>()<=16){
if(r.integer<53>()<=69){
if(r.integer<43>()<=4){
return 0x1.8e2cfee6a5660p-1;
}else{
return 0x1.0624dd2f1a9fdp-7;
}
}else{
return 0x1.3e81450efdc9dp-4;
}
}else{
if(r.integer<2>()<=147){
return -0x1.03d64e55ce68bp-6;
}else{
if(r.integer<0>()<=1583){
return 0x1.5336deb95e5b4p-3;
}else{
if(r.integer<55>()<=5){
if(r.integer<20>()<=2){
return -0x1.975f2cb641700p-5;
}else{
if(r.integer<5>()<=2){
return -0x1.513e361b9ae63p-5;
}else{
if(r.integer<50>()<=61){
return 0x1.008f71f86ae03p-3;
}else{
if(r.integer<31>()<=11962){
return -0x1.3a92a30553262p-6;
}else{
if(r.integer<20>()<=49){
if(r.integer<19>()<=81){
return 0x1.c3c76a8d3c947p-4;
}else{
if(r.integer<19>()<=89){
return 0x1.da02a689a8460p-1;
}else{
return 0x1.9e13d1c402787p-3;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<54>()<=4){
return -0x1.522510db9a700p-6;
}else{
return 0x1.797cc39ffd60fp-7;
}
}
}
}
}
}else{
if(r.integer<8>()<=51){
if(r.integer<43>()<=4){
if(r.integer<43>()<=1){
return -0x1.4f8b588e368f0p-7;
}else{
if(r.integer<55>()<=4){
return 0x1.81e6f56cff06fp-2;
}else{
return 0x1.ecb473ba8cd80p-5;
}
}
}else{
if(r.integer<31>()<=6968){
return 0x1.f7d73c9257860p-3;
}else{
if(r.integer<17>()<=4){
return -0x1.3fb5f874f1437p-5;
}else{
if(r.integer<50>()<=49){
return 0x1.1b152f3c2dadcp-1;
}else{
return -0x1.974f118b17cbap-6;
}
}
}
}
}else{
if(r.integer<43>()<=0){
if(r.integer<35>()<=5){
if(r.integer<19>()<=48){
return 0x1.6b79cb9df8a3fp-2;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<53>()<=59){
return -0x1.9aefdaeece7f5p-5;
}else{
return -0x1.04fd95c274843p-5;
}
}
}else{
if(r.integer<35>()<=6){
return 0x1.3a92a30553267p-8;
}else{
if(r.integer<19>()<=39){
return -0x1.512fb7418f056p-4;
}else{
return -0x1.828c0be769dc1p-6;
}
}
}
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=6267){
if(r.integer<44>()<=16){
if(r.integer<43>()<=4){
if(r.integer<31>()<=4448){
if(r.integer<29>()<=8){
if(r.integer<1>()<=75){
if(r.integer<3>()<=86){
return 0x0.0p+0;
}else{
return 0x1.50b0f27bb2fedp+0;
}
}else{
if(r.integer<38>()<=6){
if(r.integer<1>()<=89){
if(r.integer<3>()<=75){
if(r.integer<14>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=89){
if(r.integer<15>()<=3){
return 0x1.3986fa2fb1738p+3;
}else{
return 0x1.630adc7cee124p+2;
}
}else{
if(r.integer<39>()<=-2){
if(r.integer<15>()<=5){
return -0x1.dd92edadede4ap-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=21){
return -0x1.89374bc6a7efap-6;
}else{
return 0x1.999999999999ap-3;
}
}
}
}
}else{
if(r.integer<17>()<=3){
if(r.integer<39>()<=-2){
return 0x1.be46214c80e15p-9;
}else{
if(r.integer<30>()<=6){
return 0x0.0p+0;
}else{
return 0x1.78ce80225653dp+0;
}
}
}else{
if(r.integer<3>()<=77){
if(r.integer<26>()<=180){
return -0x1.cac083126e980p-5;
}else{
return 0x1.ac8605681ecd4p+1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<4>()<=287){
return -0x1.80153922358a0p-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<36>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=28){
if(r.integer<53>()<=190){
if(r.integer<51>()<=-107){
if(r.integer<5>()<=335){
if(r.integer<35>()<=0){
if(r.integer<0>()<=2060){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=2){
if(r.integer<6>()<=279){
if(r.integer<0>()<=2012){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=29){
if(r.integer<39>()<=-7){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=44){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5125){
if(r.integer<6>()<=277){
if(r.integer<1>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=90){
if(r.integer<36>()<=13){
return 0x1.1ab800b74d5fbp+3;
}else{
return -0x1.a36e2eb1c432fp-10;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=76){
return 0x0.0p+0;
}else{
if(r.integer<23>()<=30){
return 0x0.0p+0;
}else{
return 0x1.56a161e4f7660p+1;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=152){
if(r.integer<52>()<=21){
if(r.integer<43>()<=4){
if(r.integer<31>()<=11654){
if(r.integer<30>()<=27){
if(r.integer<31>()<=8670){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=0){
return 0x1.3333333333334p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.5729b280f12c3p+1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7915){
if(r.integer<23>()<=16){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=54){
if(r.integer<4>()<=87){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=54){
if(r.integer<31>()<=9859){
if(r.integer<44>()<=13){
if(r.integer<53>()<=188){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=17){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=49){
if(r.integer<7>()<=43){
return -0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=7){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-324){
if(r.integer<35>()<=4){
return -0x1.c41cc532a4980p+2;
}else{
return -0x1.6872b020c49b4p-4;
}
}else{
if(r.integer<31>()<=13030){
return -0x1.2f1a9fbe76c8bp-2;
}else{
return 0x1.0a3d70a3d70a4p+0;
}
}
}
}else{
if(r.integer<31>()<=11805){
if(r.integer<10>()<=136){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=68){
if(r.integer<31>()<=10055){
if(r.integer<31>()<=9368){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=55){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-5;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<4>()<=114){
return 0x1.096bb98c7e283p-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=14298){
if(r.integer<31>()<=12439){
return -0x1.cac083126e97ap-3;
}else{
return -0x1.fe90ff9724745p+1;
}
}else{
return 0x1.353f7ced91688p+0;
}
}
}
}
}
}else{
if(r.integer<9>()<=47){
if(r.integer<43>()<=3){
if(r.integer<52>()<=51){
return 0x0.0p+0;
}else{
return 0x1.89374bc6a7ef9p-6;
}
}else{
if(r.integer<6>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=48){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=105){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=86){
if(r.integer<25>()<=100){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<19>()<=51){
if(r.integer<29>()<=3){
if(r.integer<39>()<=-1){
if(r.integer<8>()<=-102){
if(r.integer<33>()<=6){
if(r.integer<3>()<=72){
if(r.integer<2>()<=522){
return -0x1.112233a8f147dp+0;
}else{
return 0x1.63f0f3d12629ap-4;
}
}else{
if(r.integer<43>()<=2){
return 0x1.50ba2cb7182fap+0;
}else{
return -0x1.d4ae988445ca7p-1;
}
}
}else{
if(r.integer<5>()<=271){
return 0x1.0e686315cef45p+2;
}else{
return -0x1.244707258e2f0p-1;
}
}
}else{
if(r.integer<19>()<=7){
return 0x1.44a1f080303c0p-1;
}else{
return 0x1.b75aaa7081727p+2;
}
}
}else{
if(r.integer<51>()<=-143){
if(r.integer<39>()<=0){
if(r.integer<36>()<=13){
if(r.integer<1>()<=74){
return 0x1.b65b019490d77p+0;
}else{
return 0x1.dd96f478b84e0p-3;
}
}else{
if(r.integer<44>()<=10){
return -0x1.38e523dba75afp-7;
}else{
return -0x1.e108c3f3e0370p-3;
}
}
}else{
if(r.integer<15>()<=1){
return 0x1.4144d94de48f6p+3;
}else{
if(r.integer<35>()<=6){
return 0x1.0b43f849ca9bbp+2;
}else{
return -0x1.ce33aa2684a47p-3;
}
}
}
}else{
if(r.integer<14>()<=4){
if(r.integer<14>()<=0){
return -0x1.fbe76c8b4395ap-3;
}else{
return 0x1.3a5134a5f9fa3p-1;
}
}else{
if(r.integer<35>()<=5){
return 0x1.c221f8f92599ap-8;
}else{
if(r.integer<6>()<=158){
return -0x1.b04de611ed3e7p-2;
}else{
return -0x1.3ea988fae5e4fp-4;
}
}
}
}
}
}else{
if(r.integer<8>()<=99){
if(r.integer<20>()<=22){
if(r.integer<30>()<=9){
if(r.integer<47>()<=-1){
if(r.integer<6>()<=273){
if(r.integer<9>()<=23){
return -0x1.51c5c5718eb8ap-1;
}else{
return 0x1.9b1168de0feb4p-3;
}
}else{
return -0x1.8cb2807052ce7p+0;
}
}else{
if(r.integer<47>()<=0){
return 0x1.26a65cf67b1c0p-1;
}else{
if(r.integer<50>()<=40){
return 0x1.4271293807ae5p+2;
}else{
return 0x1.44ae5ac6cb007p+1;
}
}
}
}else{
if(r.integer<19>()<=6){
if(r.integer<6>()<=95){
return -0x1.90bd52058651cp-3;
}else{
return 0x1.3635f1ff6149ap-8;
}
}else{
if(r.integer<44>()<=13){
if(r.integer<24>()<=20){
if(r.integer<0>()<=2286){
return 0x1.3d6c7219220ffp+0;
}else{
return 0x1.637ba567d9024p-3;
}
}else{
if(r.integer<35>()<=4){
if(r.integer<5>()<=455){
if(r.integer<5>()<=433){
if(r.integer<35>()<=1){
if(r.integer<43>()<=2){
if(r.integer<5>()<=345){
if(r.integer<6>()<=323){
return -0x1.dc2686fd5fbcdp-2;
}else{
return -0x1.38730e1495b94p-3;
}
}else{
if(r.integer<13>()<=4){
return -0x1.f404ca1435c22p-3;
}else{
return 0x1.62de9c8302ff4p-1;
}
}
}else{
if(r.integer<5>()<=367){
return 0x1.001edebd6525dp+0;
}else{
return -0x1.7b121a08eab54p-4;
}
}
}else{
return 0x1.2698f0fd2dbdap-1;
}
}else{
return 0x1.33a879057a685p+0;
}
}else{
return -0x1.b3c9c6880f2dap-3;
}
}else{
if(r.integer<43>()<=3){
return -0x1.3e86a372b655fp-4;
}else{
return -0x1.139e4275c655bp-3;
}
}
}
}else{
if(r.integer<0>()<=5870){
return 0x1.e2cfc377389bap-2;
}else{
return -0x1.639f9dd0c713cp-3;
}
}
}
}
}else{
if(r.integer<20>()<=90){
if(r.integer<47>()<=7){
if(r.integer<19>()<=24){
if(r.integer<52>()<=60){
if(r.integer<6>()<=401){
if(r.integer<55>()<=2){
return -0x1.22eabba02999ap-9;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return 0x1.d064b1db59d80p-8;
}
}else{
if(r.integer<39>()<=-7){
if(r.integer<3>()<=30){
return -0x1.ea031c1cc9c2fp-2;
}else{
return -0x1.98f1d3ed527e7p-7;
}
}else{
if(r.integer<35>()<=1){
if(r.integer<5>()<=340){
return -0x1.8be67da2ee012p-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.2dfd694ccab3fp-11;
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<6>()<=409){
if(r.integer<7>()<=-72){
return 0x1.0f94c87980f57p-5;
}else{
return -0x1.4727dcbddb986p-7;
}
}else{
return 0x1.f50275fc05a00p-5;
}
}else{
if(r.integer<5>()<=460){
if(r.integer<35>()<=3){
if(r.integer<43>()<=6){
if(r.integer<5>()<=367){
if(r.integer<1>()<=56){
return 0x1.999999999999ap-3;
}else{
return 0x1.bcf5944140114p+0;
}
}else{
if(r.integer<5>()<=400){
if(r.integer<1>()<=103){
return 0x0.0p+0;
}else{
return -0x1.4c55432873bcap-2;
}
}else{
return 0x1.fb5e859c61a00p-3;
}
}
}else{
if(r.integer<47>()<=0){
return 0x1.6f0068db8bac8p-3;
}else{
return -0x1.a91105e1c150ap-2;
}
}
}else{
if(r.integer<3>()<=100){
return 0x0.0p+0;
}else{
return 0x1.3e38caccc265dp-5;
}
}
}else{
return -0x1.f67a45407bf0fp-7;
}
}
}
}else{
if(r.integer<20>()<=46){
if(r.integer<30>()<=8){
return 0x1.72002d4c69651p+2;
}else{
if(r.integer<7>()<=-88){
return 0x1.3ee8f3f4d9dc4p+0;
}else{
return 0x1.a36371ea531a0p-6;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=39){
return 0x1.963def79caf25p-1;
}else{
return 0x1.04c287798679ap-6;
}
}
}
}else{
if(r.integer<19>()<=20){
if(r.integer<20>()<=23){
if(r.integer<3>()<=42){
return 0x1.f4468e59ca76dp-5;
}else{
return -0x1.0624dd2f1a9fdp-6;
}
}else{
if(r.integer<20>()<=81){
if(r.integer<50>()<=-80){
if(r.integer<44>()<=10){
if(r.integer<43>()<=4){
return -0x1.47ae147ae147cp-5;
}else{
return -0x1.df5133cf3a655p-2;
}
}else{
return 0x1.821ca55234804p-2;
}
}else{
if(r.integer<7>()<=49){
if(r.integer<15>()<=6){
return 0x1.fffe5280d6544p-3;
}else{
return 0x1.0385c67dfe32dp-4;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<39>()<=-2){
if(r.integer<29>()<=9){
if(r.integer<7>()<=21){
if(r.integer<5>()<=272){
return -0x1.e7dcd12f65a74p-2;
}else{
return 0x1.5cd9f5aa3ba85p+0;
}
}else{
return 0x1.cb85da9ff426cp+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=-7){
if(r.integer<30>()<=3){
if(r.integer<20>()<=49){
return 0x1.96d18873568efp+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=1){
if(r.integer<20>()<=27){
return -0x1.fa29040ddf467p-6;
}else{
if(r.integer<3>()<=61){
if(r.integer<8>()<=189){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return -0x1.0624dd2f1a9fdp-4;
}
}
}else{
if(r.integer<5>()<=19){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return -0x1.578374942692fp-6;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=1){
if(r.integer<6>()<=136){
if(r.integer<6>()<=37){
return 0x1.1ba72573570fbp-2;
}else{
if(r.integer<51>()<=126){
return -0x1.36105d455574cp-3;
}else{
if(r.integer<16>()<=5){
return 0x1.229987fbe2641p-1;
}else{
return -0x1.63c82674decf4p-5;
}
}
}
}else{
if(r.integer<47>()<=1){
if(r.integer<5>()<=21){
return -0x1.9d1e3371c76dap-3;
}else{
return 0x1.327aa68f4b620p-1;
}
}else{
if(r.integer<8>()<=108){
return 0x1.006a992601468p+3;
}else{
return -0x1.2f53aaa1ff99bp-1;
}
}
}
}else{
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=141){
if(r.integer<35>()<=3){
return -0x1.bc98a222d5174p-7;
}else{
if(r.integer<43>()<=3){
return 0x1.4f8b588e368f0p-7;
}else{
return -0x1.a36e2eb1c432fp-9;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=82){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_9(const BudgetResidualFeatures&r){
if(r.integer<53>()<=99){
if(r.integer<9>()<=24){
if(r.integer<5>()<=286){
if(r.integer<44>()<=16){
if(r.integer<53>()<=59){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1071){
if(r.integer<3>()<=88){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=73){
if(r.integer<31>()<=4121){
if(r.integer<16>()<=4){
return 0x1.c0595eccdd805p-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=883){
return 0x0.0p+0;
}else{
return -0x1.872e37a820954p-8;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<44>()<=5){
if(r.integer<0>()<=1476){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-62){
if(r.integer<6>()<=271){
if(r.integer<9>()<=4){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=8){
if(r.integer<6>()<=270){
if(r.integer<51>()<=6){
if(r.integer<24>()<=45){
if(r.integer<5>()<=32){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=71){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=24){
if(r.integer<30>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<17>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=3){
if(r.integer<1>()<=53){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=87){
if(r.integer<4>()<=480){
if(r.integer<3>()<=71){
if(r.integer<19>()<=23){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-1){
return 0x1.c7ae147ae147cp+1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.f351b6e156e74p+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<15>()<=7){
if(r.integer<52>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3333333333334p-1;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<31>()<=5057){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<32>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=4){
if(r.integer<15>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5700){
if(r.integer<17>()<=5){
return 0x0.0p+0;
}else{
return 0x1.4ac083126e979p+1;
}
}else{
return -0x1.8f1bb9db673b4p-6;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=34){
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=38){
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=56){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=14167){
if(r.integer<52>()<=52){
if(r.integer<51>()<=-27){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=42){
if(r.integer<25>()<=69){
return 0x0.0p+0;
}else{
return -0x1.89374bc6a7efap-6;
}
}else{
if(r.integer<19>()<=79){
if(r.integer<5>()<=417){
return 0x0.0p+0;
}else{
return -0x1.01cadb5b05093p-4;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=1566){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=1){
if(r.integer<51>()<=-33){
if(r.integer<36>()<=13){
return 0x1.79db40e17a368p-8;
}else{
return -0x1.0624dd2f1aa00p-7;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=33){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=45){
if(r.integer<4>()<=432){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=39){
if(r.integer<52>()<=29){
if(r.integer<3>()<=103){
if(r.integer<53>()<=61){
if(r.integer<14>()<=6){
if(r.integer<29>()<=0){
return 0x1.1b1d92b7fe08bp-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<32>()<=1){
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5934){
return 0x0.0p+0;
}else{
return -0x1.1d3671ac14c67p-8;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=90){
if(r.integer<1>()<=75){
return -0x1.b447f0af800adp-4;
}else{
if(r.integer<44>()<=7){
return 0x0.0p+0;
}else{
return -0x1.ffdf73c3712e2p-8;
}
}
}else{
if(r.integer<17>()<=4){
return 0x1.d7dbf487fcb94p-7;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<1>()<=75){
if(r.integer<44>()<=10){
if(r.integer<35>()<=5){
if(r.integer<35>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=-31){
if(r.integer<0>()<=1365){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=36){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=137){
if(r.integer<24>()<=23){
if(r.integer<53>()<=83){
if(r.integer<19>()<=54){
return -0x1.0c6f7a0b5ed8fp-13;
}else{
return -0x1.c2422f4f78e44p-4;
}
}else{
return 0x1.638103cb918e5p-2;
}
}else{
if(r.integer<3>()<=93){
return 0x0.0p+0;
}else{
return 0x1.98c7e28240b78p-1;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=4850){
if(r.integer<26>()<=69){
return -0x1.607060c3c2c08p-5;
}else{
if(r.integer<17>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1566){
if(r.integer<30>()<=11){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=477){
if(r.integer<3>()<=78){
if(r.integer<14>()<=6){
if(r.integer<1>()<=11){
if(r.integer<19>()<=64){
return 0x1.49766b9727cf5p-3;
}else{
if(r.integer<55>()<=6){
return 0x1.9524bfd2e9468p-2;
}else{
return -0x1.1d3671ac14c67p-8;
}
}
}else{
if(r.integer<3>()<=22){
if(r.integer<7>()<=-38){
if(r.integer<2>()<=306){
return 0x1.d9b1b79d909f2p-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.0f1eabe7a4eaap-12;
}
}else{
if(r.integer<4>()<=436){
if(r.integer<4>()<=414){
if(r.integer<36>()<=8){
if(r.integer<54>()<=1){
if(r.integer<26>()<=215){
return 0x1.92783d287f7b1p-3;
}else{
return -0x1.6433863f49c20p-5;
}
}else{
return -0x1.c8571c4687a3dp-9;
}
}else{
if(r.integer<19>()<=84){
return 0x1.d9b1b79d909f2p-4;
}else{
return -0x1.1d3671ac14c67p-8;
}
}
}else{
return -0x1.0c0ad03d9a953p-3;
}
}else{
if(r.integer<15>()<=7){
if(r.integer<10>()<=51){
return 0x1.3ec460ed80a18p-3;
}else{
return -0x1.c8571c4687a3dp-9;
}
}else{
return 0x1.47ae147ae147cp-2;
}
}
}
}
}else{
if(r.integer<54>()<=5){
if(r.integer<55>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=8){
if(r.integer<31>()<=8970){
return -0x1.1d3671ac14c67p-8;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<2>()<=309){
return -0x1.c8571c4687a3dp-9;
}else{
return 0x1.41e9af5ba2be2p-6;
}
}
}
}else{
if(r.integer<4>()<=438){
if(r.integer<35>()<=4){
if(r.integer<19>()<=69){
if(r.integer<18>()<=2){
return -0x1.1d3671ac14c67p-8;
}else{
return 0x1.c8571c4687a3fp-11;
}
}else{
if(r.integer<20>()<=38){
return 0x1.9608eb610c8a5p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=3){
return 0x0.0p+0;
}else{
return -0x1.1d3671ac14c67p-8;
}
}
}else{
return -0x1.1d3671ac14c67p-8;
}
}
}
}else{
if(r.integer<2>()<=247){
if(r.integer<30>()<=6){
if(r.integer<5>()<=272){
if(r.integer<19>()<=45){
return -0x1.79c6957b26e7dp-3;
}else{
return -0x1.050b01bbc1e27p-4;
}
}else{
return 0x1.4f8b588e368f2p-5;
}
}else{
if(r.integer<2>()<=206){
if(r.integer<6>()<=280){
if(r.integer<26>()<=85){
return 0x1.02c509e869befp+0;
}else{
return -0x1.3d950beb45b40p-4;
}
}else{
return -0x1.b307d4b5a4670p-2;
}
}else{
return 0x1.85421eb374613p+0;
}
}
}else{
if(r.integer<1>()<=73){
if(r.integer<2>()<=488){
if(r.integer<50>()<=35){
if(r.integer<16>()<=8){
return 0x1.f6b1a2a4db164p+0;
}else{
return 0x1.4fdbe06606c4dp-5;
}
}else{
return 0x1.5a7df2409c1edp-2;
}
}else{
return -0x1.f46ed245b291cp-3;
}
}else{
return -0x1.b0ff3348cf1e7p-3;
}
}
}
}else{
return -0x1.c8571c4687a3dp-9;
}
}
}else{
if(r.integer<5>()<=488){
if(r.integer<5>()<=471){
if(r.integer<16>()<=9){
if(r.integer<28>()<=0){
if(r.integer<20>()<=82){
if(r.integer<19>()<=81){
if(r.integer<47>()<=-7){
if(r.integer<1>()<=97){
return -0x1.55f0cd5d1584dp-4;
}else{
return 0x1.aa8b99d1a2ca7p+1;
}
}else{
if(r.integer<39>()<=1){
if(r.integer<51>()<=-70){
if(r.integer<47>()<=7){
return 0x1.4db59578a2a92p-4;
}else{
return 0x1.d6e47dc37a3dcp+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=38){
return 0x1.a8dc01c902e8cp+0;
}else{
return 0x1.711947cfa269ap-9;
}
}
}
}else{
if(r.integer<39>()<=-7){
return -0x1.465e892253114p-3;
}else{
if(r.integer<13>()<=2){
return 0x1.97f62b6ae7d57p-1;
}else{
return 0x1.92783d287f7b1p-3;
}
}
}
}else{
if(r.integer<19>()<=72){
return 0x1.9157abb8800ecp-1;
}else{
if(r.integer<20>()<=88){
return 0x1.999999999999ap-3;
}else{
return -0x1.9c0c659403867p-8;
}
}
}
}else{
if(r.integer<20>()<=88){
if(r.integer<19>()<=14){
if(r.integer<31>()<=6901){
return 0x1.ccfa9a0f8b385p-1;
}else{
if(r.integer<26>()<=152){
return 0x1.f2990f301eabdp-4;
}else{
return -0x1.1e63177c73700p-4;
}
}
}else{
if(r.integer<6>()<=136){
if(r.integer<18>()<=1){
return 0x1.450efdc9c4dafp-6;
}else{
if(r.integer<27>()<=0){
if(r.integer<35>()<=4){
if(r.integer<36>()<=0){
return 0x0.0p+0;
}else{
return 0x1.99567dbb16c1fp-3;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
if(r.integer<16>()<=6){
return -0x1.c2c8670c7e937p-5;
}else{
return -0x1.9934efcbd5561p-4;
}
}
}
}else{
if(r.integer<19>()<=86){
if(r.integer<4>()<=412){
if(r.integer<19>()<=49){
if(r.integer<19>()<=32){
if(r.integer<7>()<=-35){
return 0x1.5696e58a32f45p-1;
}else{
return -0x1.9b45cd759a48dp-4;
}
}else{
return -0x1.89efd86a8fc0ep-2;
}
}else{
if(r.integer<39>()<=0){
if(r.integer<35>()<=1){
return 0x0.0p+0;
}else{
return 0x1.33226c3b927d4p-1;
}
}else{
return -0x1.0c6f7a0b5ed8fp-13;
}
}
}else{
return 0x1.3333333333334p-1;
}
}else{
if(r.integer<13>()<=6){
if(r.integer<13>()<=1){
return -0x1.6b54e2b063e08p-5;
}else{
return 0x1.d7dbf487fcb94p-7;
}
}else{
return -0x1.999999999999ap-3;
}
}
}
}
}else{
if(r.integer<1>()<=91){
return 0x0.0p+0;
}else{
return -0x1.0624dd2f1a9fbp-4;
}
}
}
}else{
if(r.integer<5>()<=283){
return 0x1.3c46d82ba5a04p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=83){
return 0x1.6cb1a8d53359ap-6;
}else{
return 0x1.cb923a29c779ap-1;
}
}
}else{
return -0x1.be71146a45467p-8;
}
}
}
}else{
if(r.integer<44>()<=10){
if(r.integer<1>()<=87){
if(r.integer<3>()<=67){
if(r.integer<31>()<=6968){
if(r.integer<10>()<=59){
if(r.integer<39>()<=1){
return 0x0.0p+0;
}else{
return -0x1.6c467a37d4827p-5;
}
}else{
if(r.integer<3>()<=29){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=77){
if(r.integer<8>()<=36){
if(r.integer<20>()<=44){
if(r.integer<47>()<=-1){
if(r.integer<1>()<=25){
return 0x1.539781bc58354p-5;
}else{
if(r.integer<20>()<=26){
if(r.integer<43>()<=5){
if(r.integer<55>()<=4){
return -0x1.9602356465db4p-4;
}else{
return 0x1.b40c9dae6264cp-2;
}
}else{
return -0x1.2d1536f3dd071p-3;
}
}else{
return -0x1.22064b59d6c74p-3;
}
}
}else{
if(r.integer<55>()<=10){
if(r.integer<3>()<=89){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=99){
if(r.integer<43>()<=5){
if(r.integer<19>()<=51){
if(r.integer<19>()<=16){
return 0x1.1589aa0d5a30bp+0;
}else{
return 0x1.54c985f06f697p-6;
}
}else{
if(r.integer<19>()<=68){
return 0x1.fa29a7435061dp+0;
}else{
return 0x1.d2fe8c84d589ap-1;
}
}
}else{
return -0x1.8e757928e0c9ep-5;
}
}else{
if(r.integer<13>()<=4){
return 0x1.39a669e19b102p-7;
}else{
return 0x1.01b8bcca76306p-2;
}
}
}
}else{
if(r.integer<0>()<=2347){
if(r.integer<3>()<=96){
return 0x0.0p+0;
}else{
return -0x1.8c7e28240b781p-3;
}
}else{
return 0x1.4f75deff545e7p-6;
}
}
}
}else{
if(r.integer<20>()<=71){
return -0x1.ec3e5728b0ce8p-9;
}else{
if(r.integer<0>()<=1457){
return -0x1.05646cca83b17p-3;
}else{
if(r.integer<20>()<=96){
if(r.integer<15>()<=4){
if(r.integer<5>()<=351){
return 0x1.23810e8858ff7p-7;
}else{
if(r.integer<8>()<=-60){
return -0x1.0e428def1678cp-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=102){
return 0x0.0p+0;
}else{
return 0x1.e21c2e22c1e5cp-7;
}
}
}else{
if(r.integer<6>()<=46){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=11){
return -0x1.02795703f2d3dp-5;
}else{
return 0x1.3b7d84901d192p-1;
}
}
}
}
}
}
}else{
if(r.integer<3>()<=101){
if(r.integer<36>()<=18){
return 0x0.0p+0;
}else{
return 0x1.27476ca61b883p-13;
}
}else{
if(r.integer<51>()<=60){
if(r.integer<19>()<=35){
if(r.integer<8>()<=51){
if(r.integer<20>()<=49){
return -0x1.135137f86147ap-3;
}else{
if(r.integer<26>()<=81){
return -0x1.e70ae68de90cdp-6;
}else{
if(r.integer<7>()<=56){
return 0x1.0cfaba45e18bap+0;
}else{
return 0x1.aac53b0813cadp-6;
}
}
}
}else{
return -0x1.fe11be43721acp-6;
}
}else{
if(r.integer<38>()<=6){
return -0x1.45851a5ba0e59p-6;
}else{
return -0x1.fd8e35b848b15p-4;
}
}
}else{
if(r.integer<5>()<=272){
if(r.integer<35>()<=0){
if(r.integer<1>()<=62){
if(r.integer<16>()<=3){
return -0x1.ca2f8e8df7cfap-8;
}else{
return -0x1.4c0008b9620bfp-5;
}
}else{
return 0x1.310fcb01cf15bp-1;
}
}else{
if(r.integer<35>()<=5){
if(r.integer<17>()<=5){
return 0x1.8741525ac0c0dp-4;
}else{
if(r.integer<5>()<=139){
if(r.integer<0>()<=2012){
return -0x1.e7f3e70f659b0p-4;
}else{
return -0x1.eb31e7aea56f8p-6;
}
}else{
return 0x1.2ac7318af0113p-3;
}
}
}else{
if(r.integer<43>()<=2){
if(r.integer<17>()<=6){
return -0x1.12541580f0ab4p-5;
}else{
return -0x1.9de4d7db73ae8p-8;
}
}else{
return 0x1.a51baddb6ffdap-9;
}
}
}
}else{
if(r.integer<5>()<=483){
if(r.integer<19>()<=46){
return 0x1.2294d564a0e97p-7;
}else{
if(r.integer<19>()<=64){
if(r.integer<25>()<=87){
return 0x1.0538a40b6289bp-7;
}else{
if(r.integer<17>()<=6){
return -0x1.8ef42cc0b0e85p-5;
}else{
return -0x1.1c5fb2173ee16p-8;
}
}
}else{
if(r.integer<6>()<=51){
return -0x1.ee2a1d3d86260p-6;
}else{
return 0x1.d8521119d8c44p-4;
}
}
}
}else{
return -0x1.c53c8a9fd69fap-6;
}
}
}
}
}
}else{
if(r.integer<8>()<=78){
if(r.integer<3>()<=111){
if(r.integer<43>()<=5){
if(r.integer<6>()<=465){
if(r.integer<55>()<=8){
if(r.integer<47>()<=-1){
if(r.integer<20>()<=29){
if(r.integer<3>()<=97){
return 0x1.d0b8ea97b8eedp-1;
}else{
return 0x1.e486a7cf674cdp-10;
}
}else{
if(r.integer<19>()<=95){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}
}else{
if(r.integer<31>()<=5832){
return -0x1.999999999999ap-3;
}else{
return 0x1.24c3d9b410e93p-2;
}
}
}else{
if(r.integer<16>()<=9){
if(r.integer<5>()<=455){
return 0x0.0p+0;
}else{
return -0x1.0d24abb0f3527p-2;
}
}else{
return 0x1.cfcc3931ad7fap-3;
}
}
}else{
return -0x1.98f1d3ed527e4p-7;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=32){
if(r.integer<23>()<=45){
return -0x1.df736d8af2e34p-6;
}else{
return -0x1.96ed5ba75f6eap-4;
}
}else{
if(r.integer<55>()<=0){
return -0x1.0a76d16d9b63fp-4;
}else{
return 0x1.3105309675cdbp-4;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<25>()<=20){
if(r.integer<54>()<=2){
return 0x1.e0cc5e12040e7p-1;
}else{
if(r.integer<26>()<=48){
return -0x1.5084fdab3c03ap-3;
}else{
if(r.integer<1>()<=104){
if(r.integer<4>()<=75){
return 0x1.be5e4a0d3f58cp+0;
}else{
return 0x1.6d98b4c23eff4p-2;
}
}else{
return 0x1.fdf187ed1ed20p-7;
}
}
}
}else{
if(r.integer<26>()<=59){
if(r.integer<0>()<=1653){
return 0x1.374bc6a7ef9dcp-1;
}else{
if(r.integer<20>()<=48){
if(r.integer<31>()<=7411){
if(r.integer<17>()<=4){
return -0x1.12fe8a5f140cbp-3;
}else{
if(r.integer<15>()<=5){
return -0x1.088ae8fcae3bfp-2;
}else{
return 0x1.0cf0ff31230dbp-2;
}
}
}else{
return -0x1.d0e58b34a6fb7p-8;
}
}else{
if(r.integer<0>()<=1802){
return -0x1.a3de7eec684a5p-3;
}else{
return -0x1.355475a31a4bfp-4;
}
}
}
}else{
if(r.integer<25>()<=78){
if(r.integer<26>()<=163){
if(r.integer<19>()<=86){
if(r.integer<3>()<=15){
if(r.integer<26>()<=125){
return 0x1.eb5ede31cf052p-2;
}else{
return -0x1.aa7a1193fc20dp-5;
}
}else{
if(r.integer<18>()<=1){
return 0x1.7c4edb0473017p-4;
}else{
return -0x1.0721317dfc597p-5;
}
}
}else{
return -0x1.1dfd1615c1079p-5;
}
}else{
return -0x1.bc8886f7ab72cp-5;
}
}else{
if(r.integer<25>()<=125){
if(r.integer<26>()<=112){
if(r.integer<35>()<=3){
if(r.integer<53>()<=47){
return -0x1.1a7724a4a5107p-3;
}else{
return 0x1.f49716319aacfp-6;
}
}else{
if(r.integer<3>()<=28){
return 0x1.8349a108ceb0bp+0;
}else{
return -0x1.4f8b588e368e7p-6;
}
}
}else{
if(r.integer<10>()<=77){
if(r.integer<24>()<=45){
if(r.integer<22>()<=3){
if(r.integer<16>()<=4){
return 0x1.47d602808dda0p-1;
}else{
if(r.integer<18>()<=9){
return 0x1.c18d4262140b0p-3;
}else{
return -0x1.6ae378b5c9501p-2;
}
}
}else{
return -0x1.0624dd2f1a9fdp-5;
}
}else{
return 0x1.f3d3ccc641c34p-2;
}
}else{
return 0x1.9bb67f587ac07p-8;
}
}
}else{
if(r.integer<26>()<=96){
if(r.integer<6>()<=33){
return -0x1.ecd4aa10e0220p-6;
}else{
return 0x1.a0f0a5efe9317p-3;
}
}else{
if(r.integer<19>()<=40){
if(r.integer<1>()<=98){
if(r.integer<36>()<=10){
if(r.integer<55>()<=4){
if(r.integer<47>()<=0){
return 0x1.a5795cf45df18p+0;
}else{
return -0x1.1375b9d1ae9a3p-3;
}
}else{
if(r.integer<3>()<=49){
if(r.integer<33>()<=8){
if(r.integer<31>()<=7343){
return 0x1.b13b76ce93764p-2;
}else{
if(r.integer<31>()<=8743){
return -0x1.a57646ae3a3aap-2;
}else{
return 0x1.f68cefba81874p-3;
}
}
}else{
return 0x1.9f3e84d043c4dp+0;
}
}else{
return -0x1.c0c7050caf3b0p-2;
}
}
}else{
if(r.integer<51>()<=36){
return -0x1.0f8f6a15c8693p-2;
}else{
if(r.integer<39>()<=-1){
return 0x1.cec05773845c2p+1;
}else{
return -0x1.3d244dbd2234fp-4;
}
}
}
}else{
if(r.integer<3>()<=44){
if(r.integer<4>()<=287){
if(r.integer<18>()<=5){
return 0x1.35c352c7f0667p-2;
}else{
return 0x1.0c041a40f3e9ap-7;
}
}else{
if(r.integer<19>()<=7){
if(r.integer<10>()<=47){
return -0x1.f1c90597ef757p-3;
}else{
return 0x1.ced0b30b5aa72p-2;
}
}else{
return -0x1.5732ecbc565d0p-4;
}
}
}else{
if(r.integer<8>()<=30){
if(r.integer<5>()<=29){
return 0x1.f4f7b93494877p-5;
}else{
return -0x1.8d4374f4c9962p-4;
}
}else{
if(r.integer<19>()<=13){
return 0x1.e75360d024702p-4;
}else{
return -0x1.7ebaf102363adp-6;
}
}
}
}
}else{
if(r.integer<25>()<=155){
if(r.integer<26>()<=187){
return 0x1.90f9b7e7627a8p-7;
}else{
if(r.integer<6>()<=35){
return 0x1.07111652d2b50p-9;
}else{
if(r.integer<0>()<=1997){
return -0x1.cfb4de997deafp-3;
}else{
return -0x1.b51c011279aa4p-4;
}
}
}
}else{
if(r.integer<35>()<=1){
if(r.integer<36>()<=10){
if(r.integer<31>()<=6301){
if(r.integer<25>()<=193){
return -0x1.8ff80534c833bp-6;
}else{
return 0x1.99ed7c6fbd274p-2;
}
}else{
return 0x1.8d48d35882222p-13;
}
}else{
if(r.integer<6>()<=26){
return -0x1.9a5badc81c305p-4;
}else{
return 0x1.9c6471910949ap-2;
}
}
}else{
if(r.integer<31>()<=8856){
return -0x1.e857c2b49afccp-5;
}else{
if(r.integer<35>()<=3){
if(r.integer<19>()<=62){
if(r.integer<10>()<=63){
return 0x1.563d4e6a1b51cp-2;
}else{
return -0x1.578e315b97ab6p-5;
}
}else{
if(r.integer<5>()<=274){
return -0x1.ec0348dfc2c8cp-5;
}else{
return -0x1.634ed140c73cfp-4;
}
}
}else{
if(r.integer<20>()<=97){
return 0x1.e10b7325bc7cdp-6;
}else{
return -0x1.bbac68ff1d012p-4;
}
}
}
}
}
}
}
}
}
}
}
}
}else{
if(r.integer<14>()<=2){
if(r.integer<31>()<=11805){
if(r.integer<1>()<=84){
return 0x1.90f9b7e7627a4p-9;
}else{
if(r.integer<20>()<=27){
if(r.integer<25>()<=69){
return -0x1.ce37b0f14f0d4p-3;
}else{
return 0x1.50575b5b9b5c4p-2;
}
}else{
if(r.integer<19>()<=49){
return 0x1.58bb58054fa04p+0;
}else{
if(r.integer<3>()<=59){
return 0x1.798a2f994abf4p-3;
}else{
return 0x1.159d3164e314cp+0;
}
}
}
}
}else{
return 0x1.cd5f99c38b04cp-7;
}
}else{
if(r.integer<2>()<=496){
return 0x1.4071e0172c6c6p-9;
}else{
if(r.integer<20>()<=89){
return -0x1.0624dd2f1a9fdp-4;
}else{
return 0x1.b0594ea5d5674p+1;
}
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=6267){
if(r.integer<44>()<=16){
if(r.integer<43>()<=4){
if(r.integer<52>()<=28){
if(r.integer<31>()<=4485){
if(r.integer<39>()<=-7){
if(r.integer<31>()<=2071){
if(r.integer<29>()<=5){
return 0x1.f3b645a1cac08p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=186){
if(r.integer<31>()<=3570){
if(r.integer<29>()<=4){
if(r.integer<36>()<=9){
if(r.integer<5>()<=14){
return 0x1.2d77318fc5048p-1;
}else{
if(r.integer<25>()<=264){
return 0x0.0p+0;
}else{
return 0x1.c28f5c28f5c2ap-1;
}
}
}else{
if(r.integer<1>()<=85){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=190){
if(r.integer<51>()<=-107){
if(r.integer<5>()<=335){
if(r.integer<35>()<=0){
if(r.integer<0>()<=2060){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=111){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<9>()<=2){
if(r.integer<6>()<=279){
if(r.integer<0>()<=2012){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=29){
if(r.integer<39>()<=-7){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=72){
if(r.integer<6>()<=278){
if(r.integer<9>()<=9){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=89){
if(r.integer<7>()<=7){
if(r.integer<0>()<=2286){
if(r.integer<31>()<=5091){
return 0x1.683ec892ab68dp+3;
}else{
if(r.integer<6>()<=273){
return 0x0.0p+0;
}else{
return -0x1.2bb6672fba020p+0;
}
}
}else{
return 0x1.f910fa14a1fcap+2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=96){
if(r.integer<38>()<=-1){
return 0x1.c224e33b98ae4p+2;
}else{
if(r.integer<19>()<=16){
return 0x1.c95c4c710b6aap-6;
}else{
return -0x1.0cd2b05475ad6p-1;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=21){
if(r.integer<5>()<=141){
if(r.integer<43>()<=4){
if(r.integer<3>()<=50){
if(r.integer<1>()<=49){
if(r.integer<31>()<=7104){
return 0x0.0p+0;
}else{
return -0x1.5379fa97e132cp-3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=11349){
if(r.integer<23>()<=47){
if(r.integer<31>()<=8634){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.957470eb24a6bp+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<9>()<=7){
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=39){
if(r.integer<1>()<=26){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=28){
if(r.integer<9>()<=21){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7309){
if(r.integer<3>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=27){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=9537){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=442){
if(r.integer<5>()<=53){
return -0x1.ed288ce703afap-2;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.26e978d4fdf3bp-1;
}
}
}
}
}
}
}else{
if(r.integer<52>()<=52){
if(r.integer<44>()<=13){
if(r.integer<53>()<=190){
if(r.integer<31>()<=7915){
if(r.integer<36>()<=13){
if(r.integer<26>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=9203){
if(r.integer<36>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=410){
return -0x1.9ce075f6fd220p-4;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=10214){
return 0x0.0p+0;
}else{
if(r.integer<10>()<=214){
if(r.integer<38>()<=0){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.999999999999ap-2;
}
}else{
return -0x1.d7dbf487fcb94p-2;
}
}
}
}else{
if(r.integer<9>()<=44){
return 0x1.0624dd2f1a9fdp-4;
}else{
if(r.integer<0>()<=3076){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=279){
if(r.integer<52>()<=69){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<19>()<=51){
if(r.integer<20>()<=49){
if(r.integer<9>()<=38){
if(r.integer<44>()<=16){
if(r.integer<55>()<=8){
if(r.integer<55>()<=2){
if(r.integer<38>()<=1){
return 0x1.3ab430f49491fp-1;
}else{
return -0x1.e71b01b912b07p-4;
}
}else{
if(r.integer<32>()<=6){
if(r.integer<6>()<=12){
return 0x1.cd6a78e713ed4p-1;
}else{
return 0x1.1a12361eb12c0p-4;
}
}else{
if(r.integer<54>()<=6){
if(r.integer<10>()<=208){
return -0x1.283be6e98c28dp-1;
}else{
return -0x1.cb26847920ff4p-5;
}
}else{
return -0x1.04e00e9dfd817p-4;
}
}
}
}else{
if(r.integer<2>()<=230){
if(r.integer<33>()<=8){
return 0x1.2c54fb37a1e08p+0;
}else{
return 0x1.9881baac6e1b2p-6;
}
}else{
return 0x1.1ef0e11d1e9b7p-1;
}
}
}else{
if(r.integer<30>()<=1){
if(r.integer<6>()<=277){
return 0x1.01a0befcd57e3p+3;
}else{
return -0x1.8c5b429bdbe94p-2;
}
}else{
if(r.integer<31>()<=6801){
return 0x1.31a318d1e69abp+1;
}else{
if(r.integer<5>()<=471){
return -0x1.706d7b5890e5dp-6;
}else{
return 0x1.467ac9dbe7d90p+0;
}
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<51>()<=-179){
if(r.integer<36>()<=10){
if(r.integer<35>()<=1){
if(r.integer<5>()<=340){
if(r.integer<43>()<=4){
if(r.integer<0>()<=5255){
return -0x1.27f089eb50c68p-3;
}else{
if(r.integer<6>()<=409){
return -0x1.1ce080b3c4932p+2;
}else{
return 0x1.99e507c5e0e42p-2;
}
}
}else{
if(r.integer<19>()<=12){
return -0x1.37c19e819c082p-2;
}else{
return 0x1.47171e5d40d67p+0;
}
}
}else{
if(r.integer<5>()<=383){
return 0x1.3598a4625ba60p-1;
}else{
if(r.integer<5>()<=433){
return -0x1.2faae876767efp-4;
}else{
if(r.integer<5>()<=455){
return 0x1.7090d92313cdcp-1;
}else{
if(r.integer<30>()<=9){
return 0x1.14d7fe5936d30p+0;
}else{
if(r.integer<20>()<=6){
return 0x1.ff08f8e6cae97p-2;
}else{
return -0x1.6d7658aa6eb1ap-5;
}
}
}
}
}
}
}else{
if(r.integer<30>()<=6){
return 0x1.dd75bc6fb26a7p-1;
}else{
if(r.integer<20>()<=35){
return 0x1.8a289e95e8f12p-2;
}else{
if(r.integer<29>()<=6){
return 0x1.4fdb5c1d117ccp+0;
}else{
return -0x1.abfc9d9fe38afp-8;
}
}
}
}
}else{
if(r.integer<35>()<=1){
if(r.integer<43>()<=3){
return -0x1.e2a93e388614ap-2;
}else{
return 0x1.d0fca114a6efap-3;
}
}else{
return 0x1.44e40aac00797p-6;
}
}
}else{
if(r.integer<54>()<=0){
if(r.integer<6>()<=406){
return -0x1.06a5b68867c2fp-7;
}else{
return -0x1.4dd9122fa1660p-3;
}
}else{
if(r.integer<30>()<=17){
if(r.integer<47>()<=-7){
if(r.integer<30>()<=4){
return 0x1.359cba35707a4p+2;
}else{
return 0x1.d0f3a2fa6b6b8p-2;
}
}else{
if(r.integer<10>()<=152){
if(r.integer<53>()<=135){
return 0x1.0079f86988afdp-3;
}else{
return 0x1.dcee2d19be980p-1;
}
}else{
if(r.integer<20>()<=13){
return -0x1.decf5c32d6a2dp-5;
}else{
if(r.integer<5>()<=135){
return -0x1.269ba02f0a033p-7;
}else{
return 0x1.ea9d159ab4054p-4;
}
}
}
}
}else{
if(r.integer<52>()<=37){
return -0x1.db21794c721e8p-4;
}else{
return 0x1.461344315b8f7p-8;
}
}
}
}
}else{
if(r.integer<5>()<=477){
if(r.integer<35>()<=5){
if(r.integer<35>()<=1){
if(r.integer<5>()<=423){
if(r.integer<5>()<=389){
if(r.integer<5>()<=340){
if(r.integer<19>()<=24){
if(r.integer<7>()<=-40){
return 0x1.84a5744bdfdb7p-4;
}else{
return -0x1.09488f4c1ef8bp-3;
}
}else{
if(r.integer<43>()<=6){
return 0x1.4ef0fedb3cd23p-2;
}else{
if(r.integer<9>()<=45){
return 0x1.d4095fadc324ap-2;
}else{
return -0x1.e316e62085dc8p-4;
}
}
}
}else{
return 0x1.38355099cb6dap-3;
}
}else{
return -0x1.b92f24f571a07p-4;
}
}else{
if(r.integer<43>()<=6){
return -0x1.db877ab32484cp-5;
}else{
return 0x1.0370ad242b7c9p-2;
}
}
}else{
if(r.integer<35>()<=4){
if(r.integer<24>()<=26){
if(r.integer<19>()<=43){
return 0x1.13e15e54492d7p-1;
}else{
return -0x1.2cf0f9d2bf54ep-6;
}
}else{
return 0x1.a2341ce8182cdp-4;
}
}else{
if(r.integer<1>()<=91){
if(r.integer<19>()<=31){
if(r.integer<4>()<=210){
return -0x1.85b492f7c7801p-5;
}else{
return 0x1.17a46173b85e8p-1;
}
}else{
return -0x1.4f70809b9bd27p-5;
}
}else{
return -0x1.b262126ec2804p-4;
}
}
}
}else{
if(r.integer<7>()<=-92){
return -0x1.acc5456ef5005p-2;
}else{
if(r.integer<24>()<=7){
return 0x1.56415534e5badp-7;
}else{
if(r.integer<32>()<=5){
return -0x1.47ce4ad134907p-5;
}else{
return -0x1.30efb707939d3p-4;
}
}
}
}
}else{
return -0x1.b97602e68f40dp-4;
}
}
}
}else{
if(r.integer<30>()<=5){
if(r.integer<20>()<=78){
if(r.integer<8>()<=117){
if(r.integer<1>()<=19){
if(r.integer<31>()<=11131){
return 0x1.05b97d64afad2p-9;
}else{
return -0x1.01e70ae68de91p+0;
}
}else{
return -0x1.b4f10df4b5492p-5;
}
}else{
if(r.integer<31>()<=3371){
return -0x1.9eee9823a2c78p-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=49){
return -0x1.a7a8839fe5ccdp-9;
}else{
if(r.integer<51>()<=147){
if(r.integer<9>()<=38){
return 0x1.558dbfe06f04fp-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=22){
return -0x1.061212d214b54p-4;
}else{
if(r.integer<31>()<=11418){
return 0x1.4f8b588e3699ap-12;
}else{
if(r.integer<50>()<=105){
if(r.integer<52>()<=66){
if(r.integer<51>()<=-354){
return -0x1.fc60db846d040p+0;
}else{
return -0x1.2599ed7c6fbd3p-8;
}
}else{
if(r.integer<31>()<=15121){
return 0x0.0p+0;
}else{
return -0x1.e92923e5b8564p-4;
}
}
}else{
return 0x1.2dfd694ccab3fp-11;
}
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<14>()<=4){
if(r.integer<30>()<=2){
if(r.integer<6>()<=137){
if(r.integer<31>()<=3294){
return -0x1.41bd64a4f03a0p-3;
}else{
return -0x1.5e79dde77c504p-5;
}
}else{
if(r.integer<29>()<=4){
return -0x1.65ab5583c013ap-2;
}else{
if(r.integer<10>()<=121){
return -0x1.9f4d37c1376d7p-2;
}else{
return 0x1.c2488f65e40aap-1;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=0){
if(r.integer<17>()<=0){
return -0x1.060a053c7fe30p-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<46>()<=6){
if(r.integer<23>()<=45){
if(r.integer<31>()<=12606){
if(r.integer<26>()<=22){
return 0x1.5c05ba5424448p-3;
}else{
if(r.integer<24>()<=50){
return 0x1.63ad4e824412ap-9;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<13>()<=5){
return -0x1.0c6f7a0b5ed8dp-9;
}else{
return 0x1.b43526527a205p-10;
}
}
}else{
if(r.integer<46>()<=-1){
if(r.integer<3>()<=103){
return -0x1.aac53b0813cacp-4;
}else{
return 0x1.4f8b588e368f7p-12;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=362){
return -0x1.018917157054bp-3;
}else{
return 0x1.8fd2707abc5ecp-4;
}
}
}
}
}else{
if(r.integer<20>()<=82){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_10(const BudgetResidualFeatures&r){
if(r.integer<0>()<=1618){
if(r.integer<9>()<=29){
if(r.integer<5>()<=284){
if(r.integer<47>()<=7){
if(r.integer<53>()<=59){
if(r.integer<8>()<=-50){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=9){
if(r.integer<31>()<=4164){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=0){
if(r.integer<51>()<=-1){
if(r.integer<19>()<=43){
return 0x1.0d2d5c17c11e3p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<17>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=6){
return -0x1.ae0639d28a807p-5;
}else{
if(r.integer<6>()<=259){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<44>()<=8){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=5){
if(r.integer<15>()<=7){
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<29>()<=8){
if(r.integer<28>()<=0){
if(r.integer<0>()<=911){
if(r.integer<30>()<=6){
if(r.integer<25>()<=93){
return 0x1.ac29fe8951424p+0;
}else{
if(r.integer<17>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=203){
return 0x1.f2f847efb60a7p+0;
}else{
return 0x1.fe1a68284a0afp-7;
}
}
}
}else{
if(r.integer<16>()<=8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<2>()<=186){
if(r.integer<8>()<=54){
if(r.integer<30>()<=8){
if(r.integer<33>()<=5){
return -0x1.97afb48e11a64p-7;
}else{
return -0x1.d85a58b1ffeccp-4;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-1){
if(r.integer<4>()<=492){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=17){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=13){
if(r.integer<6>()<=280){
if(r.integer<22>()<=4){
if(r.integer<14>()<=3){
return 0x1.5a65a723c5d80p-4;
}else{
return 0x1.b8b83ff0efc20p-1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=0){
if(r.integer<33>()<=3){
return 0x1.7f7915455685cp+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.02e45bee99923p-6;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=97){
if(r.integer<43>()<=4){
if(r.integer<44>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=145){
if(r.integer<4>()<=450){
if(r.integer<52>()<=19){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=105){
return -0x1.3fd0d0678c006p-5;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-13){
if(r.integer<31>()<=5633){
if(r.integer<29>()<=11){
if(r.integer<20>()<=49){
if(r.integer<30>()<=4){
return 0x1.767ed761dbf44p+3;
}else{
if(r.integer<52>()<=7){
return 0x1.cb83935e88184p+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=145){
return 0x1.70a3d70a3d70bp+2;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=2){
if(r.integer<1>()<=28){
return 0x0.0p+0;
}else{
return 0x1.cdb281792a9fcp+1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=21){
if(r.integer<24>()<=39){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=591){
if(r.integer<31>()<=5125){
return 0x0.0p+0;
}else{
return 0x1.2d70d51ee37c7p-3;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<5>()<=483){
if(r.integer<31>()<=5198){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<32>()<=7){
return 0x0.0p+0;
}else{
return 0x1.0106aaccc90c6p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<8>()<=-56){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<29>()<=4){
if(r.integer<15>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=3){
return 0x1.199999999999ap+1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=-7){
return 0x0.0p+0;
}else{
if(r.integer<27>()<=0){
if(r.integer<13>()<=8){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<33>()<=6){
if(r.integer<0>()<=1205){
if(r.integer<13>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=72){
if(r.integer<31>()<=4813){
if(r.integer<26>()<=141){
return 0x1.4f0520d130dfap-1;
}else{
return -0x1.904b3c3e74afdp-4;
}
}else{
return -0x1.869835158b827p-4;
}
}else{
return -0x1.41ea31a3fa632p-3;
}
}
}else{
if(r.integer<4>()<=390){
if(r.integer<19>()<=61){
if(r.integer<20>()<=42){
return 0x0.0p+0;
}else{
return -0x1.2b21288b1d457p-4;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<53>()<=36){
if(r.integer<52>()<=38){
if(r.integer<0>()<=1384){
if(r.integer<19>()<=65){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=32){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=280){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=25){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=46){
if(r.integer<51>()<=-27){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=39){
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<36>()<=0){
if(r.integer<31>()<=3986){
if(r.integer<0>()<=1248){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=60){
return 0x0.0p+0;
}else{
return -0x1.c23b7952d2350p-3;
}
}
}else{
if(r.integer<29>()<=24){
if(r.integer<47>()<=-2){
if(r.integer<25>()<=171){
return 0x0.0p+0;
}else{
return -0x1.a0baf60ab3b84p-3;
}
}else{
if(r.integer<19>()<=17){
if(r.integer<8>()<=42){
if(r.integer<31>()<=5600){
return 0x1.7481b21c475e7p-3;
}else{
if(r.integer<30>()<=13){
return -0x1.c1a81a54aec77p-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=73){
return 0x1.22607d1859932p-2;
}else{
return 0x1.cdb532afde324p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=46){
return 0x0.0p+0;
}else{
return -0x1.5e7f3c4b34dccp-5;
}
}
}
}
}else{
if(r.integer<0>()<=1402){
if(r.integer<23>()<=57){
if(r.integer<4>()<=57){
return -0x1.d46b7ca5c2f2cp-5;
}else{
if(r.integer<29>()<=1){
return 0x1.40f974ecc8d7fp-1;
}else{
if(r.integer<46>()<=-1){
if(r.integer<2>()<=334){
if(r.integer<52>()<=32){
return 0x1.172b95b0000d7p-2;
}else{
return -0x1.0a569b17481b3p-7;
}
}else{
return -0x1.481a87260abcep-5;
}
}else{
if(r.integer<35>()<=5){
if(r.integer<51>()<=-41){
if(r.integer<1>()<=77){
return 0x0.0p+0;
}else{
return 0x1.8b0e916847bd0p+0;
}
}else{
if(r.integer<5>()<=26){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=445){
if(r.integer<20>()<=77){
if(r.integer<15>()<=2){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<18>()<=5){
return 0x1.402179843cb34p-9;
}else{
if(r.integer<16>()<=8){
return 0x0.0p+0;
}else{
return 0x1.19f3809c9bcd3p-7;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=42){
return 0x0.0p+0;
}else{
return -0x1.6ebffc2ee51adp-4;
}
}
}else{
if(r.integer<19>()<=94){
if(r.integer<3>()<=71){
if(r.integer<8>()<=-75){
return 0x1.6a3b073d0b235p-3;
}else{
if(r.integer<17>()<=4){
if(r.integer<19>()<=20){
return 0x0.0p+0;
}else{
if(r.integer<16>()<=10){
if(r.integer<4>()<=81){
return 0x1.ff63f8cddc974p-5;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.0a569b17481b3p-7;
}
}
}else{
if(r.integer<54>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<25>()<=247){
if(r.integer<7>()<=33){
if(r.integer<20>()<=90){
if(r.integer<6>()<=447){
if(r.integer<19>()<=22){
return 0x1.6a6a012599ed8p-3;
}else{
if(r.integer<31>()<=5866){
return 0x1.e6dad9c49bbfap-3;
}else{
return 0x1.ee45178c38b2dp-2;
}
}
}else{
return -0x1.27476ca61b87bp-11;
}
}else{
return -0x1.016ce789e774fp-4;
}
}else{
if(r.integer<2>()<=99){
return -0x1.999999999999ap-3;
}else{
if(r.integer<6>()<=22){
return 0x1.999999999999ap-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x1.b5e95b78cc9a7p-3;
}
}
}else{
return -0x1.0c6f7a0b5ed8fp-13;
}
}
}
}
}else{
if(r.integer<53>()<=43){
if(r.integer<7>()<=-39){
if(r.integer<31>()<=8149){
if(r.integer<35>()<=2){
return -0x1.005b19ac2389fp-11;
}else{
if(r.integer<32>()<=8){
if(r.integer<38>()<=-1){
return -0x1.98f1d3ed527e5p-2;
}else{
if(r.integer<50>()<=-46){
return -0x1.cc05db13eaf72p-6;
}else{
return -0x1.9b65b2c87ae9dp-3;
}
}
}else{
return -0x1.5ac4add5a1ee0p-7;
}
}
}else{
return 0x1.bb58a8851143ap-6;
}
}else{
if(r.integer<1>()<=72){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p-1;
}
}
}else{
if(r.integer<24>()<=47){
if(r.integer<15>()<=6){
if(r.integer<3>()<=101){
if(r.integer<31>()<=5398){
return -0x1.0a569b17481b3p-7;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.7f717a40b8d7cp-3;
}
}else{
if(r.integer<3>()<=96){
return -0x1.1c36690908303p-3;
}else{
return 0x1.36ad662a2b77ap-2;
}
}
}else{
if(r.integer<50>()<=-43){
return 0x1.a723e833fdd5ap-2;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<44>()<=16){
if(r.integer<53>()<=190){
if(r.integer<53>()<=99){
if(r.integer<52>()<=39){
if(r.integer<19>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=87){
if(r.integer<3>()<=75){
if(r.integer<31>()<=6901){
if(r.integer<13>()<=8){
return 0x0.0p+0;
}else{
return 0x1.4f8b588e368f3p-11;
}
}else{
if(r.integer<53>()<=45){
if(r.integer<4>()<=93){
if(r.integer<0>()<=1818){
return 0x0.0p+0;
}else{
return 0x1.0624dd2f1a9fbp-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=44){
if(r.integer<9>()<=35){
return -0x1.bda5119ce0767p-6;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=51){
if(r.integer<39>()<=1){
if(r.integer<3>()<=8){
if(r.integer<19>()<=30){
return -0x1.1fe44bef6cb4fp-3;
}else{
if(r.integer<31>()<=9629){
if(r.integer<0>()<=2440){
return 0x0.0p+0;
}else{
return 0x1.8d48d35882222p-13;
}
}else{
if(r.integer<33>()<=10){
return -0x1.a465249ced610p-5;
}else{
return -0x1.3333333333334p-1;
}
}
}
}else{
if(r.integer<31>()<=13115){
return 0x0.0p+0;
}else{
return 0x1.594af4f0d844dp+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<54>()<=8){
if(r.integer<3>()<=97){
if(r.integer<20>()<=66){
if(r.integer<4>()<=120){
if(r.integer<8>()<=42){
if(r.integer<19>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=50){
return 0x1.b147ad8b0a822p-1;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.14968ff9dda72p-1;
}
}else{
if(r.integer<33>()<=2){
if(r.integer<53>()<=38){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=91){
return 0x1.998ad6075e184p-3;
}else{
if(r.integer<20>()<=54){
if(r.integer<0>()<=2212){
return -0x1.374261796ca84p-6;
}else{
return 0x1.f6deef0e4034ap-2;
}
}else{
return -0x1.eb928ab19f49fp-6;
}
}
}
}else{
if(r.integer<44>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=22){
if(r.integer<19>()<=37){
return 0x0.0p+0;
}else{
return 0x1.9b3c5bfbd44c5p-2;
}
}else{
if(r.integer<20>()<=53){
if(r.integer<51>()<=42){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<43>()<=5){
return 0x1.e6766dcfcf265p-2;
}else{
return -0x1.5255625d175d5p-4;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=10214){
if(r.integer<17>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<19>()<=40){
if(r.integer<2>()<=3){
return 0x1.2ad81adea8977p-6;
}else{
if(r.integer<55>()<=7){
if(r.integer<0>()<=3378){
if(r.integer<46>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.769cd92df2f14p-2;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=450){
if(r.integer<26>()<=243){
if(r.integer<38>()<=-2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=36){
if(r.integer<31>()<=8458){
return -0x1.23d5e1e3233f4p-4;
}else{
if(r.integer<26>()<=46){
return -0x1.30164840e171bp-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=88){
return -0x1.328a6bd4397dap-5;
}else{
if(r.integer<51>()<=63){
return 0x1.73c9f3a0ee6f0p-2;
}else{
return -0x1.dc4e1f1cd0c62p-6;
}
}
}
}
}
}else{
if(r.integer<19>()<=52){
return 0x0.0p+0;
}else{
if(r.integer<10>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=93){
return -0x1.f08c6dd7b6f04p-6;
}else{
return 0x1.10a137f38c543p-8;
}
}
}
}
}
}else{
if(r.integer<19>()<=95){
return 0x0.0p+0;
}else{
return 0x1.75b665823ad87p-3;
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<44>()<=13){
if(r.integer<19>()<=58){
if(r.integer<51>()<=-25){
if(r.integer<19>()<=50){
if(r.integer<13>()<=7){
if(r.integer<33>()<=2){
return 0x1.22749f0e4da0ap-5;
}else{
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
return -0x1.32b55ef1fddecp-4;
}
}
}else{
if(r.integer<1>()<=114){
return 0x1.8779f62a0220dp-3;
}else{
return -0x1.9510146c95f7cp-4;
}
}
}else{
if(r.integer<6>()<=454){
if(r.integer<3>()<=44){
if(r.integer<18>()<=2){
return -0x1.47ae147ae147cp-4;
}else{
return 0x1.51eb851eb851fp+0;
}
}else{
return 0x1.5e9e1b089a028p-1;
}
}else{
return -0x1.48344c37e6f72p-4;
}
}
}else{
if(r.integer<1>()<=94){
if(r.integer<53>()<=95){
return 0x0.0p+0;
}else{
return 0x1.4510646afd68cp+2;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<14>()<=4){
if(r.integer<3>()<=65){
if(r.integer<38>()<=0){
if(r.integer<24>()<=57){
if(r.integer<53>()<=38){
if(r.integer<16>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.842dbb68e60c7p-5;
}
}else{
return 0x1.2eb4e30ff402bp-2;
}
}else{
if(r.integer<19>()<=85){
return 0x1.4227f646cc4cdp-8;
}else{
return 0x1.d70a3d70a3d70p-1;
}
}
}else{
if(r.integer<15>()<=5){
return 0x1.4a8d4a896eb1cp+0;
}else{
return -0x1.7ece44cf9b66cp-5;
}
}
}else{
if(r.integer<26>()<=220){
if(r.integer<2>()<=170){
if(r.integer<50>()<=-44){
return 0x1.7edd4d1a0688fp-6;
}else{
return 0x1.518e45b117c32p-1;
}
}else{
if(r.integer<4>()<=426){
if(r.integer<50>()<=-60){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae1480p-5;
}
}else{
return 0x1.328958f37afb3p-7;
}
}
}else{
if(r.integer<5>()<=33){
if(r.integer<5>()<=26){
if(r.integer<25>()<=193){
return 0x1.a4552bcddb8d0p-2;
}else{
return -0x1.16b2ec485f8cbp-4;
}
}else{
return -0x1.b5abf074a1dc8p-3;
}
}else{
if(r.integer<13>()<=7){
return 0x1.0a42bdd983ae3p-3;
}else{
return 0x1.7de83158f2c85p-2;
}
}
}
}
}
}else{
if(r.integer<19>()<=95){
if(r.integer<53>()<=71){
return -0x1.55af4dcfb079ap-8;
}else{
if(r.integer<25>()<=207){
return -0x1.1bf859179e573p-3;
}else{
return 0x1.5ba91e1bf4d35p-2;
}
}
}else{
return 0x1.13198d44cc8dbp+0;
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<43>()<=2){
if(r.integer<53>()<=87){
if(r.integer<20>()<=52){
if(r.integer<51>()<=3){
if(r.integer<8>()<=-78){
return 0x1.bfba6a9f8617cp+0;
}else{
if(r.integer<4>()<=151){
return -0x1.aa9e936d49734p-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=47){
return 0x1.00d1b71758e22p+1;
}else{
return 0x1.0fc55eb32d833p-3;
}
}
}else{
if(r.integer<28>()<=0){
if(r.integer<19>()<=11){
if(r.integer<36>()<=7){
return 0x1.0624dd2f1a9fdp-7;
}else{
return -0x1.2839042d8c2a4p-3;
}
}else{
if(r.integer<53>()<=63){
if(r.integer<19>()<=40){
if(r.integer<30>()<=7){
return -0x1.2ff724cb4cab3p-3;
}else{
if(r.integer<36>()<=3){
return 0x1.df26fdabf8fdfp-1;
}else{
if(r.integer<6>()<=395){
return 0x1.0a0ecca183c8dp-1;
}else{
return -0x1.370f1c0de3d4ap-3;
}
}
}
}else{
return 0x1.1e0bd7f02e8b3p+0;
}
}else{
return 0x1.2443f0df6a782p-3;
}
}
}else{
if(r.integer<19>()<=25){
if(r.integer<20>()<=85){
if(r.integer<35>()<=6){
if(r.integer<35>()<=2){
if(r.integer<38>()<=0){
if(r.integer<19>()<=20){
if(r.integer<36>()<=5){
return 0x1.71ed024c6080cp-1;
}else{
return -0x1.6d6dc1a47a9e4p-4;
}
}else{
return -0x1.149484d406ca7p-3;
}
}else{
return -0x1.75297ea7c6703p-2;
}
}else{
return 0x1.d15e13d85616dp-1;
}
}else{
return -0x1.1aac4b197b48bp-4;
}
}else{
return -0x1.482eedd42e6cdp-5;
}
}else{
if(r.integer<10>()<=31){
if(r.integer<19>()<=37){
return 0x1.404ea4a8c154dp-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=0){
if(r.integer<1>()<=99){
if(r.integer<5>()<=58){
return 0x1.05829842a3e10p-1;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<25>()<=153){
if(r.integer<35>()<=1){
return -0x1.1b1d09479ec78p-4;
}else{
return 0x1.1f268343e4280p-6;
}
}else{
return -0x1.0b7ef564acb92p-3;
}
}
}else{
return -0x1.bf57aa72152c7p-3;
}
}
}
}
}
}else{
return -0x1.6bf70540c2cf2p-6;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<4>()<=470){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=54){
return -0x1.a4d333993499fp-3;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=21){
if(r.integer<2>()<=530){
if(r.integer<19>()<=12){
return -0x1.541c61e06fc1fp-3;
}else{
if(r.integer<19>()<=55){
if(r.integer<20>()<=81){
if(r.integer<0>()<=2891){
if(r.integer<6>()<=46){
if(r.integer<19>()<=44){
return -0x1.7df70988d62d4p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=45){
return 0x1.1d862b5b561a7p-3;
}else{
return -0x1.d82b697f0e6ccp-5;
}
}
}else{
return 0x1.ce5639c878aa4p-1;
}
}else{
return 0x1.1167feb95065ap-1;
}
}else{
if(r.integer<8>()<=-36){
return -0x1.b13346dce6d40p-5;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x1.f5a5332acfb77p-1;
}
}else{
if(r.integer<20>()<=78){
if(r.integer<0>()<=2347){
return 0x1.220e14373bf8dp-1;
}else{
if(r.integer<1>()<=97){
return -0x1.102af9059878fp-2;
}else{
return 0x1.1115fcec7a3c3p-2;
}
}
}else{
if(r.integer<7>()<=-57){
if(r.integer<36>()<=10){
return 0x1.6f268705f6c2cp-4;
}else{
return -0x1.6c25ff2951997p-2;
}
}else{
return -0x1.8b233dd67d0a4p-4;
}
}
}
}
}
}else{
if(r.integer<19>()<=47){
if(r.integer<20>()<=60){
if(r.integer<51>()<=15){
return 0x1.19aa760ac931cp-1;
}else{
return 0x1.bf16b11c6d1e2p+3;
}
}else{
if(r.integer<20>()<=95){
return 0x1.5557ed9f21bb2p-1;
}else{
return 0x1.3f048fb81726fp+2;
}
}
}else{
if(r.integer<31>()<=8528){
return 0x1.1ea3034fc0b29p+0;
}else{
if(r.integer<31>()<=10804){
return -0x1.0624dd2f1a9fbp-6;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<5>()<=345){
if(r.integer<29>()<=10){
if(r.integer<50>()<=15){
if(r.integer<8>()<=-108){
if(r.integer<51>()<=-125){
if(r.integer<38>()<=-1){
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=149){
if(r.integer<19>()<=62){
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=26){
if(r.integer<5>()<=22){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=91){
if(r.integer<19>()<=37){
if(r.integer<5>()<=280){
if(r.integer<27>()<=0){
if(r.integer<30>()<=7){
if(r.integer<9>()<=6){
return 0x0.0p+0;
}else{
return 0x1.26e978d4fdf3bp-3;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<55>()<=7){
return 0x1.2203576fcae08p-1;
}else{
return -0x1.cdcaf98df5f74p-5;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<46>()<=-1){
return -0x1.421f5f40d8367p-12;
}else{
if(r.integer<3>()<=90){
if(r.integer<1>()<=76){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=32){
return 0x1.05bc01a36e2ebp+0;
}else{
if(r.integer<36>()<=4){
return -0x1.54c985f06f695p-6;
}else{
return 0x1.e49210634f85ap-2;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<0>()<=2561){
if(r.integer<1>()<=85){
return 0x1.0624dd2f1a9fdp-7;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=22){
if(r.integer<31>()<=4485){
if(r.integer<36>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-108){
if(r.integer<53>()<=137){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=0){
if(r.integer<8>()<=87){
if(r.integer<43>()<=2){
return -0x1.426fe718a86d8p-5;
}else{
if(r.integer<50>()<=83){
return 0x0.0p+0;
}else{
return -0x1.2d9711ffdcc49p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=5){
if(r.integer<44>()<=13){
if(r.integer<31>()<=6633){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=45){
if(r.integer<9>()<=39){
return 0x0.0p+0;
}else{
return -0x1.0624dd2f1a9fdp-4;
}
}else{
if(r.integer<4>()<=251){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-122){
if(r.integer<2>()<=158){
return 0x1.674883e85a848p-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=108){
if(r.integer<19>()<=39){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<3>()<=79){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=111){
if(r.integer<23>()<=32){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=389){
return 0x1.47ae147ae147cp-3;
}else{
if(r.integer<5>()<=433){
if(r.integer<19>()<=60){
if(r.integer<53>()<=135){
return -0x1.b631a180f846fp-5;
}else{
return 0x1.05186db50f40fp-6;
}
}else{
return -0x1.7c1bda5119ce0p-5;
}
}else{
return 0x1.eabbcb1cc964dp-7;
}
}
}
}else{
if(r.integer<3>()<=89){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<8>()<=129){
if(r.integer<7>()<=80){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=49){
if(r.integer<8>()<=-111){
return 0x1.8e260431cf167p-5;
}else{
if(r.integer<20>()<=14){
return -0x1.b889405277e67p-8;
}else{
return 0x1.7194471347ad1p-1;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<7>()<=-47){
return -0x1.e0f81f585750dp-8;
}else{
if(r.integer<6>()<=37){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=4813){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=18){
if(r.integer<43>()<=5){
if(r.integer<5>()<=271){
if(r.integer<31>()<=6334){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=364){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7070){
if(r.integer<50>()<=-30){
if(r.integer<5>()<=21){
return 0x1.adea897635e75p-7;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=94){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=514){
return 0x0.0p+0;
}else{
return 0x1.bb5d1d435b14dp-3;
}
}
}
}else{
if(r.integer<50>()<=68){
if(r.integer<55>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=6){
if(r.integer<25>()<=14){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<7>()<=-12){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-199){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<6>()<=140){
if(r.integer<35>()<=2){
if(r.integer<5>()<=362){
if(r.integer<43>()<=3){
if(r.integer<51>()<=-342){
return -0x1.320627616dd93p+3;
}else{
return -0x1.6a98fb0e28b7bp-6;
}
}else{
if(r.integer<43>()<=6){
if(r.integer<6>()<=21){
return -0x1.b21c475e63615p-7;
}else{
return 0x1.c277df34ae5dap-7;
}
}else{
return -0x1.457a5d942fcd5p-8;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=12771){
if(r.integer<4>()<=243){
return 0x1.02de00d1b7176p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=6267){
if(r.integer<9>()<=2){
if(r.integer<6>()<=279){
if(r.integer<0>()<=1737){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=44){
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=95){
return -0x1.56415534e5badp-9;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<7>()<=35){
if(r.integer<36>()<=16){
if(r.integer<6>()<=284){
if(r.integer<31>()<=5364){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-21){
return 0x1.441355475a31bp-1;
}else{
if(r.integer<53>()<=288){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=26){
return -0x1.5d82e7fc53224p-6;
}else{
return 0x1.999999999999ap-1;
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<29>()<=4){
if(r.integer<50>()<=34){
return 0x0.0p+0;
}else{
return 0x1.9cd5b92f8c09cp-2;
}
}else{
if(r.integer<51>()<=81){
if(r.integer<31>()<=15121){
if(r.integer<31>()<=11571){
if(r.integer<43>()<=6){
if(r.integer<39>()<=-7){
if(r.integer<3>()<=60){
return -0x1.8a410c0ed7087p-4;
}else{
if(r.integer<25>()<=251){
if(r.integer<4>()<=75){
return -0x1.a5515dc0a5772p-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.dc725c3dee784p-3;
}
}
}else{
if(r.integer<36>()<=16){
if(r.integer<35>()<=6){
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=5140){
return 0x0.0p+0;
}else{
return 0x1.f212d77318fc7p-6;
}
}
}
}else{
if(r.integer<0>()<=3286){
return 0x0.0p+0;
}else{
return -0x1.cac083126e97ap-3;
}
}
}else{
if(r.integer<0>()<=2454){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<36>()<=16){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.3dd97f62b6ae8p-2;
}
}else{
if(r.integer<5>()<=29){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=77){
return 0x1.1d92b7fe08af0p-1;
}else{
if(r.integer<50>()<=29){
if(r.integer<50>()<=7){
if(r.integer<38>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<20>()<=46){
if(r.integer<30>()<=2){
if(r.integer<6>()<=279){
return 0x1.0b4934516b57ap+2;
}else{
return -0x1.0624dd2f1a9fbp-6;
}
}else{
if(r.integer<8>()<=-40){
if(r.integer<6>()<=276){
if(r.integer<30>()<=8){
if(r.integer<6>()<=271){
return 0x1.017f4eb035693p+2;
}else{
if(r.integer<20>()<=22){
return 0x1.d390b64622a44p-1;
}else{
if(r.integer<50>()<=51){
return -0x1.01a33810d90f6p+1;
}else{
return 0x1.3f9063bae56cdp-5;
}
}
}
}else{
if(r.integer<6>()<=274){
if(r.integer<10>()<=253){
return 0x1.ff7164c729f5ap-3;
}else{
if(r.integer<35>()<=4){
if(r.integer<5>()<=307){
return -0x1.3c6286ddd532dp+0;
}else{
return 0x1.2e465182857f0p-3;
}
}else{
if(r.integer<35>()<=6){
return 0x1.a2a59eeff69bdp-1;
}else{
return -0x1.28283d35eb746p-1;
}
}
}
}else{
if(r.integer<20>()<=35){
if(r.integer<31>()<=7615){
return -0x1.ca6ca03c4b0a0p-2;
}else{
return 0x1.d4415e8fc569dp-1;
}
}else{
return -0x1.7e8ffde471dcdp-6;
}
}
}
}else{
if(r.integer<6>()<=278){
if(r.integer<30>()<=8){
return -0x1.436fd6d28a261p+1;
}else{
return -0x1.8915bdd76683ep-3;
}
}else{
if(r.integer<7>()<=-88){
return 0x1.ea704173a2402p-1;
}else{
if(r.integer<20>()<=19){
if(r.integer<43>()<=4){
if(r.integer<31>()<=13607){
return 0x1.473bfeb3cfa5cp-1;
}else{
return -0x1.50ee60ef79b7dp-3;
}
}else{
if(r.integer<26>()<=208){
return -0x1.af7fdfdf233bap-3;
}else{
return 0x1.56fc29f662614p-2;
}
}
}else{
if(r.integer<1>()<=70){
if(r.integer<50>()<=46){
return -0x1.c22ab25b317f0p-2;
}else{
if(r.integer<26>()<=125){
return -0x1.d37442026a23dp-3;
}else{
if(r.integer<53>()<=81){
return 0x1.0786871837af6p-2;
}else{
return -0x1.783e4ad677774p-5;
}
}
}
}else{
return 0x1.ccf439f920124p-6;
}
}
}
}
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<30>()<=16){
if(r.integer<28>()<=0){
if(r.integer<8>()<=69){
return 0x1.247b49f846a33p+1;
}else{
if(r.integer<35>()<=6){
if(r.integer<30>()<=9){
if(r.integer<3>()<=93){
return 0x1.9825e6997c934p+2;
}else{
return 0x1.0f49e3bd98ec0p-2;
}
}else{
return 0x1.5af3ec7660667p-10;
}
}else{
return 0x1.2041131ab9eaap+1;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<30>()<=13){
if(r.integer<53>()<=41){
return 0x0.0p+0;
}else{
return -0x1.ebc83a96d4c34p-3;
}
}else{
if(r.integer<3>()<=28){
return 0x1.d7dbf487fcb94p-7;
}else{
if(r.integer<4>()<=535){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=28){
return 0x1.02de00d1b7177p-1;
}else{
return -0x1.93b3a68b19a42p-5;
}
}
}
}
}
}
}
}else{
if(r.integer<29>()<=14){
if(r.integer<19>()<=47){
if(r.integer<43>()<=5){
if(r.integer<10>()<=333){
if(r.integer<43>()<=2){
return 0x1.4671537f58fbap-1;
}else{
if(r.integer<32>()<=4){
return 0x1.33c3d1d16e724p-2;
}else{
return -0x1.f10bc65cc62a7p-4;
}
}
}else{
return -0x1.9c8d3eed50a60p-2;
}
}else{
if(r.integer<9>()<=48){
if(r.integer<55>()<=7){
return 0x1.03ac5ceabca1dp-1;
}else{
return -0x1.1855aeaa9a3fap-2;
}
}else{
if(r.integer<35>()<=4){
return 0x1.6a2548f5f9522p+0;
}else{
return -0x1.0e81a302cee77p-3;
}
}
}
}else{
if(r.integer<0>()<=1737){
return -0x1.0624dd2f1a9fbp-7;
}else{
if(r.integer<52>()<=42){
if(r.integer<0>()<=2167){
if(r.integer<16>()<=5){
return 0x1.a36e2eb1c432dp-4;
}else{
return 0x1.5dbd9cef69a3cp-1;
}
}else{
return 0x1.89374bc6a7f00p-5;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=277){
if(r.integer<53>()<=55){
if(r.integer<33>()<=9){
return -0x1.a36e2eb1c4334p-9;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=49){
if(r.integer<24>()<=14){
return -0x1.bd5e80a3026adp-4;
}else{
return 0x1.009c07322368cp+0;
}
}else{
if(r.integer<6>()<=264){
return 0x1.47ae147ae147ap-4;
}else{
if(r.integer<52>()<=94){
return -0x1.d7dbf487fcb94p-6;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<20>()<=87){
if(r.integer<36>()<=6){
if(r.integer<31>()<=7343){
return 0x1.7ebc489b245e3p-1;
}else{
if(r.integer<52>()<=46){
if(r.integer<26>()<=163){
return -0x1.26e978d4fdf3cp-3;
}else{
return -0x1.0c6f7a0b5ee15p-14;
}
}else{
if(r.integer<2>()<=350){
if(r.integer<31>()<=8599){
return -0x1.67dac0e777844p-2;
}else{
return 0x1.747cdd28ee162p-8;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return -0x1.18cf03deb1d1ap-6;
}
}else{
if(r.integer<51>()<=-4){
if(r.integer<50>()<=45){
return 0x1.9caf1194c1b2ap-4;
}else{
if(r.integer<6>()<=279){
return -0x1.d80d58ea38288p-4;
}else{
return 0x1.045b2e79e5f52p+1;
}
}
}else{
return -0x1.0c6f7a0b5ee15p-14;
}
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_11(const BudgetResidualFeatures&r){
if(r.integer<0>()<=1653){
if(r.integer<9>()<=29){
if(r.integer<5>()<=284){
if(r.integer<53>()<=59){
if(r.integer<44>()<=16){
if(r.integer<0>()<=1365){
if(r.integer<52>()<=9){
if(r.integer<31>()<=3443){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=0){
if(r.integer<1>()<=106){
if(r.integer<20>()<=86){
if(r.integer<33>()<=6){
if(r.integer<51>()<=6){
if(r.integer<19>()<=53){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.0e89d9f07008ap-2;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=2414){
if(r.integer<29>()<=5){
if(r.integer<38>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=28){
if(r.integer<6>()<=57){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.b5c7cd898b2ecp-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=6){
if(r.integer<31>()<=5057){
if(r.integer<53>()<=57){
if(r.integer<31>()<=4669){
if(r.integer<20>()<=8){
if(r.integer<2>()<=362){
if(r.integer<51>()<=15){
return 0x0.0p+0;
}else{
return -0x1.ff0cf396485f5p-7;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<28>()<=0){
if(r.integer<5>()<=37){
if(r.integer<26>()<=220){
if(r.integer<10>()<=31){
return 0x1.059fca896986ap+2;
}else{
if(r.integer<6>()<=373){
return 0x0.0p+0;
}else{
return 0x1.34e97ad13a138p-1;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=54){
return -0x1.47ae147ae147cp-4;
}else{
if(r.integer<3>()<=79){
if(r.integer<3>()<=64){
return 0x0.0p+0;
}else{
return 0x1.a8288a841cdf7p-1;
}
}else{
if(r.integer<26>()<=152){
return 0x0.0p+0;
}else{
return -0x1.41311610631f4p-4;
}
}
}
}
}else{
if(r.integer<51>()<=48){
if(r.integer<53>()<=41){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=18){
return 0x0.0p+0;
}else{
if(r.integer<33>()<=8){
if(r.integer<13>()<=4){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x1.597ac598fbe4fp-1;
}
}
}
}else{
if(r.integer<3>()<=64){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=46){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=20){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=117){
return 0x0.0p+0;
}else{
return 0x1.2dce28d5d6327p+0;
}
}
}
}
}
}else{
if(r.integer<3>()<=70){
return 0x0.0p+0;
}else{
return 0x1.25ccd1a51ff55p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-49){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<9>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1094){
if(r.integer<19>()<=62){
if(r.integer<52>()<=0){
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
return 0x1.b9d272ccfd9d2p+0;
}
}else{
if(r.integer<29>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=10){
if(r.integer<1>()<=77){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=97){
if(r.integer<44>()<=10){
if(r.integer<43>()<=4){
if(r.integer<51>()<=-70){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=1){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
return -0x1.5cc857f3061c8p-1;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<4>()<=60){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1307){
if(r.integer<5>()<=150){
if(r.integer<5>()<=54){
return 0x0.0p+0;
}else{
return 0x1.a36e2eb1c4300p-8;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=48){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<5>()<=483){
if(r.integer<31>()<=5198){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<8>()<=-56){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5091){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<47>()<=-7){
if(r.integer<29>()<=9){
if(r.integer<28>()<=0){
if(r.integer<19>()<=78){
if(r.integer<19>()<=69){
if(r.integer<1>()<=74){
return 0x0.0p+0;
}else{
return 0x1.1d7dbf487fcb9p+0;
}
}else{
return -0x1.0624dd2f1a9fbp-4;
}
}else{
if(r.integer<25>()<=163){
return 0x1.989775435f2b9p-4;
}else{
return 0x1.2ec3539854157p+2;
}
}
}else{
if(r.integer<7>()<=-12){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=41){
if(r.integer<52>()<=47){
if(r.integer<35>()<=3){
if(r.integer<53>()<=36){
if(r.integer<53>()<=28){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<46>()<=1){
if(r.integer<26>()<=112){
if(r.integer<25>()<=90){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=76){
if(r.integer<24>()<=19){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.10f3e58cd98f2p-3;
}
}
}else{
if(r.integer<1>()<=51){
if(r.integer<0>()<=1530){
if(r.integer<25>()<=254){
if(r.integer<54>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=37){
return 0x0.0p+0;
}else{
return 0x1.89cb78ed5a3edp-11;
}
}
}else{
return -0x1.0a569b17481b3p-7;
}
}else{
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return -0x1.9ada615fec4edp-3;
}
}
}else{
if(r.integer<2>()<=194){
return 0x1.184f821e52d16p-3;
}else{
if(r.integer<19>()<=18){
if(r.integer<5>()<=145){
return -0x1.31597a80e0cc4p-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=64){
if(r.integer<20>()<=16){
return -0x1.73d3367359940p-6;
}else{
if(r.integer<3>()<=92){
return 0x1.3897d4a612ac2p-8;
}else{
return 0x1.588c890fde9a5p-2;
}
}
}else{
if(r.integer<4>()<=331){
if(r.integer<5>()<=280){
return 0x1.156a24aae7f1ap-9;
}else{
return -0x1.fe07017c01027p-6;
}
}else{
return 0x1.9a2b5c469f432p-14;
}
}
}
}
}
}
}else{
return 0x1.96d8f4f93bc0fp-6;
}
}
}else{
if(r.integer<3>()<=45){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<26>()<=4){
return 0x1.c62a1b5c7cd8ap-2;
}else{
if(r.integer<31>()<=7104){
if(r.integer<36>()<=18){
if(r.integer<1>()<=106){
if(r.integer<54>()<=2){
if(r.integer<1>()<=1){
return 0x1.999999999999ap-3;
}else{
if(r.integer<17>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=141){
return 0x1.236b94f976cecp-7;
}else{
if(r.integer<47>()<=-2){
return -0x1.6433863f49c20p-5;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<50>()<=38){
if(r.integer<4>()<=129){
if(r.integer<5>()<=36){
return 0x1.999999999999ap-3;
}else{
if(r.integer<3>()<=80){
return 0x0.0p+0;
}else{
return -0x1.19ce075f6fd22p-4;
}
}
}else{
if(r.integer<24>()<=17){
if(r.integer<8>()<=66){
if(r.integer<9>()<=43){
return 0x0.0p+0;
}else{
return 0x1.4f8b588e368f3p-11;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=22){
if(r.integer<51>()<=48){
return 0x1.0e8858ff75968p-2;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<33>()<=1){
if(r.integer<19>()<=76){
if(r.integer<25>()<=209){
if(r.integer<1>()<=77){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=57){
if(r.integer<5>()<=460){
if(r.integer<36>()<=1){
if(r.integer<4>()<=466){
return 0x0.0p+0;
}else{
return 0x1.88f42fe82517fp-3;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<16>()<=6){
return 0x1.0bd33f4f17b7bp-2;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<23>()<=52){
if(r.integer<2>()<=160){
return -0x1.22501d35004e0p-3;
}else{
if(r.integer<17>()<=5){
return -0x1.0573b254508f3p-5;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.1f062a91790ebp-2;
}
}
}
}else{
if(r.integer<14>()<=2){
return -0x1.3a92a3055325dp-8;
}else{
if(r.integer<30>()<=3){
return 0x1.35a7cf08de986p-2;
}else{
return 0x1.191505e8d0a2dp-6;
}
}
}
}else{
if(r.integer<24>()<=47){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<25>()<=66){
if(r.integer<3>()<=88){
return 0x0.0p+0;
}else{
return -0x1.6aa5dd9716d4cp-4;
}
}else{
if(r.integer<2>()<=311){
if(r.integer<5>()<=132){
if(r.integer<29>()<=23){
if(r.integer<8>()<=51){
if(r.integer<18>()<=2){
return 0x1.f311daf3d6fcdp-4;
}else{
if(r.integer<43>()<=5){
return 0x1.57e750395bf54p-4;
}else{
if(r.integer<31>()<=6034){
return -0x1.095cf5fa42a6dp-2;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x1.4e09784ec636bp-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=9){
if(r.integer<0>()<=1548){
if(r.integer<3>()<=69){
if(r.integer<6>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=47){
return 0x0.0p+0;
}else{
return -0x1.0f4a2df528851p-5;
}
}
}else{
if(r.integer<16>()<=4){
return 0x0.0p+0;
}else{
return -0x1.aed1643635714p-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.6d127d05394ffp-11;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<53>()<=190){
if(r.integer<53>()<=99){
if(r.integer<52>()<=39){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=87){
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<13>()<=8){
if(r.integer<31>()<=7034){
if(r.integer<18>()<=4){
if(r.integer<29>()<=4){
if(r.integer<19>()<=56){
return 0x1.f456b74364080p-1;
}else{
return 0x1.f05ba363faa9ap-7;
}
}else{
if(r.integer<5>()<=25){
if(r.integer<52>()<=43){
return 0x0.0p+0;
}else{
return 0x1.e9f4381b0b3b5p-4;
}
}else{
if(r.integer<14>()<=9){
if(r.integer<2>()<=370){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<2>()<=360){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<23>()<=43){
if(r.integer<36>()<=8){
if(r.integer<19>()<=96){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=57){
if(r.integer<8>()<=36){
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.fa1bba70a9b65p-1;
}
}else{
if(r.integer<26>()<=110){
return 0x1.b526bdd9eac28p-3;
}else{
return -0x1.04fcb9db75b57p-5;
}
}
}
}else{
if(r.integer<50>()<=-57){
if(r.integer<4>()<=380){
if(r.integer<55>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=16){
if(r.integer<8>()<=-1){
return -0x1.617aaa7c511a8p-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=39){
if(r.integer<20>()<=28){
if(r.integer<19>()<=51){
if(r.integer<0>()<=2684){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
if(r.integer<38>()<=-1){
return 0x1.4cec41dd1a21ap-5;
}else{
if(r.integer<20>()<=23){
if(r.integer<18>()<=3){
if(r.integer<5>()<=271){
return 0x1.87d2625c175cdp-5;
}else{
return -0x1.eeb167db4a57fp-5;
}
}else{
return -0x1.799d5ceb10205p-5;
}
}else{
return 0x1.d46c8f8681754p-3;
}
}
}
}else{
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<18>()<=7){
return -0x1.8d0cb22ed599dp-8;
}else{
if(r.integer<19>()<=35){
if(r.integer<1>()<=42){
return -0x1.023c22f987c96p-10;
}else{
return 0x1.42808bb431532p-3;
}
}else{
if(r.integer<30>()<=15){
return 0x1.0fb4fecfd43e3p-7;
}else{
return -0x1.0c80a81747004p-7;
}
}
}
}
}
}
}else{
if(r.integer<36>()<=18){
if(r.integer<1>()<=70){
if(r.integer<0>()<=2454){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=9453){
return 0x1.7aefbdf11a67ap-3;
}else{
if(r.integer<16>()<=9){
return 0x0.0p+0;
}else{
return 0x1.e65e07361905ap-4;
}
}
}
}else{
if(r.integer<9>()<=41){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=44){
if(r.integer<5>()<=58){
return -0x1.04058cf68cd33p-5;
}else{
return -0x1.c7ddc7127011ap-4;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=23){
if(r.integer<8>()<=45){
return 0x0.0p+0;
}else{
return -0x1.8396559ff835fp-6;
}
}else{
if(r.integer<39>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=86){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=11494){
if(r.integer<54>()<=8){
return -0x1.50a8f6142a14cp-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<55>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=243){
if(r.integer<5>()<=23){
if(r.integer<43>()<=3){
return 0x0.0p+0;
}else{
return 0x1.a79fec99f1ae4p-3;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<52>()<=22){
if(r.integer<31>()<=4485){
if(r.integer<36>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=152){
if(r.integer<35>()<=5){
if(r.integer<8>()<=-108){
if(r.integer<35>()<=0){
if(r.integer<0>()<=2138){
if(r.integer<43>()<=0){
return -0x1.3333333333334p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=5091){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=331){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=7104){
if(r.integer<36>()<=16){
if(r.integer<20>()<=23){
if(r.integer<8>()<=117){
if(r.integer<3>()<=63){
if(r.integer<3>()<=61){
return 0x0.0p+0;
}else{
return -0x1.1cba6d4620ee1p-4;
}
}else{
if(r.integer<31>()<=6202){
if(r.integer<20>()<=15){
return 0x1.0ac4579cefc67p-2;
}else{
if(r.integer<35>()<=3){
return -0x1.9cd9bffa5672fp-3;
}else{
return 0x1.7dbf2623b3c0dp-4;
}
}
}else{
return 0x1.3932fc819b4b4p-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=5732){
if(r.integer<30>()<=6){
return -0x1.4f8b588e368f3p-10;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<55>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<27>()<=0){
if(r.integer<1>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<13>()<=8){
if(r.integer<5>()<=466){
return -0x1.2040e8279c265p-5;
}else{
return -0x1.7c01025e7f115p-5;
}
}else{
if(r.integer<10>()<=148){
return 0x1.a606c0e099ac0p-2;
}else{
return -0x1.2768fa955cf3fp-3;
}
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=2){
if(r.integer<52>()<=58){
if(r.integer<30>()<=11){
if(r.integer<31>()<=9163){
if(r.integer<18>()<=10){
if(r.integer<30>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=32){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=348){
if(r.integer<5>()<=23){
return -0x1.eb851eb851eb8p-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
return -0x1.a36e2eb1c432cp-7;
}
}else{
return -0x1.a9fbe76c8b43ap-4;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=23){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<14>()<=4){
if(r.integer<2>()<=215){
if(r.integer<4>()<=376){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<27>()<=0){
if(r.integer<55>()<=0){
return -0x1.af3cc400a063fp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=5){
if(r.integer<4>()<=63){
if(r.integer<4>()<=36){
return -0x1.d2e3923622fccp-4;
}else{
return -0x1.3e22831551539p-1;
}
}else{
if(r.integer<0>()<=3493){
if(r.integer<26>()<=127){
if(r.integer<55>()<=5){
return 0x1.122774e4029e7p-1;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.14fde8f97e30bp-7;
}
}else{
return -0x1.06cca2db61bb1p-3;
}
}
}else{
if(r.integer<2>()<=525){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=7){
return 0x1.37f5177748948p-1;
}else{
if(r.integer<20>()<=39){
return -0x1.8ba2847d945cap-2;
}else{
return 0x1.9ea217169cfa8p-3;
}
}
}
}
}
}
}
}
}
}else{
if(r.integer<43>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=4813){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=16){
if(r.integer<5>()<=152){
if(r.integer<43>()<=5){
if(r.integer<31>()<=6136){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=85){
if(r.integer<52>()<=12){
if(r.integer<51>()<=-318){
return -0x1.09d495182a993p+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7070){
if(r.integer<52>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=33){
if(r.integer<4>()<=36){
return 0x1.47ae147ae147ap-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=68){
if(r.integer<29>()<=17){
if(r.integer<30>()<=12){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=516){
if(r.integer<25>()<=75){
if(r.integer<50>()<=40){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=2){
if(r.integer<55>()<=1){
return 0x1.3a92a30553267p-8;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<38>()<=0){
if(r.integer<1>()<=82){
if(r.integer<31>()<=8856){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<25>()<=136){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=189){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=242){
return 0x1.4f8b588e368f7p-12;
}else{
if(r.integer<0>()<=3943){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<19>()<=84){
if(r.integer<4>()<=321){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.cd5f99c38b04ap-7;
}
}
}
}else{
if(r.integer<6>()<=409){
return 0x0.0p+0;
}else{
return 0x1.47ae147ae147cp-5;
}
}
}
}else{
if(r.integer<38>()<=-2){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=51){
if(r.integer<50>()<=50){
if(r.integer<1>()<=15){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=373){
if(r.integer<31>()<=10868){
if(r.integer<26>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.d3462400da29ap-6;
}
}else{
return 0x1.0e0bcb29227bfp-10;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<35>()<=2){
if(r.integer<31>()<=14740){
if(r.integer<6>()<=62){
return -0x1.3e7fa8bde0067p-8;
}else{
return 0x1.1a39f09a3a06dp-7;
}
}else{
return -0x1.8ac9f2fdb8fdfp-4;
}
}else{
return 0x1.cd5f99c38b04ap-7;
}
}else{
if(r.integer<54>()<=6){
if(r.integer<8>()<=239){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<52>()<=1){
if(r.integer<47>()<=-1){
if(r.integer<51>()<=123){
return 0x0.0p+0;
}else{
if(r.integer<38>()<=0){
if(r.integer<3>()<=36){
if(r.integer<3>()<=23){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.b333333333334p+1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-131){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=6103){
return 0x1.c7ae147ae147cp+1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=50){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<31>()<=6267){
if(r.integer<39>()<=-7){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=29){
if(r.integer<3>()<=73){
if(r.integer<6>()<=278){
if(r.integer<9>()<=6){
if(r.integer<6>()<=263){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<4>()<=87){
if(r.integer<1>()<=14){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=89){
if(r.integer<1>()<=73){
if(r.integer<6>()<=279){
return 0x0.0p+0;
}else{
return 0x1.26e978d4fdf3bp+0;
}
}else{
if(r.integer<1>()<=90){
return 0x1.f9c9e569ba694p+2;
}else{
return 0x1.5288631070908p-4;
}
}
}else{
if(r.integer<29>()<=6){
if(r.integer<15>()<=6){
if(r.integer<52>()<=5){
if(r.integer<32>()<=3){
return -0x1.c6b8324d1a5d0p-3;
}else{
return -0x1.0fae77352a8c7p-1;
}
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x1.4e01ce954c934p+0;
}
}else{
if(r.integer<52>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=95){
if(r.integer<2>()<=328){
return 0x1.92783d287f7b1p-3;
}else{
return -0x1.f5f96be72ecddp-9;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=26){
if(r.integer<8>()<=-108){
if(r.integer<6>()<=264){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=269){
if(r.integer<31>()<=7915){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=4){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=2091){
if(r.integer<52>()<=27){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=378){
if(r.integer<51>()<=-41){
if(r.integer<50>()<=-48){
if(r.integer<6>()<=270){
return -0x1.cd01613a3dd00p-3;
}else{
return -0x1.005b19ac2389fp-11;
}
}else{
if(r.integer<29>()<=5){
if(r.integer<14>()<=8){
if(r.integer<32>()<=2){
return 0x0.0p+0;
}else{
return 0x1.d53982d88cf47p-2;
}
}else{
return -0x1.c07479cf79d02p-7;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=29){
if(r.integer<52>()<=28){
return 0x0.0p+0;
}else{
return -0x1.c8571c4687a3dp-9;
}
}else{
if(r.integer<19>()<=48){
if(r.integer<29>()<=24){
if(r.integer<20>()<=64){
return 0x0.0p+0;
}else{
return -0x1.17733aea74990p-4;
}
}else{
if(r.integer<28>()<=0){
if(r.integer<14>()<=3){
if(r.integer<13>()<=5){
return 0x1.4298d6d1079a0p-2;
}else{
return -0x1.0791efac1fd91p-5;
}
}else{
if(r.integer<50>()<=57){
return -0x1.0436f158c8433p-8;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<15>()<=7){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return -0x1.005b19ac2389fp-11;
}
}
}
}else{
if(r.integer<7>()<=58){
if(r.integer<17>()<=0){
return 0x1.005b19ac2389fp-9;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<0>()<=2075){
if(r.integer<17>()<=6){
if(r.integer<32>()<=6){
if(r.integer<31>()<=8856){
if(r.integer<14>()<=4){
if(r.integer<31>()<=7446){
return 0x1.0cafe6b8056a3p-5;
}else{
if(r.integer<32>()<=2){
return 0x1.55c07bdb9897cp-8;
}else{
return -0x1.6d127d05394fep-9;
}
}
}else{
if(r.integer<0>()<=1900){
if(r.integer<1>()<=48){
return -0x1.cf1e46f91ef68p-9;
}else{
return -0x1.005b19ac2389fp-11;
}
}else{
return -0x1.005b19ac2389fp-11;
}
}
}else{
if(r.integer<19>()<=15){
return 0x1.2599ed7c6fbd3p-6;
}else{
if(r.integer<2>()<=129){
return -0x1.40c7c652b52eap-11;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<7>()<=36){
if(r.integer<20>()<=25){
return 0x1.c6d4903aa03a0p-8;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=87){
if(r.integer<2>()<=440){
return -0x1.40c7c652b52eap-11;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.3c458092b77d4p-4;
}
}
}else{
return -0x1.6d127d05394fep-9;
}
}
}
}else{
if(r.integer<31>()<=10320){
if(r.integer<3>()<=86){
if(r.integer<14>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<25>()<=182){
return 0x0.0p+0;
}else{
return 0x1.2a305532617c2p-2;
}
}
}else{
if(r.integer<52>()<=69){
if(r.integer<36>()<=13){
if(r.integer<31>()<=14298){
if(r.integer<31>()<=11571){
if(r.integer<52>()<=54){
if(r.integer<31>()<=11205){
return -0x1.89374bc6a7efap-3;
}else{
return -0x1.1ff2e48e8a71ep+1;
}
}else{
if(r.integer<0>()<=4812){
return 0x0.0p+0;
}else{
return 0x1.0624dd2f1a9fcp-4;
}
}
}else{
if(r.integer<52>()<=60){
return -0x1.dc91d14e3bcd4p+1;
}else{
return -0x1.999999999999ap-3;
}
}
}else{
return 0x1.b91b3f20a73f7p+0;
}
}else{
if(r.integer<20>()<=93){
if(r.integer<1>()<=8){
return -0x1.916872b020c4ap-2;
}else{
if(r.integer<53>()<=93){
return 0x1.197571f20ac9ep-3;
}else{
if(r.integer<31>()<=12194){
return 0x0.0p+0;
}else{
return -0x1.72474538ef34ep-3;
}
}
}
}else{
return 0x1.5c462700cad62p-4;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=9007){
if(r.integer<6>()<=284){
if(r.integer<30>()<=1){
if(r.integer<20>()<=44){
if(r.integer<6>()<=263){
return -0x1.d0f08cb447b4cp-3;
}else{
if(r.integer<6>()<=279){
return 0x1.4eb08bbd51c97p+2;
}else{
return -0x1.eb29b7bcf8ccdp-2;
}
}
}else{
if(r.integer<20>()<=76){
if(r.integer<5>()<=282){
return -0x1.3a92a30553263p-3;
}else{
return 0x1.34ce3de6149c7p-3;
}
}else{
if(r.integer<8>()<=-24){
return 0x1.227d028a1dfbap+0;
}else{
if(r.integer<31>()<=7378){
return -0x1.b089a02752547p-4;
}else{
return 0x1.fc8f32378ab0dp-4;
}
}
}
}
}else{
if(r.integer<26>()<=18){
return 0x1.aafd10aec648fp-1;
}else{
if(r.integer<29>()<=2){
if(r.integer<53>()<=67){
return -0x1.8ae108ddb8f20p-4;
}else{
if(r.integer<24>()<=47){
if(r.integer<36>()<=13){
return 0x1.0f9f8540f20dap+0;
}else{
if(r.integer<19>()<=32){
return -0x1.7b50ea6473834p-2;
}else{
return 0x1.662cb84d6c780p-4;
}
}
}else{
if(r.integer<31>()<=7650){
if(r.integer<19>()<=46){
if(r.integer<5>()<=269){
return 0x1.1a309c99c2f90p+2;
}else{
return 0x1.be71146a45435p-6;
}
}else{
return -0x1.0dc712f981e1ap-11;
}
}else{
return -0x1.d80e496ededafp-2;
}
}
}
}else{
if(r.integer<4>()<=446){
if(r.integer<52>()<=23){
if(r.integer<30>()<=6){
return -0x1.a9fbe76c8b43ap-4;
}else{
return -0x1.79e2c506afc78p-3;
}
}else{
if(r.integer<43>()<=3){
if(r.integer<16>()<=7){
if(r.integer<23>()<=56){
return 0x1.e88b7613a3385p-3;
}else{
if(r.integer<16>()<=2){
return 0x1.00817c8ebe40bp-2;
}else{
return -0x1.bec8683c3c09fp-3;
}
}
}else{
if(r.integer<25>()<=262){
return 0x1.c9ad5d9bbc897p-2;
}else{
return -0x1.30347b31cf85fp-2;
}
}
}else{
return 0x1.1cbe7c4ffb4b3p-5;
}
}
}else{
if(r.integer<0>()<=3041){
if(r.integer<7>()<=-47){
return 0x1.44c5a430eeaccp-1;
}else{
return -0x1.0f357d0f753dfp-3;
}
}else{
return 0x1.5182a9930be0ep-3;
}
}
}
}
}
}else{
if(r.integer<5>()<=449){
if(r.integer<26>()<=204){
if(r.integer<1>()<=90){
return -0x1.a7fb313932fc8p-5;
}else{
if(r.integer<35>()<=2){
if(r.integer<0>()<=2138){
return 0x1.2ee631f8a0903p+1;
}else{
return 0x1.6d0261da0fab7p-4;
}
}else{
if(r.integer<26>()<=122){
return 0x1.9e975a4f2be1ap-3;
}else{
return -0x1.a0209c57b9fb5p-2;
}
}
}
}else{
if(r.integer<26>()<=241){
return -0x1.a7e9206714107p-2;
}else{
return -0x1.0624dd2f1a9fbp-7;
}
}
}else{
return -0x1.d6bb6317fd4cdp-3;
}
}
}else{
if(r.integer<52>()<=55){
if(r.integer<31>()<=9629){
if(r.integer<3>()<=39){
return 0x1.414ceb2efc5bap-2;
}else{
if(r.integer<19>()<=32){
return 0x1.6774361065dcap-3;
}else{
if(r.integer<10>()<=29){
return 0x1.a36e2eb1c432cp-9;
}else{
if(r.integer<43>()<=5){
return -0x1.0624dd2f1a9fbp-7;
}else{
if(r.integer<16>()<=3){
return 0x1.81ab86ef0186dp-4;
}else{
if(r.integer<29>()<=18){
return -0x1.2154b96ac545cp-2;
}else{
return -0x1.0624dd2f1a9fbp-7;
}
}
}
}
}
}
}else{
if(r.integer<5>()<=150){
if(r.integer<29>()<=4){
return -0x1.ebd9018e75794p-1;
}else{
if(r.integer<52>()<=46){
if(r.integer<3>()<=60){
if(r.integer<0>()<=2576){
return 0x1.02988ba793825p+0;
}else{
return -0x1.009356671d791p-2;
}
}else{
return -0x1.27bb2fec56d5dp-1;
}
}else{
if(r.integer<31>()<=11494){
return -0x1.0ceedd8f2e04dp-6;
}else{
if(r.integer<3>()<=53){
return 0x0.0p+0;
}else{
return -0x1.882e736c1994fp+0;
}
}
}
}
}else{
if(r.integer<51>()<=-368){
return -0x1.face3e9c2fe77p+0;
}else{
if(r.integer<19>()<=0){
return -0x1.bebea8580992ap-2;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=11349){
if(r.integer<26>()<=18){
if(r.integer<7>()<=67){
return 0x1.0ed8ab3d5e16dp-2;
}else{
return 0x1.70473f1d90f95p+1;
}
}else{
if(r.integer<52>()<=82){
if(r.integer<10>()<=57){
if(r.integer<31>()<=10997){
if(r.integer<17>()<=2){
if(r.integer<50>()<=-61){
return 0x1.8c1aff2a851e0p-3;
}else{
if(r.integer<20>()<=47){
return 0x1.a36e2eb1c432cp-9;
}else{
if(r.integer<54>()<=2){
return 0x0.0p+0;
}else{
return -0x1.f09db7607ef0cp-4;
}
}
}
}else{
return 0x1.c14b39644fb5dp-9;
}
}else{
if(r.integer<26>()<=93){
if(r.integer<52>()<=61){
return -0x1.871499b08ed54p-3;
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<26>()<=168){
if(r.integer<8>()<=18){
return -0x1.797cc39ffd610p-9;
}else{
return -0x1.999999999999ap-1;
}
}else{
if(r.integer<17>()<=3){
return 0x1.9652bd3c36115p-5;
}else{
return -0x1.3207daaceebcbp-5;
}
}
}
}
}else{
return 0x1.797cc39ffd610p-8;
}
}else{
if(r.integer<5>()<=269){
return 0x1.5d1584cc82fb0p-1;
}else{
return 0x1.5a07b352a8439p-7;
}
}
}
}else{
if(r.integer<52>()<=75){
if(r.integer<31>()<=13030){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1949){
return 0x1.11590b0c8d2e2p-10;
}else{
return -0x1.6f0068db8bac8p-6;
}
}
}else{
if(r.integer<31>()<=15662){
if(r.integer<52>()<=100){
if(r.integer<31>()<=14583){
if(r.integer<4>()<=424){
if(r.integer<10>()<=67){
if(r.integer<19>()<=51){
if(r.integer<20>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<36>()<=3){
return 0x1.c3e03f1a721c0p-2;
}else{
if(r.integer<26>()<=256){
if(r.integer<13>()<=1){
return 0x1.9568085c57e04p-1;
}else{
return -0x1.d24d3f4df3a8fp-5;
}
}else{
return -0x1.3fd4c294ae860p-2;
}
}
}
}else{
if(r.integer<17>()<=0){
return 0x1.0b97d440b632fp-1;
}else{
if(r.integer<51>()<=-58){
return 0x1.c1b3e1bdce6ddp-1;
}else{
if(r.integer<24>()<=0){
return -0x1.d7fcd6aac713ap-2;
}else{
return 0x1.4f8b588e368f7p-11;
}
}
}
}
}else{
if(r.integer<29>()<=15){
if(r.integer<19>()<=60){
return 0x1.3e09d0e4339bcp-1;
}else{
if(r.integer<35>()<=3){
return -0x1.455f85a19510bp-4;
}else{
return 0x1.ba85664aa6864p-2;
}
}
}else{
if(r.integer<0>()<=4010){
return -0x1.b866e43aa79b8p-8;
}else{
return 0x1.64840e1719f81p-6;
}
}
}
}else{
if(r.integer<32>()<=4){
if(r.integer<0>()<=5419){
return -0x1.bda5119ce075fp-5;
}else{
return 0x1.485c74a6ef387p-3;
}
}else{
return 0x1.4f8b588e368f7p-11;
}
}
}else{
if(r.integer<4>()<=313){
return -0x1.64840e1719f80p-5;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.70f216c478d17p-4;
}
}else{
if(r.integer<0>()<=5806){
if(r.integer<5>()<=277){
if(r.integer<43>()<=2){
if(r.integer<38>()<=-1){
return -0x1.843a8cc3c8414p-1;
}else{
return 0x1.f786b4ba874ffp-6;
}
}else{
return -0x1.e7f3791be634dp-5;
}
}else{
return 0x1.11590b0c8d2e2p-10;
}
}else{
if(r.integer<52>()<=94){
return -0x1.b9522350ce8cfp+2;
}else{
return -0x1.e0c3a21377617p-1;
}
}
}
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_12(const BudgetResidualFeatures&r){
if(r.integer<0>()<=1636){
if(r.integer<9>()<=29){
if(r.integer<5>()<=286){
if(r.integer<53>()<=61){
if(r.integer<44>()<=16){
if(r.integer<52>()<=9){
if(r.integer<31>()<=3443){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=1346){
if(r.integer<50>()<=-30){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1094){
if(r.integer<0>()<=453){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=281){
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=115){
if(r.integer<51>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=274){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=28){
return 0x0.0p+0;
}else{
return 0x1.c7ae147ae147cp+1;
}
}
}
}else{
if(r.integer<24>()<=7){
return 0x1.9af0312ce2c38p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=97){
if(r.integer<43>()<=4){
if(r.integer<43>()<=2){
if(r.integer<51>()<=-70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=50){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-78){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<5>()<=483){
if(r.integer<31>()<=5198){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<8>()<=-56){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<30>()<=7){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<33>()<=4){
return 0x0.0p+0;
}else{
return 0x1.3333333333334p+1;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=-7){
if(r.integer<9>()<=9){
if(r.integer<3>()<=105){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=41){
if(r.integer<50>()<=46){
if(r.integer<52>()<=35){
if(r.integer<53>()<=36){
if(r.integer<31>()<=4521){
if(r.integer<23>()<=58){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=280){
if(r.integer<19>()<=63){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<36>()<=2){
if(r.integer<1>()<=85){
if(r.integer<47>()<=1){
if(r.integer<26>()<=70){
return -0x1.2a015b49d2b1fp-5;
}else{
if(r.integer<15>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.41f9ca86cc628p-5;
}
}else{
return 0x1.b4b96f47c27eap-6;
}
}else{
if(r.integer<16>()<=6){
if(r.integer<6>()<=281){
return 0x1.3594e24fc0dd8p-5;
}else{
if(r.integer<25>()<=158){
return 0x1.76bc63b7cf28ap-7;
}else{
return -0x1.f4262109b779dp-11;
}
}
}else{
if(r.integer<15>()<=2){
return -0x1.13404ea4a8c16p-5;
}else{
if(r.integer<6>()<=146){
return 0x0.0p+0;
}else{
return 0x1.11b418b20ec03p-8;
}
}
}
}
}
}else{
if(r.integer<10>()<=25){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=36){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=78){
if(r.integer<5>()<=134){
if(r.integer<55>()<=6){
if(r.integer<1>()<=54){
if(r.integer<18>()<=8){
if(r.integer<20>()<=40){
if(r.integer<9>()<=32){
if(r.integer<31>()<=5534){
return 0x0.0p+0;
}else{
return -0x1.6b54e2b063e08p-4;
}
}else{
if(r.integer<4>()<=303){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=52){
return 0x1.4727dcbddb984p-9;
}else{
if(r.integer<24>()<=44){
if(r.integer<26>()<=84){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=0){
return 0x1.9be172763f218p-7;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<15>()<=2){
return -0x1.21c8d2973c1c4p-5;
}else{
if(r.integer<6>()<=264){
if(r.integer<52>()<=34){
return 0x0.0p+0;
}else{
return -0x1.60c1eafe31900p-3;
}
}else{
if(r.integer<20>()<=54){
return 0x0.0p+0;
}else{
return 0x1.1ff30f81a8364p-4;
}
}
}
}
}else{
if(r.integer<6>()<=456){
if(r.integer<4>()<=318){
return 0x0.0p+0;
}else{
return 0x1.13f9a9711f746p-2;
}
}else{
return -0x1.0d8c04b093dc3p-3;
}
}
}else{
if(r.integer<47>()<=-1){
if(r.integer<3>()<=20){
return 0x0.0p+0;
}else{
return -0x1.2781680e4b0b2p-5;
}
}else{
if(r.integer<24>()<=41){
if(r.integer<26>()<=158){
return 0x1.a252b6ed4db1fp-8;
}else{
if(r.integer<20>()<=86){
if(r.integer<10>()<=55){
if(r.integer<31>()<=6801){
return 0x1.aa242b58735ecp-10;
}else{
return -0x1.735889a653deap-3;
}
}else{
if(r.integer<50>()<=30){
return -0x1.f3d3aa6a29f2cp-10;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.3c1754d2b794dp-4;
}
}
}else{
if(r.integer<25>()<=103){
return -0x1.d245bb28be17ap-10;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<0>()<=1248){
if(r.integer<50>()<=29){
return 0x0.0p+0;
}else{
return 0x1.35ed21d6ea5d0p-1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=444){
if(r.integer<20>()<=12){
if(r.integer<4>()<=205){
if(r.integer<30>()<=16){
return 0x1.31ff7e1056587p+0;
}else{
return -0x1.9cb8320b15072p-10;
}
}else{
return -0x1.edc6419850c44p-5;
}
}else{
if(r.integer<2>()<=54){
return -0x1.4904a45e15074p-4;
}else{
return 0x1.0766fc8e5b780p-4;
}
}
}else{
return -0x1.387f2274f4f48p-5;
}
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<53>()<=212){
if(r.integer<53>()<=99){
if(r.integer<9>()<=40){
if(r.integer<19>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-40){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<13>()<=8){
if(r.integer<51>()<=87){
if(r.integer<23>()<=43){
if(r.integer<31>()<=14914){
if(r.integer<43>()<=2){
if(r.integer<8>()<=27){
if(r.integer<24>()<=43){
if(r.integer<43>()<=0){
if(r.integer<36>()<=18){
if(r.integer<20>()<=98){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-3){
return 0x1.6a419246940e2p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=26){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=64){
return -0x1.47ae147ae147cp-4;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<4>()<=36){
if(r.integer<16>()<=5){
return 0x0.0p+0;
}else{
return -0x1.bf2e2a6a1ec85p-4;
}
}else{
if(r.integer<32>()<=1){
if(r.integer<14>()<=0){
return -0x1.1489f2291f2a9p-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=7){
return 0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<19>()<=74){
if(r.integer<1>()<=19){
if(r.integer<8>()<=-46){
if(r.integer<8>()<=-70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-38){
return 0x1.a36e2eb1c432fp-8;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<25>()<=124){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=66){
if(r.integer<20>()<=27){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=5){
return 0x0.0p+0;
}else{
return -0x1.c35d625bbfc47p-3;
}
}
}else{
if(r.integer<52>()<=49){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-53){
if(r.integer<5>()<=52){
return 0x1.dbb3c6c9af074p-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.e76ada54cfda0p-1;
}
}
}
}
}
}else{
if(r.integer<20>()<=56){
if(r.integer<20>()<=21){
return 0x0.0p+0;
}else{
if(r.integer<13>()<=3){
if(r.integer<25>()<=183){
return 0x0.0p+0;
}else{
return -0x1.c698f88152f32p-4;
}
}else{
if(r.integer<23>()<=4){
return -0x1.711947cfa26a4p-11;
}else{
if(r.integer<43>()<=0){
return -0x1.999999999999ap-3;
}else{
return -0x1.e4b65463a52e2p-6;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=88){
if(r.integer<24>()<=36){
if(r.integer<35>()<=2){
if(r.integer<20>()<=63){
if(r.integer<6>()<=16){
return -0x1.782d38476f2a7p-4;
}else{
if(r.integer<23>()<=31){
if(r.integer<32>()<=7){
if(r.integer<30>()<=3){
return 0x1.9148a36e14ec7p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<15>()<=5){
return -0x1.eb851eb851ec0p-4;
}else{
return 0x1.0624dd2f1aa00p-7;
}
}
}else{
return -0x1.d03806ef97d9ap-9;
}
}
}else{
if(r.integer<5>()<=362){
return -0x1.0a0b71a330713p-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<19>()<=36){
return 0x1.0ed0277539e8dp-2;
}else{
if(r.integer<6>()<=25){
if(r.integer<12>()<=3){
return -0x1.93b3a68b19a44p-6;
}else{
return 0x1.3a9f3317a1b5ap-3;
}
}else{
if(r.integer<0>()<=1917){
return -0x1.95cec6bd8d408p-3;
}else{
if(r.integer<23>()<=22){
return -0x1.0830d99a43405p-6;
}else{
return 0x1.008ea3cfdbfe7p-8;
}
}
}
}
}else{
if(r.integer<1>()<=5){
return -0x1.0e87461eb7142p-4;
}else{
if(r.integer<3>()<=6){
return 0x1.1d208a29b32e7p-2;
}else{
if(r.integer<6>()<=16){
return -0x1.3ed127f98ee4dp-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<0>()<=1704){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=29){
if(r.integer<31>()<=8251){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=62){
if(r.integer<54>()<=7){
if(r.integer<1>()<=106){
if(r.integer<20>()<=50){
return 0x0.0p+0;
}else{
return 0x1.1c477b98107d7p-3;
}
}else{
return 0x1.4bef1f65a985ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<50>()<=-52){
if(r.integer<18>()<=7){
if(r.integer<20>()<=72){
return 0x1.b73811c993f8ap-2;
}else{
return -0x1.081c3bf25fdcdp-6;
}
}else{
return -0x1.8d8502409e972p-3;
}
}else{
if(r.integer<4>()<=277){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
return 0x1.73cffdd11e0c8p-2;
}
}
}
}else{
if(r.integer<51>()<=21){
if(r.integer<23>()<=33){
if(r.integer<43>()<=6){
if(r.integer<20>()<=41){
if(r.integer<43>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=6){
if(r.integer<23>()<=22){
return 0x0.0p+0;
}else{
return -0x1.5b2c1f9272560p-3;
}
}else{
if(r.integer<19>()<=54){
return 0x0.0p+0;
}else{
if(r.integer<10>()<=23){
return 0x1.791819d2391d5p-2;
}else{
return -0x1.0624dd2f1a9fcp-5;
}
}
}
}
}else{
if(r.integer<19>()<=27){
if(r.integer<15>()<=3){
if(r.integer<50>()<=-71){
return -0x1.98d6fbfab7c1dp-3;
}else{
if(r.integer<13>()<=0){
return 0x1.2ed428e1a0997p-8;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.d5a0148ed692cp-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=21){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=83){
if(r.integer<23>()<=42){
if(r.integer<26>()<=264){
if(r.integer<31>()<=13607){
if(r.integer<24>()<=58){
if(r.integer<31>()<=12273){
if(r.integer<29>()<=3){
return 0x1.c0ca600b02928p-8;
}else{
if(r.integer<29>()<=5){
if(r.integer<19>()<=88){
if(r.integer<50>()<=-69){
return 0x0.0p+0;
}else{
return -0x1.51811b005e0a4p-3;
}
}else{
return 0x1.0ba54509778a8p-6;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.a9e9c1fcc473ap-6;
}
}else{
return 0x1.3da3c1bf1147ep-10;
}
}else{
return -0x1.eb851eb851ebap-4;
}
}else{
if(r.integer<6>()<=20){
return -0x1.e011e98596e35p-11;
}else{
return 0x1.e040783a5641cp-7;
}
}
}else{
return 0x1.a1554fbdad754p-7;
}
}else{
if(r.integer<18>()<=6){
if(r.integer<2>()<=81){
return -0x1.273224919912fp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=11418){
return -0x1.4bc4fa7074067p-5;
}else{
return -0x1.d97711c8c209ap-8;
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<55>()<=0){
if(r.integer<25>()<=60){
return 0x0.0p+0;
}else{
return -0x1.0bfb833affd33p-7;
}
}else{
if(r.integer<1>()<=68){
return 0x0.0p+0;
}else{
if(r.integer<36>()<=18){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=137){
return 0x0.0p+0;
}else{
return 0x1.4f8b588e368f3p-11;
}
}
}
}
}
}else{
if(r.integer<55>()<=1){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=147){
if(r.integer<13>()<=6){
return 0x0.0p+0;
}else{
return 0x1.334eea7c68b91p-7;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=8){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=33){
if(r.integer<24>()<=0){
return 0x1.99567dbb16c1fp-3;
}else{
if(r.integer<30>()<=9){
if(r.integer<18>()<=8){
return 0x0.0p+0;
}else{
return 0x1.072ed471096c3p-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<2>()<=45){
return -0x1.ffb480a5accdap-8;
}else{
if(r.integer<47>()<=-2){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=46){
if(r.integer<28>()<=0){
if(r.integer<10>()<=47){
return 0x1.2e473b27f43b0p-3;
}else{
if(r.integer<18>()<=4){
return 0x0.0p+0;
}else{
return 0x1.ff7caafefa4f0p-7;
}
}
}else{
if(r.integer<18>()<=4){
if(r.integer<31>()<=8149){
return -0x1.89374bc6a7efap-6;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<31>()<=4448){
if(r.integer<36>()<=13){
if(r.integer<50>()<=-28){
if(r.integer<6>()<=373){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=22){
if(r.integer<53>()<=170){
if(r.integer<52>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=107){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=335){
if(r.integer<8>()<=114){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=271){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=7343){
if(r.integer<36>()<=16){
if(r.integer<31>()<=5732){
if(r.integer<7>()<=-37){
if(r.integer<35>()<=1){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<1>()<=90){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-1){
return -0x1.9f94c17ecc1f2p-3;
}else{
if(r.integer<17>()<=4){
if(r.integer<6>()<=447){
return -0x1.0624dd2f1a9fbp-6;
}else{
return -0x1.0e12e83a109d1p-2;
}
}else{
if(r.integer<35>()<=3){
if(r.integer<4>()<=221){
return -0x1.b5a32ab3fe09fp-3;
}else{
if(r.integer<31>()<=4955){
return 0x1.d68c692f6e82ap-1;
}else{
return -0x1.e6f00e9b4e4f7p-5;
}
}
}else{
return 0x1.db005ab088182p-1;
}
}
}
}
}
}else{
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=2){
if(r.integer<3>()<=63){
if(r.integer<52>()<=50){
if(r.integer<6>()<=17){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=39){
return 0x0.0p+0;
}else{
return -0x1.0624dd2f1a9fdp-5;
}
}
}else{
if(r.integer<20>()<=23){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=129){
if(r.integer<44>()<=8){
return -0x1.64840e1719f82p-7;
}else{
return -0x1.5075d724410b6p-3;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<4>()<=255){
return 0x0.0p+0;
}else{
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<14>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<27>()<=0){
if(r.integer<1>()<=77){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<46>()<=0){
if(r.integer<26>()<=71){
return -0x1.f09b082ea2aaap-11;
}else{
if(r.integer<4>()<=120){
if(r.integer<31>()<=11064){
return 0x1.a9b8cb8e086bfp-3;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.3a92a30553262p-8;
}
}
}
}
}
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<7>()<=-90){
if(r.integer<35>()<=3){
if(r.integer<5>()<=373){
if(r.integer<26>()<=235){
return 0x1.56535f27ccb08p-5;
}else{
return -0x1.f2b3e722b9685p-7;
}
}else{
if(r.integer<5>()<=400){
return -0x1.fa63c60f79b3cp-1;
}else{
if(r.integer<5>()<=471){
return 0x1.0cdad9d5c9cbap-6;
}else{
return -0x1.999999999999ap-2;
}
}
}
}else{
if(r.integer<51>()<=135){
return -0x1.c766979fd5840p-3;
}else{
return -0x1.6ba34f158b036p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=4813){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=22){
if(r.integer<43>()<=5){
if(r.integer<5>()<=275){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=7070){
if(r.integer<6>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=19){
if(r.integer<25>()<=38){
return 0x1.900acf91ce1dap-4;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=53){
if(r.integer<52>()<=52){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-89){
if(r.integer<8>()<=216){
return -0x1.6e67f031df53ap-6;
}else{
return -0x1.9648ac413c0a8p-1;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<1>()<=74){
if(r.integer<52>()<=26){
if(r.integer<31>()<=6267){
if(r.integer<39>()<=-7){
if(r.integer<31>()<=4164){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-120){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=6){
if(r.integer<47>()<=-1){
if(r.integer<51>()<=111){
return 0x0.0p+0;
}else{
if(r.integer<54>()<=3){
return 0x1.199999999999ap+1;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-158){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<2>()<=99){
if(r.integer<3>()<=15){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=82){
return 0x0.0p+0;
}else{
return 0x1.c538f8a7c394dp-2;
}
}
}
}
}else{
if(r.integer<8>()<=-108){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=7950){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=11205){
if(r.integer<39>()<=-1){
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=2){
return 0x1.0624dd2f1aa00p-5;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<55>()<=5){
if(r.integer<31>()<=6633){
if(r.integer<5>()<=488){
if(r.integer<54>()<=0){
return 0x1.30f1ff2528726p-1;
}else{
if(r.integer<10>()<=73){
return -0x1.289f05943e90fp-8;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.604122230455cp-9;
}
}else{
if(r.integer<20>()<=53){
if(r.integer<3>()<=21){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=281){
if(r.integer<0>()<=2028){
if(r.integer<31>()<=7480){
if(r.integer<1>()<=58){
if(r.integer<54>()<=3){
return -0x1.99e1fa052b800p-5;
}else{
return 0x1.5bf91c8365c80p-3;
}
}else{
return 0x1.4e747943f9ad0p-1;
}
}else{
if(r.integer<35>()<=3){
if(r.integer<16>()<=6){
if(r.integer<4>()<=239){
return -0x1.676f611d0c918p-11;
}else{
if(r.integer<30>()<=23){
return 0x1.909914e468a01p-6;
}else{
return -0x1.c8571c4687a3dp-9;
}
}
}else{
if(r.integer<26>()<=214){
if(r.integer<0>()<=1818){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=45){
if(r.integer<13>()<=2){
return -0x1.90bda96ec90bbp-4;
}else{
if(r.integer<18>()<=4){
return 0x1.7aab213e59a5fp-6;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=59){
if(r.integer<55>()<=2){
return 0x1.ad552712ad458p-1;
}else{
return 0x1.6e081b57745b2p-3;
}
}else{
if(r.integer<1>()<=36){
return 0x1.0213df0d9fae7p-2;
}else{
return -0x1.df284416db38dp-9;
}
}
}
}
}
}else{
if(r.integer<0>()<=2242){
if(r.integer<1>()<=11){
return -0x1.40c7c652b52eap-11;
}else{
return 0x1.9858d1d346e47p-3;
}
}else{
if(r.integer<43>()<=3){
if(r.integer<5>()<=351){
if(r.integer<35>()<=2){
if(r.integer<51>()<=-248){
return -0x1.c0c8336a4d974p+1;
}else{
if(r.integer<43>()<=1){
return -0x1.290257c914b20p-4;
}else{
return 0x1.47ae147ae147cp-5;
}
}
}else{
if(r.integer<51>()<=253){
if(r.integer<30>()<=5){
if(r.integer<25>()<=30){
return -0x1.26e978d4fdf3bp-1;
}else{
return 0x1.2eda88f80bbfdp-1;
}
}else{
if(r.integer<26>()<=14){
return 0x1.d533aa22bd122p-2;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.02942ef68d906p-2;
}
}
}else{
if(r.integer<5>()<=378){
return 0x1.2524ae316a7efp-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=261){
if(r.integer<3>()<=99){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=260){
return 0x1.260a39ddea407p-3;
}else{
return 0x1.f89176b569030p-1;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<20>()<=49){
if(r.integer<30>()<=4){
return -0x1.32b55ef1fddecp-5;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-11){
return 0x0.0p+0;
}else{
return 0x1.0c771b6542415p+2;
}
}
}
}
}else{
if(r.integer<6>()<=257){
if(r.integer<9>()<=63){
if(r.integer<50>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=87){
return 0x1.d63886594af4fp-2;
}else{
return -0x1.2dfd694ccab40p-10;
}
}
}else{
return -0x1.0c6f7a0b5ed93p-13;
}
}else{
if(r.integer<31>()<=9955){
if(r.integer<3>()<=56){
if(r.integer<53>()<=47){
return -0x1.56415534e5badp-9;
}else{
if(r.integer<6>()<=259){
return 0x1.9ab4cca5e079fp-10;
}else{
if(r.integer<10>()<=83){
if(r.integer<9>()<=43){
if(r.integer<0>()<=1933){
return -0x1.cf1e46f91ef68p-9;
}else{
return -0x1.9a99f4b345bd2p-3;
}
}else{
if(r.integer<4>()<=368){
if(r.integer<31>()<=8528){
return 0x1.539aba5e93bcap-8;
}else{
return -0x1.128f23c9deb0bp-6;
}
}else{
return 0x1.6a98c41469046p-5;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<35>()<=5){
return 0x1.a057e88e0d385p-11;
}else{
if(r.integer<25>()<=257){
if(r.integer<43>()<=2){
if(r.integer<31>()<=9495){
if(r.integer<25>()<=139){
return 0x1.3404ea4a8c156p-3;
}else{
return -0x1.7a15c5ba08fafp-3;
}
}else{
return -0x1.a9a86baaaf26fp-2;
}
}else{
if(r.integer<43>()<=4){
return 0x1.7b5286b591470p-4;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.999999999999ap-3;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=23){
return -0x1.0c6f7a0b5ed93p-13;
}else{
if(r.integer<54>()<=7){
if(r.integer<26>()<=20){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=70){
if(r.integer<20>()<=12){
return -0x1.320d9945b6c33p-3;
}else{
if(r.integer<1>()<=16){
if(r.integer<53>()<=24){
return -0x1.45953586ca8a0p-4;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.005b19ac2389fp-11;
}
}
}else{
if(r.integer<31>()<=7070){
if(r.integer<26>()<=91){
return 0x1.8477d1fc3f33dp-3;
}else{
if(r.integer<26>()<=169){
if(r.integer<0>()<=2716){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<53>()<=4){
return -0x1.a9785ee161da7p-8;
}else{
if(r.integer<8>()<=57){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=3){
if(r.integer<13>()<=1){
return 0x1.4562e09fe8684p-2;
}else{
if(r.integer<23>()<=57){
return 0x0.0p+0;
}else{
return -0x1.fa43fe5c91d15p-2;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=6400){
if(r.integer<39>()<=-7){
if(r.integer<4>()<=358){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<15>()<=7){
if(r.integer<43>()<=4){
if(r.integer<53>()<=300){
if(r.integer<13>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=56){
return -0x1.0342aa9f7b5afp-3;
}else{
if(r.integer<2>()<=524){
if(r.integer<35>()<=3){
if(r.integer<5>()<=345){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=12){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=262){
return 0x0.0p+0;
}else{
return -0x1.44f22271c4e97p-2;
}
}
}
}else{
return 0x1.bb0d31c1c4054p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=29){
if(r.integer<9>()<=28){
if(r.integer<10>()<=105){
if(r.integer<14>()<=9){
if(r.integer<29>()<=1){
if(r.integer<14>()<=4){
return -0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=9046){
if(r.integer<5>()<=261){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=15){
if(r.integer<50>()<=23){
if(r.integer<3>()<=89){
if(r.integer<4>()<=173){
return 0x0.0p+0;
}else{
return 0x1.0a3d70a3d70a3p-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.5fbe5adde0e02p+1;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=13507){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<18>()<=9){
return -0x1.0624dd2f1a9fdp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=-31){
return -0x1.cbfa94dc1a9dap-4;
}else{
return 0x1.e7f3a25735fa7p-3;
}
}
}
}else{
if(r.integer<19>()<=45){
if(r.integer<43>()<=5){
if(r.integer<6>()<=258){
if(r.integer<0>()<=2810){
if(r.integer<20>()<=37){
if(r.integer<54>()<=7){
if(r.integer<8>()<=21){
if(r.integer<0>()<=2197){
return 0x1.11590b0c8d2e2p-10;
}else{
return 0x1.69f0303f9308cp-8;
}
}else{
return -0x1.f989e325fc294p-5;
}
}else{
return -0x1.d25840cd94617p-3;
}
}else{
return 0x1.65abd2ed7d657p+0;
}
}else{
if(r.integer<2>()<=239){
return 0x1.447933468e110p-2;
}else{
return -0x1.3c254a3c64347p-4;
}
}
}else{
if(r.integer<51>()<=36){
if(r.integer<14>()<=3){
if(r.integer<35>()<=1){
if(r.integer<19>()<=11){
if(r.integer<14>()<=0){
return -0x1.9e03b698d8d47p-2;
}else{
return 0x1.ae4afc1849a15p-9;
}
}else{
return 0x1.488862982e3d4p-1;
}
}else{
return 0x1.7dae81882adc5p-8;
}
}else{
if(r.integer<50>()<=-46){
if(r.integer<19>()<=7){
return -0x1.593e5fb71fbc6p-4;
}else{
if(r.integer<31>()<=9537){
return 0x1.b18da5465561dp-1;
}else{
if(r.integer<39>()<=-7){
return -0x1.195d7cbb700bbp-1;
}else{
if(r.integer<1>()<=94){
return -0x1.797cc39ffd610p-9;
}else{
if(r.integer<6>()<=263){
if(r.integer<10>()<=21){
return 0x1.11590b0c8d2e2p-10;
}else{
return 0x1.28c35073cc2fap-3;
}
}else{
if(r.integer<0>()<=4101){
if(r.integer<20>()<=35){
return 0x1.ae4afc1849a15p-9;
}else{
return -0x1.76ddaceee0f3dp-5;
}
}else{
return 0x1.a38eb35f2f0efp-2;
}
}
}
}
}
}
}else{
if(r.integer<16>()<=4){
return 0x0.0p+0;
}else{
return -0x1.276d317aaf1a4p-2;
}
}
}
}else{
if(r.integer<24>()<=52){
if(r.integer<43>()<=2){
if(r.integer<51>()<=45){
return -0x1.bda2626b042fdp-2;
}else{
if(r.integer<35>()<=3){
if(r.integer<10>()<=109){
return -0x1.26ac8982c28a0p-3;
}else{
if(r.integer<43>()<=0){
return 0x1.889f0e364344fp-1;
}else{
return 0x1.797cc39ffd610p-8;
}
}
}else{
return 0x1.62a04eb8a17c0p-1;
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<35>()<=0){
return 0x0.0p+0;
}else{
return -0x1.70a3d70a3d70bp-2;
}
}else{
if(r.integer<4>()<=303){
if(r.integer<1>()<=107){
return 0x1.26d1d9849ebe3p-4;
}else{
return -0x1.94cc7cdc23cbcp-2;
}
}else{
return 0x1.0fc74edac2d27p-2;
}
}
}
}else{
if(r.integer<8>()<=96){
if(r.integer<3>()<=57){
return -0x1.1547316448767p-3;
}else{
return -0x1.969757bc03a2ap-2;
}
}else{
if(r.integer<5>()<=472){
if(r.integer<35>()<=6){
return -0x1.e6dbeca55a420p-3;
}else{
return 0x1.25da37ccfe7e8p-2;
}
}else{
return 0x1.65ef38ab99d69p-1;
}
}
}
}
}
}else{
if(r.integer<35>()<=3){
if(r.integer<5>()<=455){
if(r.integer<20>()<=52){
if(r.integer<53>()<=71){
if(r.integer<1>()<=98){
return -0x1.a319ec989aa00p-7;
}else{
if(r.integer<53>()<=24){
return 0x1.a36e2eb1c432dp-10;
}else{
return -0x1.5379fa97e132cp-4;
}
}
}else{
if(r.integer<0>()<=2301){
return 0x1.23efad3eaed73p+1;
}else{
if(r.integer<30>()<=22){
return -0x1.0c0ad03d9a954p-3;
}else{
return 0x1.046ffc3c51142p-1;
}
}
}
}else{
return 0x1.999999999999ap-1;
}
}else{
return -0x1.150302a5071c3p-3;
}
}else{
if(r.integer<31>()<=13930){
if(r.integer<55>()<=6){
if(r.integer<24>()<=55){
return 0x1.bf7ad4b2745bfp-3;
}else{
return -0x1.06aa37a549825p-2;
}
}else{
if(r.integer<2>()<=309){
return 0x0.0p+0;
}else{
return -0x1.330ffc943c14fp-1;
}
}
}else{
return -0x1.402e262aa2702p-2;
}
}
}
}else{
if(r.integer<50>()<=-43){
if(r.integer<43>()<=3){
if(r.integer<35>()<=5){
if(r.integer<5>()<=460){
if(r.integer<8>()<=-296){
if(r.integer<35>()<=4){
return -0x1.33144bdec8197p+0;
}else{
return 0x1.36dfbb110d998p-2;
}
}else{
if(r.integer<32>()<=5){
if(r.integer<22>()<=4){
return -0x1.b55b44e0e1e37p-13;
}else{
return -0x1.bb332f47e548ap-3;
}
}else{
if(r.integer<33>()<=3){
return -0x1.0255e80b64033p-7;
}else{
if(r.integer<51>()<=-54){
return -0x1.b106d2eae4890p-7;
}else{
return 0x1.00e6afcce1c58p-5;
}
}
}
}
}else{
return 0x1.1c6d1e108c3f4p-3;
}
}else{
if(r.integer<6>()<=266){
if(r.integer<8>()<=129){
return -0x1.b866e43aa79c7p-8;
}else{
return 0x1.25460aa64c2f8p-2;
}
}else{
return 0x1.46470c2e0bac0p-2;
}
}
}else{
if(r.integer<38>()<=6){
if(r.integer<35>()<=6){
if(r.integer<0>()<=3493){
if(r.integer<35>()<=5){
if(r.integer<55>()<=8){
if(r.integer<3>()<=55){
if(r.integer<38>()<=0){
if(r.integer<31>()<=13821){
if(r.integer<18>()<=7){
if(r.integer<55>()<=6){
if(r.integer<31>()<=11730){
if(r.integer<6>()<=261){
return 0x1.e17d44349e81ap-6;
}else{
return -0x1.c7972d4cc5452p-8;
}
}else{
if(r.integer<8>()<=-81){
return -0x1.94e4532642b4dp-3;
}else{
if(r.integer<53>()<=49){
if(r.integer<43>()<=5){
return -0x1.44617984b5b88p-5;
}else{
return 0x1.040bfe3b03e1fp-6;
}
}else{
return 0x1.e605488d64367p-2;
}
}
}
}else{
if(r.integer<50>()<=-79){
return 0x1.cc667e16e4d14p-3;
}else{
if(r.integer<4>()<=412){
return -0x1.8119564e7c764p-3;
}else{
return -0x1.4d7d366190e9bp-6;
}
}
}
}else{
if(r.integer<20>()<=42){
return -0x1.3ccd0fe8ab4fap-3;
}else{
return -0x1.0c6f7a0b5ed93p-13;
}
}
}else{
return -0x1.0667f90d9d778p-2;
}
}else{
if(r.integer<2>()<=460){
return 0x1.36af1039b9280p-4;
}else{
return -0x1.89be2f5024b09p-2;
}
}
}else{
return 0x1.47e7cb2ae12a4p-3;
}
}else{
if(r.integer<13>()<=2){
if(r.integer<35>()<=3){
if(r.integer<10>()<=43){
if(r.integer<3>()<=20){
return -0x1.bff4d4532b017p-5;
}else{
return 0x1.3879c4113c687p-6;
}
}else{
return 0x1.205d17b32505fp-1;
}
}else{
return -0x1.f2cb8673189ddp-3;
}
}else{
if(r.integer<17>()<=3){
if(r.integer<0>()<=1834){
return -0x1.13de6b6087abep-1;
}else{
if(r.integer<8>()<=-73){
return -0x1.b64e054690de0p-6;
}else{
if(r.integer<2>()<=154){
return -0x1.4c560a71caa80p-4;
}else{
return 0x1.74e65bea0ba20p-2;
}
}
}
}else{
return -0x1.6f0068db8bac9p-6;
}
}
}
}else{
if(r.integer<4>()<=360){
if(r.integer<14>()<=7){
return -0x1.9a66af47bce94p-3;
}else{
return -0x1.2fd07d308253fp-5;
}
}else{
if(r.integer<19>()<=67){
return -0x1.2dc129e68e560p-2;
}else{
return 0x1.cac083126e978p-2;
}
}
}
}else{
if(r.integer<20>()<=45){
if(r.integer<1>()<=89){
return 0x0.0p+0;
}else{
return -0x1.1c9b532915b43p-3;
}
}else{
return -0x1.4f8b588e368f0p-7;
}
}
}else{
return 0x1.a36e2eb1c432cp-10;
}
}else{
return 0x1.e0828c36da87cp-4;
}
}
}else{
if(r.integer<26>()<=245){
if(r.integer<25>()<=64){
return -0x1.47ae147ae147cp-5;
}else{
if(r.integer<31>()<=9717){
if(r.integer<1>()<=79){
return 0x1.999999999999ap-3;
}else{
if(r.integer<3>()<=48){
return -0x1.47ae147ae147cp-5;
}else{
return 0x1.b52007dd44137p-3;
}
}
}else{
if(r.integer<9>()<=30){
return 0x1.bda5119ce0760p-3;
}else{
return -0x1.1eb851eb851ebp-2;
}
}
}
}else{
if(r.integer<31>()<=7243){
return 0x1.19dbc93ef8b94p+0;
}else{
return 0x1.d6baac9324b08p-3;
}
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_13(const BudgetResidualFeatures&r){
if(r.integer<0>()<=1653){
if(r.integer<9>()<=29){
if(r.integer<5>()<=284){
if(r.integer<53>()<=61){
if(r.integer<0>()<=1139){
if(r.integer<44>()<=16){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=29){
if(r.integer<33>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<23>()<=33){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=270){
if(r.integer<51>()<=-29){
if(r.integer<30>()<=2){
return 0x1.00468fcc331d5p+3;
}else{
if(r.integer<0>()<=852){
return 0x1.71887b808b502p-1;
}else{
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=453){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=97){
if(r.integer<43>()<=4){
if(r.integer<43>()<=2){
if(r.integer<51>()<=-70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=50){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-64){
if(r.integer<39>()<=0){
if(r.integer<54>()<=7){
if(r.integer<30>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=-8){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=394){
if(r.integer<32>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x1.47ae147ae1474p-4;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=0){
if(r.integer<25>()<=139){
return -0x1.4f8b588e368cdp-10;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<5>()<=483){
if(r.integer<31>()<=5198){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<8>()<=-56){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=9){
if(r.integer<31>()<=3891){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=43){
if(r.integer<52>()<=46){
if(r.integer<52>()<=35){
if(r.integer<31>()<=7782){
if(r.integer<1>()<=103){
if(r.integer<31>()<=4521){
if(r.integer<31>()<=3629){
if(r.integer<26>()<=204){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=351){
if(r.integer<6>()<=34){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.b31c82aeec452p-10;
}
}
}
}else{
if(r.integer<3>()<=91){
if(r.integer<53>()<=34){
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=7){
if(r.integer<1>()<=80){
if(r.integer<20>()<=30){
if(r.integer<16>()<=8){
if(r.integer<5>()<=54){
return 0x1.4b1096f36e6ecp-6;
}else{
if(r.integer<19>()<=70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=5057){
if(r.integer<25>()<=170){
return 0x0.0p+0;
}else{
return -0x1.b83435fdedf5fp-7;
}
}else{
if(r.integer<19>()<=6){
return 0x1.901e80d492c7ep-13;
}else{
if(r.integer<6>()<=275){
if(r.integer<24>()<=35){
if(r.integer<53>()<=38){
return -0x1.b5ecf4501799fp-11;
}else{
return 0x1.aa242b58735ecp-10;
}
}else{
if(r.integer<24>()<=50){
return -0x1.457a5d942fcd9p-8;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return -0x1.d34c42ceb1a95p-4;
}
}else{
if(r.integer<17>()<=3){
if(r.integer<5>()<=133){
return 0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=4777){
return -0x1.89374bc6a7efap-6;
}else{
if(r.integer<18>()<=9){
if(r.integer<3>()<=100){
if(r.integer<14>()<=8){
if(r.integer<50>()<=30){
return -0x1.aabf25f9bb5d8p-5;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.cac083126e980p-5;
}
}else{
if(r.integer<10>()<=21){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=6){
return 0x0.0p+0;
}else{
return -0x1.89374bc6a7efap-6;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<8>()<=36){
if(r.integer<20>()<=51){
if(r.integer<44>()<=4){
return 0x0.0p+0;
}else{
return 0x1.7689ca18bd663p-2;
}
}else{
if(r.integer<19>()<=30){
if(r.integer<8>()<=-30){
return -0x1.6c8ae798b657cp-4;
}else{
return 0x1.8b287ff76f2e7p-7;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.1daf5fcbe4e7bp-2;
}
}
}else{
if(r.integer<19>()<=47){
if(r.integer<3>()<=76){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=1){
return 0x1.a36e2eb1c432cp-9;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1365){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=5){
if(r.integer<24>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<29>()<=22){
if(r.integer<10>()<=35){
return 0x0.0p+0;
}else{
return -0x1.9966542e10c5cp-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<1>()<=104){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=10105){
return 0x0.0p+0;
}else{
if(r.integer<13>()<=2){
return -0x1.0624dd2f1a9fcp-1;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<27>()<=0){
if(r.integer<5>()<=38){
if(r.integer<54>()<=1){
if(r.integer<20>()<=54){
if(r.integer<18>()<=4){
return 0x1.eca1fbd4267c2p-9;
}else{
if(r.integer<26>()<=125){
return -0x1.44c09bb371a95p-5;
}else{
return -0x1.750495ba31ac8p-10;
}
}
}else{
if(r.integer<44>()<=8){
if(r.integer<33>()<=7){
return 0x1.2b35bc39269e4p-3;
}else{
return -0x1.8fdc8854ee5bcp-10;
}
}else{
return 0x1.01f4849e4b345p-1;
}
}
}else{
if(r.integer<35>()<=1){
return 0x0.0p+0;
}else{
return -0x1.54e9bc46c2b24p-12;
}
}
}else{
if(r.integer<15>()<=8){
if(r.integer<3>()<=7){
if(r.integer<8>()<=-52){
if(r.integer<32>()<=4){
return -0x1.6d127d05394fep-9;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=461){
if(r.integer<51>()<=63){
if(r.integer<1>()<=49){
return -0x1.1e2444613aa3fp-3;
}else{
if(r.integer<26>()<=6){
return 0x1.19b8b0dc9170fp+0;
}else{
if(r.integer<36>()<=18){
if(r.integer<3>()<=58){
if(r.integer<6>()<=38){
if(r.integer<5>()<=150){
return 0x1.827e922fac90dp-3;
}else{
return -0x1.c4e3f5327197ap-4;
}
}else{
if(r.integer<55>()<=8){
return 0x1.87f72fcccc4bdp-1;
}else{
return 0x1.6a4873365881ap-5;
}
}
}else{
if(r.integer<15>()<=5){
if(r.integer<6>()<=18){
return 0x1.dac6354a8dc3cp-2;
}else{
if(r.integer<6>()<=23){
return -0x1.4ba0bc149c6d4p-3;
}else{
if(r.integer<26>()<=237){
if(r.integer<20>()<=15){
if(r.integer<5>()<=58){
return 0x1.3569f6113472ep+0;
}else{
return 0x1.ef89714a9e734p-5;
}
}else{
if(r.integer<39>()<=0){
if(r.integer<20>()<=73){
if(r.integer<8>()<=39){
if(r.integer<30>()<=8){
if(r.integer<0>()<=1476){
return -0x1.7215b79b63fe8p-4;
}else{
return 0x1.2f3913f7f8825p-1;
}
}else{
if(r.integer<14>()<=3){
return -0x1.992d9a602d015p-3;
}else{
return -0x1.32c12e9a2d797p-3;
}
}
}else{
if(r.integer<43>()<=1){
if(r.integer<6>()<=362){
return -0x1.2ba16e7a311e8p-3;
}else{
return 0x1.f83b93e97c3c0p-3;
}
}else{
return 0x1.c9165ee716244p-2;
}
}
}else{
if(r.integer<1>()<=94){
if(r.integer<36>()<=5){
return 0x1.14e49392ef5b7p+0;
}else{
return 0x1.89019be172765p-7;
}
}else{
return -0x1.32a7ae4080dfep-3;
}
}
}else{
if(r.integer<25>()<=161){
if(r.integer<31>()<=6068){
return -0x1.a51ba6fc38074p-2;
}else{
return -0x1.a2f2b3bc2f9bdp-5;
}
}else{
return 0x1.be1ca823c2747p-2;
}
}
}
}else{
if(r.integer<3>()<=94){
return -0x1.6afc088acf379p-3;
}else{
return 0x1.34fe6d0b79b96p-2;
}
}
}
}
}else{
if(r.integer<39>()<=0){
if(r.integer<6>()<=432){
if(r.integer<44>()<=17){
if(r.integer<52>()<=36){
if(r.integer<19>()<=80){
if(r.integer<51>()<=48){
if(r.integer<25>()<=232){
if(r.integer<18>()<=7){
return 0x1.cc476bcf5bf35p-1;
}else{
return 0x1.fbe0b68e9ce65p-4;
}
}else{
return -0x1.9c707832f8980p-6;
}
}else{
return -0x1.7738f18e22423p-5;
}
}else{
return 0x1.552daee4da5fcp+0;
}
}else{
if(r.integer<10>()<=59){
return 0x1.a5578760315f0p-3;
}else{
return -0x1.545aed83c8ef4p-3;
}
}
}else{
return -0x1.a6c60fdfc01b2p-3;
}
}else{
return -0x1.a30b65ed4d537p-4;
}
}else{
return 0x1.7fd7d18da6c73p-1;
}
}
}
}else{
if(r.integer<19>()<=51){
return -0x1.c1fc643f19c67p-4;
}else{
return 0x1.862ca76b5591ap-8;
}
}
}
}
}else{
if(r.integer<19>()<=14){
return 0x1.db5238c16e730p-3;
}else{
if(r.integer<19>()<=81){
if(r.integer<51>()<=69){
return -0x1.8396d990f77f2p-4;
}else{
return -0x1.5f7b909a16972p-5;
}
}else{
return 0x1.51fee4f2bf6d0p-3;
}
}
}
}else{
if(r.integer<5>()<=269){
if(r.integer<55>()<=4){
return -0x1.ca5ecd2eb63b4p-4;
}else{
return 0x1.0b1a9e0d88032p-2;
}
}else{
if(r.integer<15>()<=4){
return -0x1.80b86e9352fb0p-3;
}else{
return -0x1.8300d0e057c40p-3;
}
}
}
}
}
}
}else{
if(r.integer<52>()<=26){
if(r.integer<31>()<=5091){
if(r.integer<53>()<=190){
if(r.integer<36>()<=17){
if(r.integer<47>()<=7){
if(r.integer<31>()<=4164){
if(r.integer<7>()<=-23){
if(r.integer<24>()<=47){
return 0x0.0p+0;
}else{
return 0x1.b75a74c09c3cfp-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=331){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=-102){
if(r.integer<30>()<=3){
return 0x1.ec7b890d5a5bap+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<8>()<=-117){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=15){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=18){
return 0x1.4fdf3b645a1cbp-2;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<3>()<=72){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=88){
if(r.integer<0>()<=2486){
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<33>()<=8){
return 0x1.95edbbfb3a67ap+2;
}else{
return 0x1.2a305532617c2p-1;
}
}
}else{
if(r.integer<6>()<=44){
if(r.integer<26>()<=268){
if(r.integer<0>()<=2669){
return -0x1.d29dc725c3dcdp-6;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.930be0ded288dp-3;
}
}else{
if(r.integer<30>()<=5){
if(r.integer<19>()<=94){
return 0x0.0p+0;
}else{
return 0x1.8f9b13165d39ap+0;
}
}else{
if(r.integer<52>()<=4){
return 0x1.5d340da3ac980p+3;
}else{
return 0x1.a277b7a3a64b7p-2;
}
}
}
}
}else{
if(r.integer<7>()<=17){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=382){
if(r.integer<43>()<=4){
return 0x1.374bc6a7ef9dcp-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<53>()<=95){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=53){
if(r.integer<31>()<=8458){
if(r.integer<47>()<=7){
if(r.integer<0>()<=2561){
if(r.integer<10>()<=107){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-7){
if(r.integer<31>()<=5566){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-161){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=11654){
if(r.integer<35>()<=5){
if(r.integer<0>()<=5503){
return 0x0.0p+0;
}else{
return -0x1.c3c9eecbfb15cp+2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.d547c5916f28cp+0;
}
}
}else{
if(r.integer<51>()<=162){
if(r.integer<39>()<=-1){
if(r.integer<51>()<=129){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<47>()<=7){
if(r.integer<52>()<=15){
if(r.integer<35>()<=6){
if(r.integer<9>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-104){
if(r.integer<6>()<=409){
if(r.integer<14>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=15){
if(r.integer<1>()<=96){
if(r.integer<3>()<=93){
return 0x0.0p+0;
}else{
return 0x1.9652bd3c36114p-1;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<4>()<=140){
if(r.integer<31>()<=6698){
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
return 0x1.31e752e7dde51p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<50>()<=3){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=40){
if(r.integer<31>()<=8251){
if(r.integer<6>()<=148){
if(r.integer<55>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=96){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=97){
if(r.integer<31>()<=6666){
if(r.integer<36>()<=13){
if(r.integer<9>()<=35){
if(r.integer<51>()<=-95){
if(r.integer<2>()<=206){
if(r.integer<0>()<=2091){
return 0x1.3802cb9861934p-6;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<9>()<=28){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-90){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=2){
if(r.integer<31>()<=5700){
if(r.integer<50>()<=30){
if(r.integer<5>()<=7){
return 0x1.84e3ffef39086p-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<13>()<=3){
return 0x1.7d7b80d4d1a8dp-4;
}else{
if(r.integer<3>()<=94){
return 0x0.0p+0;
}else{
return -0x1.981514e0ae85fp-3;
}
}
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<25>()<=268){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<30>()<=9){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=67){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=284){
if(r.integer<1>()<=84){
if(r.integer<2>()<=311){
if(r.integer<54>()<=4){
if(r.integer<16>()<=8){
if(r.integer<19>()<=83){
return 0x1.f67fa3a4347d4p-5;
}else{
return 0x1.851eb851eb852p-1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<32>()<=5){
return -0x1.873ffac1d29ddp-3;
}else{
return 0x1.cb66080d1599ap-8;
}
}
}else{
return 0x1.36f22a2ba735fp-2;
}
}else{
if(r.integer<39>()<=-2){
if(r.integer<29>()<=3){
return 0x1.2c4d65e460675p+1;
}else{
return -0x1.13404ea4a8c16p-4;
}
}else{
if(r.integer<52>()<=28){
return -0x1.1c6eba61aa02fp-4;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=48){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=93){
if(r.integer<43>()<=5){
return 0x0.0p+0;
}else{
return -0x1.1a401d2681741p-3;
}
}else{
if(r.integer<3>()<=43){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=3){
return 0x0.0p+0;
}else{
return -0x1.797cc39ffd610p-9;
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=5999){
if(r.integer<26>()<=254){
return 0x1.1b74d08c74eddp-2;
}else{
return 0x1.3e44df2d21a14p-1;
}
}else{
if(r.integer<36>()<=1){
if(r.integer<20>()<=62){
return 0x1.af8d4bd87099fp-2;
}else{
if(r.integer<10>()<=69){
return -0x1.62b1916231864p-3;
}else{
return 0x1.74b58eb69f5cdp-8;
}
}
}else{
if(r.integer<17>()<=3){
if(r.integer<19>()<=29){
return 0x1.06ee30caa326dp-4;
}else{
if(r.integer<26>()<=113){
return 0x1.369695025b230p-6;
}else{
return -0x1.26e978d4fdf3cp-4;
}
}
}else{
if(r.integer<19>()<=24){
return -0x1.a36e2eb1c432cp-7;
}else{
if(r.integer<47>()<=-7){
return 0x1.741dd3a5ca670p+1;
}else{
return 0x1.616575a59e8aap-3;
}
}
}
}
}
}
}
}else{
if(r.integer<36>()<=10){
if(r.integer<1>()<=16){
return -0x1.70a3d70a3d70bp-2;
}else{
if(r.integer<3>()<=18){
return -0x1.6fff6c5c49a9ap-4;
}else{
if(r.integer<31>()<=12273){
if(r.integer<31>()<=10997){
if(r.integer<6>()<=283){
if(r.integer<4>()<=75){
if(r.integer<10>()<=150){
if(r.integer<19>()<=12){
return 0x1.7a7e765297a78p-11;
}else{
return -0x1.626b2f23033a4p-4;
}
}else{
if(r.integer<31>()<=9283){
return 0x0.0p+0;
}else{
return -0x1.332cca85c218bp+0;
}
}
}else{
if(r.integer<53>()<=43){
return -0x1.9624080bd6e7ap-3;
}else{
if(r.integer<26>()<=120){
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=69){
return 0x1.79b92981d9898p-2;
}else{
return 0x1.6d127d05394fep-11;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.694467381d7dcp+1;
}
}else{
return 0x1.d7c9f1744dba0p-2;
}
}
}
}else{
if(r.integer<31>()<=12194){
if(r.integer<1>()<=34){
if(r.integer<47>()<=7){
if(r.integer<31>()<=10055){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=54){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.89374bc6a7ef9p-5;
}
}else{
if(r.integer<44>()<=7){
if(r.integer<9>()<=30){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=3){
return -0x1.999999999999ap-3;
}else{
if(r.integer<17>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<7>()<=38){
if(r.integer<4>()<=195){
if(r.integer<51>()<=75){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-3;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.999999999999ap-3;
}
}
}
}
}else{
if(r.integer<52>()<=37){
if(r.integer<7>()<=-27){
if(r.integer<2>()<=398){
return 0x0.0p+0;
}else{
return -0x1.9931839f76165p-1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-66){
if(r.integer<17>()<=4){
return -0x1.08d2fc2aa22eep-5;
}else{
return 0x1.0e5604189374cp-2;
}
}else{
return 0x1.92503df4c700ap-3;
}
}
}
}
}else{
return -0x1.48d3781e8a02dp-7;
}
}
}
}else{
if(r.integer<52>()<=64){
if(r.integer<44>()<=13){
if(r.integer<31>()<=7915){
if(r.integer<35>()<=6){
if(r.integer<14>()<=9){
if(r.integer<32>()<=8){
if(r.integer<6>()<=19){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<3>()<=110){
if(r.integer<26>()<=125){
if(r.integer<6>()<=323){
if(r.integer<25>()<=80){
return -0x1.40c7c652b52eap-11;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<17>()<=3){
return 0x0.0p+0;
}else{
return 0x1.a6b50b0f27bb4p-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.f3a66f2ed0bccp-2;
}
}
}else{
if(r.integer<31>()<=5934){
if(r.integer<5>()<=280){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<50>()<=-45){
if(r.integer<29>()<=19){
if(r.integer<16>()<=6){
if(r.integer<14>()<=1){
return 0x1.2af69966fe42ep-7;
}else{
if(r.integer<13>()<=4){
return -0x1.0a569b17481afp-7;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.25a774f29cf58p-5;
}
}else{
if(r.integer<19>()<=24){
if(r.integer<16>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=22){
return 0x0.0p+0;
}else{
return -0x1.9c96e8d4033bcp-5;
}
}
}else{
if(r.integer<19>()<=51){
if(r.integer<29>()<=2){
return 0x1.999999999999ap-2;
}else{
if(r.integer<3>()<=104){
return 0x0.0p+0;
}else{
return 0x1.05fa7381b57fdp-3;
}
}
}else{
if(r.integer<4>()<=295){
return -0x1.0c6f7a0b5ed8fp-13;
}else{
if(r.integer<46>()<=-1){
return 0x1.3a92a30553267p-8;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<52>()<=40){
if(r.integer<30>()<=21){
return -0x1.6ecab8f656331p-6;
}else{
return -0x1.2b127d5b1f8b6p-2;
}
}else{
if(r.integer<27>()<=0){
if(r.integer<19>()<=62){
if(r.integer<2>()<=458){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<38>()<=6){
if(r.integer<31>()<=10737){
if(r.integer<10>()<=31){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=2973){
if(r.integer<31>()<=9046){
if(r.integer<26>()<=107){
return 0x0.0p+0;
}else{
if(r.integer<23>()<=34){
if(r.integer<18>()<=0){
if(r.integer<25>()<=176){
return 0x0.0p+0;
}else{
return -0x1.999999999999ap-2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<25>()<=190){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=37){
return -0x1.999999999999ap-2;
}else{
return -0x1.0624dd2f1a9fdp-7;
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.096bb98c7e282p-3;
}
}else{
if(r.integer<1>()<=65){
return 0x0.0p+0;
}else{
return 0x1.2d77318fc5048p-3;
}
}
}
}else{
if(r.integer<25>()<=20){
return 0x1.52ed361984a3ep-11;
}else{
if(r.integer<31>()<=11131){
if(r.integer<4>()<=529){
if(r.integer<25>()<=86){
if(r.integer<31>()<=8282){
return -0x1.89374bc6a7efap-6;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=115){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=286){
if(r.integer<14>()<=3){
if(r.integer<54>()<=2){
return 0x1.99674b91ef6eap-4;
}else{
return -0x1.2d77318fc5049p-4;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<25>()<=163){
if(r.integer<53>()<=67){
return 0x1.ab63edfc777e7p-5;
}else{
return -0x1.cbb13eb2e069ap-6;
}
}else{
if(r.integer<13>()<=0){
return 0x1.6620283b1de87p-4;
}else{
return -0x1.4e99379666abcp-4;
}
}
}
}
}
}else{
return 0x1.b14bb71584e67p-7;
}
}else{
if(r.integer<36>()<=13){
if(r.integer<51>()<=-68){
if(r.integer<1>()<=44){
return -0x1.34b365f379df4p-12;
}else{
return -0x1.d16f1710c80c4p-3;
}
}else{
if(r.integer<51>()<=-49){
return 0x1.41aee5cae4592p-2;
}else{
if(r.integer<20>()<=2){
return -0x1.94face67d77f4p-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=114){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-4;
}
}
}
}
}
}
}
}else{
if(r.integer<0>()<=4609){
if(r.integer<14>()<=2){
if(r.integer<36>()<=6){
if(r.integer<4>()<=241){
if(r.integer<43>()<=0){
if(r.integer<20>()<=53){
return -0x1.41ead9535aba0p-2;
}else{
if(r.integer<8>()<=-75){
return -0x1.5b122d25be5acp-2;
}else{
return 0x1.9c34cbdc036dfp-2;
}
}
}else{
if(r.integer<1>()<=60){
if(r.integer<25>()<=181){
return 0x1.2599ed7c6fbd3p-8;
}else{
if(r.integer<19>()<=21){
return 0x1.ad7f29abcaf52p-16;
}else{
return -0x1.113a3a0d97edfp-4;
}
}
}else{
if(r.integer<2>()<=154){
if(r.integer<13>()<=7){
if(r.integer<31>()<=8670){
return 0x1.b717066b79d7ap-2;
}else{
return -0x1.e3f8ebed2c1cdp-5;
}
}else{
return 0x1.9054a16cf7a52p-3;
}
}else{
if(r.integer<6>()<=284){
return 0x1.999999999999ap-2;
}else{
return -0x1.10b3945d12d75p-3;
}
}
}
}
}else{
if(r.integer<4>()<=249){
return 0x1.999999999999ap-2;
}else{
if(r.integer<19>()<=94){
if(r.integer<16>()<=4){
if(r.integer<20>()<=96){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<32>()<=7){
return 0x1.dd646f774e6cdp-7;
}else{
return 0x1.2457ba52a233ap-3;
}
}
}else{
return 0x1.7082491afc04dp-2;
}
}
}
}else{
if(r.integer<1>()<=3){
return -0x1.8ed02ed862decp-4;
}else{
if(r.integer<31>()<=13030){
if(r.integer<26>()<=121){
if(r.integer<30>()<=12){
if(r.integer<26>()<=79){
if(r.integer<4>()<=54){
return 0x1.095933e7a7de5p-7;
}else{
return -0x1.20287aaeae0f0p-3;
}
}else{
if(r.integer<19>()<=41){
return 0x1.b8cd1c9b19b60p-3;
}else{
return -0x1.e0f124a38101cp-4;
}
}
}else{
return 0x1.df2c19f402b27p-4;
}
}else{
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<47>()<=-1){
return -0x1.0505a35809567p-4;
}else{
if(r.integer<15>()<=6){
return -0x1.1c34bef97a7fdp-4;
}else{
return 0x1.819f049b22e47p-3;
}
}
}
}
}else{
return -0x1.3222f508a027ap-2;
}
}
}
}else{
if(r.integer<17>()<=5){
if(r.integer<16>()<=4){
if(r.integer<24>()<=58){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=3){
return 0x1.4fd96381a56c7p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<4>()<=537){
if(r.integer<15>()<=5){
if(r.integer<18>()<=1){
if(r.integer<7>()<=-55){
return 0x1.03a11762d8477p-5;
}else{
if(r.integer<19>()<=6){
return -0x1.868990bd33acdp-2;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.f75104d551d67p-9;
}
}else{
if(r.integer<20>()<=58){
if(r.integer<43>()<=3){
if(r.integer<53>()<=127){
if(r.integer<2>()<=442){
if(r.integer<3>()<=21){
return 0x1.47ae147ae147cp-3;
}else{
return 0x1.47ae147ae147cp-3;
}
}else{
return -0x1.1b0dae8694187p-4;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.29fd7dba5811bp-10;
}
}
}else{
return 0x1.b969caca4036dp-4;
}
}
}else{
if(r.integer<26>()<=268){
if(r.integer<30>()<=3){
return 0x1.8068702be2060p-5;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.2af59a50cc71bp-6;
}
}
}
}else{
if(r.integer<31>()<=11064){
if(r.integer<36>()<=13){
if(r.integer<26>()<=40){
return 0x1.999999999999ap-3;
}else{
if(r.integer<31>()<=10491){
return 0x0.0p+0;
}else{
return -0x1.7c1bda5119ce0p-4;
}
}
}else{
if(r.integer<31>()<=8528){
return 0x0.0p+0;
}else{
return -0x1.32df505d0fa59p-1;
}
}
}else{
if(r.integer<5>()<=148){
return -0x1.5e59c2814c158p+0;
}else{
if(r.integer<2>()<=474){
return -0x1.c1c0e802ac58ap-7;
}else{
return -0x1.c6791ad0eb2f5p+0;
}
}
}
}
}
}else{
if(r.integer<31>()<=13712){
if(r.integer<20>()<=59){
if(r.integer<44>()<=16){
if(r.integer<43>()<=5){
if(r.integer<8>()<=-189){
if(r.integer<30>()<=21){
if(r.integer<20>()<=21){
return 0x1.cedb3fb844024p-2;
}else{
return 0x1.32eabfad0092dp-5;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=93){
if(r.integer<9>()<=60){
return 0x1.452b6c8e1d628p-6;
}else{
if(r.integer<28>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=49){
if(r.integer<25>()<=18){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=26){
if(r.integer<19>()<=49){
if(r.integer<8>()<=-20){
if(r.integer<30>()<=10){
return -0x1.f212d77318fc5p-4;
}else{
if(r.integer<0>()<=2470){
return 0x0.0p+0;
}else{
return -0x1.918a22fb7a00cp-4;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=65){
if(r.integer<39>()<=-7){
return -0x1.096bb98c7e283p-2;
}else{
if(r.integer<16>()<=1){
if(r.integer<7>()<=71){
if(r.integer<4>()<=213){
return 0x1.a146d0e3a1940p-3;
}else{
return -0x1.b213f5109eefdp-3;
}
}else{
return 0x1.65f244a2e99bfp-1;
}
}else{
if(r.integer<2>()<=356){
if(r.integer<20>()<=13){
return 0x1.5aaf78feef5edp-1;
}else{
return 0x1.96332bd321e34p-6;
}
}else{
if(r.integer<5>()<=378){
return 0x1.af22ea511c464p-1;
}else{
return 0x1.343fa2ad3e921p+0;
}
}
}
}
}else{
if(r.integer<29>()<=9){
if(r.integer<51>()<=-60){
if(r.integer<43>()<=1){
return -0x1.999999999999ap-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=7){
return -0x1.6787a55aaae1dp-4;
}else{
return 0x1.13512a39f15abp-3;
}
}
}else{
if(r.integer<27>()<=0){
return -0x1.ebfdea7c0a3cap-4;
}else{
return 0x1.a7167c3ab0778p-3;
}
}
}
}
}else{
if(r.integer<5>()<=472){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=21){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=20){
return 0x1.7c1bda5119ce0p-5;
}else{
if(r.integer<6>()<=256){
return 0x1.2686d26c9ee4bp-2;
}else{
return 0x1.6b50b0f27bb30p+0;
}
}
}
}
}
}
}else{
if(r.integer<8>()<=30){
if(r.integer<50>()<=73){
if(r.integer<38>()<=0){
return 0x0.0p+0;
}else{
return 0x1.f3046efa899ecp-5;
}
}else{
if(r.integer<15>()<=1){
return -0x1.cb5313e80322dp-4;
}else{
return 0x1.999999999999ap-2;
}
}
}else{
if(r.integer<10>()<=47){
return 0x1.fd396cac52634p-1;
}else{
if(r.integer<31>()<=11654){
return 0x1.d14e3bcd35a87p-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<26>()<=34){
return -0x1.807408da51ee4p-10;
}else{
if(r.integer<26>()<=97){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=37){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<31>()<=10804){
if(r.integer<52>()<=67){
if(r.integer<5>()<=378){
if(r.integer<18>()<=8){
if(r.integer<0>()<=1965){
return 0x1.999999999999ap-2;
}else{
return 0x1.6b3c307f4628ap-6;
}
}else{
return -0x1.17ab5ea1e0447p-3;
}
}else{
return -0x1.85cee17a02fb8p-3;
}
}else{
if(r.integer<6>()<=273){
if(r.integer<51>()<=39){
if(r.integer<20>()<=49){
if(r.integer<1>()<=88){
return 0x1.2208f3ac7b16dp+2;
}else{
return 0x1.b39469197941cp-4;
}
}else{
return 0x1.2bfa03e796267p-9;
}
}else{
return 0x1.443d9c98a7814p-3;
}
}else{
if(r.integer<8>()<=-75){
if(r.integer<30>()<=4){
return -0x1.6bebe1650a45dp-2;
}else{
return 0x1.017706de2115dp-5;
}
}else{
if(r.integer<51>()<=-21){
return 0x1.72e54fd077d24p-1;
}else{
if(r.integer<55>()<=3){
return -0x1.4d132071a42d1p-13;
}else{
return 0x1.46e7926d4cd67p-2;
}
}
}
}
}
}else{
if(r.integer<52>()<=87){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=11886){
if(r.integer<2>()<=182){
return -0x1.dc2de8c67d7d8p-5;
}else{
return 0x1.bbd1a7d2ed4d5p-1;
}
}else{
return 0x1.0b26893297778p-3;
}
}
}
}
}else{
if(r.integer<20>()<=87){
if(r.integer<30>()<=20){
if(r.integer<4>()<=81){
if(r.integer<1>()<=15){
if(r.integer<2>()<=108){
return 0x1.90acf2222d0ccp+0;
}else{
return 0x1.711947cfa26a4p-10;
}
}else{
if(r.integer<0>()<=2409){
return 0x0.0p+0;
}else{
return -0x1.40cea58aaba5bp-9;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=0){
return -0x1.3d10707f5dc80p-4;
}else{
if(r.integer<19>()<=37){
if(r.integer<53>()<=22){
return -0x1.a64b4a558a882p-4;
}else{
if(r.integer<0>()<=2012){
return 0x1.32e00d57929f4p-1;
}else{
if(r.integer<4>()<=159){
return -0x1.0f4553826f41cp-6;
}else{
return 0x1.540a65abf8b93p-8;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=-15){
if(r.integer<8>()<=-70){
if(r.integer<8>()<=-108){
if(r.integer<43>()<=4){
return 0x1.f00900c96d64dp-8;
}else{
if(r.integer<29>()<=14){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=25){
return -0x1.a1373f28d7290p-9;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<17>()<=5){
return -0x1.4f70809b9bd26p-5;
}else{
return 0x1.e07fdd04fe417p-10;
}
}
}else{
if(r.integer<1>()<=85){
if(r.integer<46>()<=-1){
if(r.integer<4>()<=390){
if(r.integer<50>()<=77){
return 0x1.6e9c849f5056ap+1;
}else{
return 0x1.04d8213ebf029p+3;
}
}else{
return -0x1.e3a52b73205e7p-6;
}
}else{
if(r.integer<6>()<=322){
if(r.integer<51>()<=-49){
return 0x1.2c1a3a3de96fap-6;
}else{
if(r.integer<6>()<=269){
if(r.integer<20>()<=94){
return 0x0.0p+0;
}else{
return -0x1.0795f676ea423p-3;
}
}else{
return -0x1.6217e690ffa18p-2;
}
}
}else{
return 0x1.16872b020c49ap-3;
}
}
}else{
if(r.integer<46>()<=1){
return 0x1.8e2218e3e4870p-1;
}else{
return 0x1.ff5f8c38a53b7p+2;
}
}
}
}else{
if(r.integer<52>()<=93){
if(r.integer<19>()<=98){
if(r.integer<53>()<=79){
if(r.integer<19>()<=45){
return -0x1.23236d2ddaf8ap-6;
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=4){
return -0x1.471f45b7e784ep-5;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=2576){
return 0x1.6c0fa9b37099fp-3;
}else{
if(r.integer<1>()<=101){
return 0x0.0p+0;
}else{
return 0x1.d44d1ce6b9e98p-8;
}
}
}
}else{
return 0x1.26ef60a915c00p-6;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<5>()<=48){
if(r.integer<52>()<=86){
if(r.integer<51>()<=-290){
return -0x1.0bf5d78811b1ep+2;
}else{
return -0x1.80b8f803b23c3p-5;
}
}else{
if(r.integer<31>()<=15353){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=21){
return -0x1.9320aea13da7dp+0;
}else{
if(r.integer<31>()<=16763){
if(r.integer<44>()<=10){
if(r.integer<52>()<=101){
return -0x1.bf4af7abb8cd0p+0;
}else{
return -0x1.93c5e777c04d7p-4;
}
}else{
return 0x1.b55b44e0e1e37p-11;
}
}else{
return -0x1.fd5ad16044085p+0;
}
}
}
}
}else{
if(r.integer<13>()<=5){
if(r.integer<31>()<=16763){
return 0x0.0p+0;
}else{
return -0x1.9299e8c793f0ep-5;
}
}else{
if(r.integer<8>()<=0){
if(r.integer<24>()<=17){
return 0x1.e32f0ee144532p-12;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_14(const BudgetResidualFeatures&r){
if(r.integer<0>()<=1653){
if(r.integer<9>()<=29){
if(r.integer<5>()<=284){
if(r.integer<53>()<=59){
if(r.integer<0>()<=1071){
if(r.integer<44>()<=16){
if(r.integer<31>()<=2414){
return 0x0.0p+0;
}else{
if(r.integer<55>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=453){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=1365){
if(r.integer<50>()<=-30){
if(r.integer<29>()<=11){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=37){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<53>()<=97){
if(r.integer<43>()<=4){
if(r.integer<51>()<=-70){
if(r.integer<7>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<44>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=58){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<5>()<=483){
if(r.integer<31>()<=5198){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<8>()<=-56){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=334){
if(r.integer<19>()<=25){
return -0x1.79f2e031d96c0p-2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=9){
if(r.integer<31>()<=3891){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=43){
if(r.integer<52>()<=47){
if(r.integer<52>()<=35){
if(r.integer<31>()<=7782){
if(r.integer<53>()<=34){
if(r.integer<52>()<=29){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=28){
if(r.integer<6>()<=366){
return -0x1.b5ecf4501799fp-11;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<4>()<=309){
if(r.integer<6>()<=446){
if(r.integer<4>()<=297){
if(r.integer<0>()<=1402){
if(r.integer<16>()<=9){
if(r.integer<50>()<=-32){
if(r.integer<31>()<=4850){
return 0x1.324bd838203b3p-1;
}else{
if(r.integer<31>()<=6334){
return 0x0.0p+0;
}else{
return 0x1.dccef8761de98p-8;
}
}
}else{
if(r.integer<2>()<=206){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=32){
return -0x1.3ec460ed80a21p-10;
}else{
if(r.integer<43>()<=0){
return -0x1.3a92a30553262p-6;
}else{
return 0x1.579054ea04730p-2;
}
}
}
}
}else{
if(r.integer<20>()<=61){
return -0x1.bdc28843378fap-6;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<23>()<=22){
return -0x1.44b700ce3e580p-4;
}else{
if(r.integer<18>()<=6){
return -0x1.c07f3696eae8ap-6;
}else{
return 0x1.d1111baf5ee90p-10;
}
}
}
}else{
return -0x1.10a137f38c543p-5;
}
}else{
if(r.integer<52>()<=32){
return -0x1.8bd66277c45ccp-3;
}else{
return -0x1.40186710756ccp-15;
}
}
}else{
if(r.integer<1>()<=102){
if(r.integer<54>()<=6){
if(r.integer<20>()<=91){
if(r.integer<18>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=9){
if(r.integer<6>()<=348){
return 0x0.0p+0;
}else{
return -0x1.1ecad0b123723p-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.0461e4768ca47p-10;
}
}else{
if(r.integer<31>()<=4991){
return 0x0.0p+0;
}else{
return 0x1.dccef8761de98p-8;
}
}
}else{
return 0x1.0b01f41b7a3fdp-1;
}
}
}
}
}else{
if(r.integer<19>()<=47){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<15>()<=8){
if(r.integer<26>()<=64){
if(r.integer<53>()<=63){
if(r.integer<10>()<=47){
return -0x1.750495ba31ac8p-10;
}else{
if(r.integer<13>()<=2){
if(r.integer<5>()<=134){
if(r.integer<2>()<=440){
return -0x1.5589b915a49bcp-4;
}else{
return 0x1.0f756e0a2c7b4p-7;
}
}else{
if(r.integer<1>()<=42){
return 0x0.0p+0;
}else{
return 0x1.c9fe2a2bbc604p-3;
}
}
}else{
if(r.integer<14>()<=6){
if(r.integer<6>()<=431){
if(r.integer<33>()<=2){
return 0x0.0p+0;
}else{
return -0x1.a5719416f8c00p-7;
}
}else{
return 0x1.c0212748ed7b0p-7;
}
}else{
return 0x1.a252b6ed4db1fp-8;
}
}
}
}else{
return -0x1.0187bf7c8231bp-8;
}
}else{
if(r.integer<31>()<=6901){
if(r.integer<25>()<=72){
if(r.integer<30>()<=15){
if(r.integer<13>()<=5){
if(r.integer<2>()<=63){
if(r.integer<13>()<=1){
return 0x0.0p+0;
}else{
return -0x1.d5dded8680b84p-4;
}
}else{
if(r.integer<54>()<=4){
return -0x1.b172a50eb5432p-6;
}else{
return 0x1.8f7fb7e2af334p-3;
}
}
}else{
return -0x1.359a40b37969ap-3;
}
}else{
if(r.integer<20>()<=71){
if(r.integer<14>()<=9){
if(r.integer<19>()<=12){
return 0x1.750495ba31ac8p-12;
}else{
if(r.integer<33>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=53){
return -0x1.0823f71155235p-14;
}else{
return -0x1.21c8d2973c1c4p-5;
}
}
}
}else{
return 0x1.10bafd05688eap-14;
}
}else{
if(r.integer<17>()<=5){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}
}else{
if(r.integer<25>()<=110){
if(r.integer<30>()<=2){
return 0x1.c52594c96540fp-2;
}else{
if(r.integer<53>()<=45){
return 0x1.e1818fb798882p-4;
}else{
if(r.integer<35>()<=4){
if(r.integer<55>()<=1){
return 0x1.240eca6a943ffp-11;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.240eca6a943ffp-13;
}
}
}
}else{
if(r.integer<31>()<=3294){
if(r.integer<24>()<=26){
return 0x0.0p+0;
}else{
return -0x1.21c8d2973c1c4p-5;
}
}else{
if(r.integer<5>()<=0){
return -0x1.0c9432de6bdf2p-5;
}else{
if(r.integer<5>()<=8){
if(r.integer<4>()<=339){
if(r.integer<7>()<=32){
return -0x1.156ef41ee144bp-8;
}else{
return 0x1.10bafd05688eap-14;
}
}else{
return 0x1.734241eee2cc0p-3;
}
}else{
if(r.integer<26>()<=135){
if(r.integer<30>()<=9){
if(r.integer<15>()<=4){
if(r.integer<19>()<=53){
return -0x1.3a5cf3201daccp-5;
}else{
return 0x1.1c5b21bc9c390p-2;
}
}else{
if(r.integer<54>()<=2){
return 0x1.c1a6394b61638p-1;
}else{
return 0x1.f011757349a3cp-2;
}
}
}else{
if(r.integer<19>()<=90){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<4>()<=370){
if(r.integer<29>()<=11){
if(r.integer<54>()<=1){
if(r.integer<19>()<=44){
return 0x1.999999999999ap-1;
}else{
if(r.integer<31>()<=5900){
return -0x1.d245bb28be17ap-10;
}else{
return 0x1.d1fd859eb254dp-3;
}
}
}else{
if(r.integer<3>()<=104){
if(r.integer<3>()<=63){
if(r.integer<16>()<=8){
if(r.integer<19>()<=15){
return 0x1.12be2649736f2p+0;
}else{
if(r.integer<2>()<=286){
return -0x1.71a4ddf060a57p-6;
}else{
return 0x1.9b60991cf1fe7p-9;
}
}
}else{
return 0x1.27dc233d2d180p-3;
}
}else{
return 0x1.32e8b58b929adp-1;
}
}else{
return -0x1.286ce1e15dc43p-4;
}
}
}else{
if(r.integer<26>()<=258){
if(r.integer<54>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<17>()<=1){
return -0x1.791e465e808c0p-6;
}else{
if(r.integer<29>()<=24){
return -0x1.955b3de0ada1cp-4;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<29>()<=18){
if(r.integer<33>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<30>()<=14){
return -0x1.87afdd95b419fp-3;
}else{
return -0x1.c8571c4687a3dp-9;
}
}
}else{
if(r.integer<0>()<=1530){
if(r.integer<3>()<=39){
return 0x0.0p+0;
}else{
return 0x1.2a6a1161c156dp-12;
}
}else{
if(r.integer<5>()<=150){
return -0x1.85acf8d5120d7p-6;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}
}
}
}else{
if(r.integer<4>()<=117){
return 0x1.5a741aff11c7cp-11;
}else{
if(r.integer<19>()<=42){
if(r.integer<36>()<=16){
if(r.integer<31>()<=7615){
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x1.428f6ac34cae5p-2;
}
}else{
if(r.integer<19>()<=25){
if(r.integer<8>()<=42){
return -0x1.a15b530ea51c5p-3;
}else{
return -0x1.240eca6a943ffp-13;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.a7c8b9f6390aap-4;
}
}else{
if(r.integer<18>()<=1){
return -0x1.6c7a045b8cf73p-6;
}else{
if(r.integer<9>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=238){
if(r.integer<29>()<=15){
if(r.integer<30>()<=21){
return -0x1.8a3cdc08bcd9ap-8;
}else{
return -0x1.5a8692e57824fp-5;
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.999999999999ap-3;
}
}
}
}
}
}
}
}else{
if(r.integer<20>()<=6){
return -0x1.750495ba31ac8p-10;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<52>()<=26){
if(r.integer<31>()<=5534){
if(r.integer<53>()<=182){
if(r.integer<44>()<=16){
if(r.integer<31>()<=4370){
if(r.integer<36>()<=10){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<43>()<=4){
if(r.integer<50>()<=22){
if(r.integer<27>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=4596){
return -0x1.794dc9b76e96dp-3;
}else{
return -0x1.782d38476f2a7p-4;
}
}
}else{
if(r.integer<29>()<=5){
if(r.integer<51>()<=93){
return 0x1.33e5753a3ec04p+1;
}else{
return -0x1.a36e2eb1c432fp-10;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<39>()<=-7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=72){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=89){
if(r.integer<3>()<=75){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=2){
if(r.integer<3>()<=88){
if(r.integer<31>()<=3686){
return 0x1.14f62f24636a5p+3;
}else{
if(r.integer<44>()<=10){
return 0x1.8c154c985f070p+0;
}else{
return 0x1.89c8268e58e54p+3;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=6){
if(r.integer<17>()<=2){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
return 0x1.3a9e389231102p+3;
}
}else{
return 0x1.d532d3bb1e3b4p-3;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<3>()<=83){
if(r.integer<50>()<=-9){
return 0x1.d5f789e9c9f7cp-4;
}else{
return 0x1.781d7dbf487fdp+3;
}
}else{
if(r.integer<1>()<=97){
if(r.integer<46>()<=-6){
return -0x1.046129cdbcb74p-1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<53>()<=107){
if(r.integer<31>()<=11730){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=137){
if(r.integer<6>()<=321){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=53){
if(r.integer<31>()<=8458){
if(r.integer<47>()<=7){
if(r.integer<52>()<=14){
if(r.integer<53>()<=176){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-149){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=11494){
if(r.integer<35>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.cd03ff3e0e2d8p-1;
}
}
}else{
if(r.integer<9>()<=3){
if(r.integer<3>()<=35){
if(r.integer<3>()<=21){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=5){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=275){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<2>()<=330){
if(r.integer<3>()<=6){
if(r.integer<25>()<=88){
return 0x1.187e7c06e19bap-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<39>()<=-1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=41){
if(r.integer<55>()<=4){
if(r.integer<52>()<=29){
if(r.integer<14>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<36>()<=3){
if(r.integer<1>()<=96){
if(r.integer<31>()<=6103){
if(r.integer<36>()<=2){
if(r.integer<31>()<=5231){
if(r.integer<44>()<=8){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=378){
if(r.integer<3>()<=53){
return 0x0.0p+0;
}else{
return -0x1.81cd7513526d5p-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<7>()<=-34){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=142){
if(r.integer<0>()<=1802){
return -0x1.4dd87b00d2380p-3;
}else{
if(r.integer<6>()<=58){
return 0x1.11d5eb597fce0p-3;
}else{
if(r.integer<15>()<=3){
return 0x1.072301593dd63p-1;
}else{
return -0x1.b089a02752547p-4;
}
}
}
}else{
if(r.integer<4>()<=502){
if(r.integer<31>()<=7138){
if(r.integer<20>()<=80){
return 0x1.73b8c59506482p-1;
}else{
if(r.integer<6>()<=384){
return 0x1.0ffb75acaa6d8p-2;
}else{
return -0x1.f2801007c15e7p-5;
}
}
}else{
if(r.integer<43>()<=0){
if(r.integer<19>()<=92){
if(r.integer<19>()<=49){
if(r.integer<0>()<=2028){
return -0x1.3e02ff6aad12cp-2;
}else{
return -0x1.2a2ad89219171p-10;
}
}else{
if(r.integer<3>()<=80){
return 0x1.986f6ec107808p-2;
}else{
return -0x1.18c78ab83c313p-6;
}
}
}else{
return -0x1.6492d1a955797p-2;
}
}else{
if(r.integer<26>()<=248){
return 0x1.14b167ec7863ep-2;
}else{
return 0x1.a52196120bf38p-2;
}
}
}
}else{
return 0x1.fba5fe2bea69ap-1;
}
}
}
}else{
if(r.integer<50>()<=-40){
if(r.integer<26>()<=253){
return 0x0.0p+0;
}else{
return -0x1.4b6f1a410808ap-3;
}
}else{
if(r.integer<6>()<=36){
if(r.integer<4>()<=265){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=1){
if(r.integer<8>()<=-108){
if(r.integer<43>()<=4){
if(r.integer<13>()<=8){
return -0x1.77318fc504818p-2;
}else{
return 0x1.47ae147ae147ap-4;
}
}else{
if(r.integer<29>()<=17){
return 0x1.47ae147ae147cp-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<3>()<=103){
if(r.integer<9>()<=31){
if(r.integer<24>()<=17){
return 0x0.0p+0;
}else{
return 0x1.54c985f06f695p-6;
}
}else{
if(r.integer<3>()<=89){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=3){
return 0x1.0c1993cfd619ap-9;
}else{
return -0x1.071d2ab331f12p-2;
}
}
}
}else{
if(r.integer<50>()<=33){
return -0x1.76f884e17bb08p-7;
}else{
if(r.integer<8>()<=189){
return 0x1.268b1c425919bp-1;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<25>()<=253){
return 0x0.0p+0;
}else{
if(r.integer<3>()<=76){
return 0x0.0p+0;
}else{
return -0x1.63e2fe67798bfp-5;
}
}
}
}
}
}
}
}else{
if(r.integer<43>()<=6){
if(r.integer<31>()<=6400){
if(r.integer<17>()<=5){
if(r.integer<36>()<=16){
if(r.integer<4>()<=161){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<31>()<=4742){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<1>()<=15){
if(r.integer<2>()<=176){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=7550){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=271){
return -0x1.0e5604189374cp-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<47>()<=7){
if(r.integer<10>()<=49){
if(r.integer<18>()<=9){
if(r.integer<26>()<=239){
if(r.integer<5>()<=155){
return -0x1.fa0036b197e84p-8;
}else{
return 0x1.070f934ba19bep-9;
}
}else{
return -0x1.53346c00a1c10p-5;
}
}else{
return 0x1.62d13089b5a0fp-5;
}
}else{
if(r.integer<39>()<=0){
if(r.integer<26>()<=120){
if(r.integer<15>()<=8){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=65){
return 0x1.2935587c6de4ap-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<26>()<=187){
if(r.integer<54>()<=6){
return 0x0.0p+0;
}else{
if(r.integer<2>()<=330){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=1){
return 0x0.0p+0;
}else{
return 0x1.d75f66b1a9b34p-11;
}
}
}
}else{
if(r.integer<2>()<=93){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=9955){
if(r.integer<19>()<=35){
if(r.integer<15>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return -0x1.2b020c49ba5e3p+1;
}
}
}
}else{
if(r.integer<25>()<=269){
return 0x0.0p+0;
}else{
return 0x1.b8fde2ef4e012p-2;
}
}
}
}
}else{
if(r.integer<31>()<=4288){
if(r.integer<10>()<=158){
if(r.integer<1>()<=59){
return 0x0.0p+0;
}else{
return -0x1.eb851eb851ebap-4;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<52>()<=68){
if(r.integer<31>()<=7950){
if(r.integer<6>()<=19){
if(r.integer<20>()<=49){
if(r.integer<19>()<=88){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=54){
return -0x1.280beb4e4ac46p-5;
}else{
if(r.integer<0>()<=2956){
return 0x1.3867ac5fe585fp-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<7>()<=-47){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<7>()<=65){
if(r.integer<36>()<=13){
if(r.integer<5>()<=466){
if(r.integer<5>()<=423){
if(r.integer<5>()<=383){
if(r.integer<25>()<=160){
if(r.integer<7>()<=-55){
if(r.integer<35>()<=3){
if(r.integer<19>()<=44){
return 0x1.9c9b26988d588p-3;
}else{
return -0x1.39d495a19af88p-5;
}
}else{
return 0x1.dc5c14867d65ap-4;
}
}else{
if(r.integer<1>()<=25){
return 0x0.0p+0;
}else{
if(r.integer<26>()<=56){
if(r.integer<25>()<=129){
if(r.integer<33>()<=1){
return 0x1.205bc01a36e2fp-6;
}else{
if(r.integer<7>()<=49){
if(r.integer<1>()<=95){
if(r.integer<0>()<=2454){
if(r.integer<20>()<=26){
return -0x1.8d1caafde76e5p-2;
}else{
if(r.integer<35>()<=4){
return -0x1.922256ecf6b8ep-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=29){
return 0x1.ae4e651b6b492p-3;
}else{
return -0x1.3d4106b90a55fp-3;
}
}
}else{
return 0x1.620bd5fa87960p-6;
}
}
}else{
if(r.integer<1>()<=95){
return 0x1.451b22a843fedp-3;
}else{
return -0x1.54f8bb7f02ad7p-2;
}
}
}else{
if(r.integer<4>()<=454){
return 0x0.0p+0;
}else{
if(r.integer<15>()<=4){
if(r.integer<44>()<=3){
return 0x1.999999999999ap-3;
}else{
return -0x1.933beda81fd58p-4;
}
}else{
if(r.integer<25>()<=137){
return 0x1.a824ccbe093aap-3;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<1>()<=117){
return 0x0.0p+0;
}else{
return -0x1.2166e5b9c40bdp-3;
}
}
}else{
if(r.integer<3>()<=95){
if(r.integer<51>()<=-173){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<20>()<=80){
return -0x1.48344c37e6f74p-5;
}else{
return 0x1.c902e8bd99284p-8;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<2>()<=75){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=30){
if(r.integer<29>()<=10){
if(r.integer<0>()<=2545){
return -0x1.23b16009d5ecbp-3;
}else{
return -0x1.66b2669a12e00p-6;
}
}else{
if(r.integer<5>()<=274){
if(r.integer<14>()<=5){
return 0x0.0p+0;
}else{
return -0x1.205bc01a36e30p-6;
}
}else{
if(r.integer<13>()<=2){
return -0x1.670d743f9480ap-7;
}else{
return 0x1.e4395899d2ab4p-8;
}
}
}
}else{
if(r.integer<25>()<=267){
if(r.integer<0>()<=2242){
if(r.integer<10>()<=67){
if(r.integer<24>()<=4){
return 0x1.82cd547b0f3c0p-8;
}else{
if(r.integer<35>()<=1){
if(r.integer<20>()<=57){
return -0x1.df25b061decc7p-6;
}else{
return 0x1.48b472e585127p-3;
}
}else{
if(r.integer<3>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<8>()<=-50){
return -0x1.5ca014071e017p-3;
}else{
if(r.integer<25>()<=145){
return -0x1.84b6f4ce678fbp-7;
}else{
if(r.integer<2>()<=252){
return 0x1.17ee0074aa2c1p-5;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
return 0x1.0c6f7a0b5ed8fp-11;
}
}else{
if(r.integer<17>()<=0){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.136c54a32ba56p-6;
}
}
}
}else{
return 0x1.577bb975314e6p-8;
}
}
}else{
if(r.integer<52>()<=45){
if(r.integer<5>()<=269){
if(r.integer<52>()<=42){
return -0x1.8c7e28240b780p-3;
}else{
if(r.integer<9>()<=42){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=8895){
if(r.integer<3>()<=68){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=174){
return 0x0.0p+0;
}else{
return 0x1.63ad4e8244134p-10;
}
}
}else{
return -0x1.49c8064fb687cp-3;
}
}
}
}else{
if(r.integer<3>()<=79){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=47){
if(r.integer<24>()<=53){
if(r.integer<52>()<=47){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=263){
if(r.integer<43>()<=6){
return 0x1.2ed428e1a0997p-8;
}else{
return -0x1.c78bf56021a55p-6;
}
}else{
return -0x1.f97bedbc4f89dp-6;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<52>()<=54){
if(r.integer<31>()<=10160){
if(r.integer<53>()<=304){
if(r.integer<3>()<=75){
if(r.integer<2>()<=527){
return 0x0.0p+0;
}else{
return -0x1.06181e621c510p-3;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-354){
return -0x1.049acf23bf21fp+2;
}else{
if(r.integer<29>()<=17){
return 0x0.0p+0;
}else{
return -0x1.df736d8af2e2cp-6;
}
}
}
}else{
if(r.integer<9>()<=51){
if(r.integer<31>()<=11654){
return 0x1.89374bc6a7ef9p-6;
}else{
if(r.integer<25>()<=199){
return 0x1.89cb78ed5a3edp-11;
}else{
if(r.integer<31>()<=13821){
return -0x1.cab500617e922p-4;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<25>()<=2){
return 0x1.7836c6b141e65p-6;
}else{
if(r.integer<31>()<=10055){
if(r.integer<6>()<=335){
if(r.integer<53>()<=34){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=188){
if(r.integer<26>()<=107){
if(r.integer<0>()<=2044){
if(r.integer<1>()<=13){
return 0x0.0p+0;
}else{
return -0x1.fccaa375382cdp-5;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=472){
return 0x0.0p+0;
}else{
return -0x1.0c6f7a0b5ee15p-14;
}
}
}else{
if(r.integer<5>()<=141){
if(r.integer<29>()<=22){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<36>()<=13){
if(r.integer<31>()<=8856){
if(r.integer<19>()<=21){
if(r.integer<29>()<=22){
if(r.integer<25>()<=110){
return 0x0.0p+0;
}else{
return 0x1.db83b8a089bc7p-2;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<54>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<31>()<=13115){
if(r.integer<20>()<=54){
if(r.integer<12>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<46>()<=0){
if(r.integer<43>()<=5){
if(r.integer<51>()<=-203){
if(r.integer<20>()<=49){
if(r.integer<50>()<=70){
return 0x0.0p+0;
}else{
return 0x1.5ef6b94fdeac8p-2;
}
}else{
if(r.integer<50>()<=69){
return 0x0.0p+0;
}else{
return -0x1.4fa092c823550p-7;
}
}
}else{
if(r.integer<19>()<=94){
if(r.integer<16>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=43){
if(r.integer<31>()<=10491){
if(r.integer<9>()<=73){
if(r.integer<6>()<=348){
return 0x0.0p+0;
}else{
if(r.integer<42>()<=128){
return 0x1.2f679760a757bp-4;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=37){
if(r.integer<16>()<=6){
if(r.integer<44>()<=5){
if(r.integer<4>()<=251){
return 0x1.30be75016ffddp-1;
}else{
if(r.integer<23>()<=19){
return -0x1.5a2201d4e3bf4p-4;
}else{
return 0x1.67397b9def628p-2;
}
}
}else{
return -0x1.b88348004032fp-3;
}
}else{
if(r.integer<51>()<=174){
return 0x1.196799f1d2ce3p-1;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=149){
return 0x0.0p+0;
}else{
return -0x1.0ac1fae1b30ecp-9;
}
}
}
}else{
if(r.integer<5>()<=143){
return 0x1.fb3fa6defc7a4p-3;
}else{
if(r.integer<29>()<=4){
return 0x1.bda5119ce0760p-6;
}else{
return -0x1.0c6f7a0b5ed93p-14;
}
}
}
}
}else{
if(r.integer<35>()<=6){
if(r.integer<47>()<=0){
return -0x1.7e5c05cd3a008p-11;
}else{
if(r.integer<0>()<=3216){
if(r.integer<52>()<=69){
return -0x1.3d75e875b0ed5p-4;
}else{
if(r.integer<4>()<=111){
return 0x1.5cfdceceb7e50p-1;
}else{
return 0x1.4d433af961664p-8;
}
}
}else{
if(r.integer<53>()<=176){
return -0x1.00acb464b2427p-7;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<52>()<=79){
return 0x0.0p+0;
}else{
return -0x1.f45c3ee26c5b0p-5;
}
}
}
}else{
if(r.integer<30>()<=9){
if(r.integer<1>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=75){
return 0x1.27b176d240033p-2;
}else{
return 0x1.c0d5bb5f24ba4p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<9>()<=89){
if(r.integer<3>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=87){
if(r.integer<1>()<=85){
if(r.integer<46>()<=0){
if(r.integer<0>()<=2301){
if(r.integer<10>()<=25){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=41){
if(r.integer<13>()<=5){
return 0x1.a9abe9051a4ecp-8;
}else{
if(r.integer<10>()<=47){
if(r.integer<18>()<=9){
return 0x0.0p+0;
}else{
return 0x1.89cb78ed5a3edp-11;
}
}else{
return 0x1.5aca50f18a1b8p-3;
}
}
}else{
return -0x1.2e4900b461c53p-10;
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<23>()<=47){
return 0x0.0p+0;
}else{
return 0x1.458e03d834869p-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=302){
return 0x0.0p+0;
}else{
return 0x1.45e2d1b39ece4p-9;
}
}
}else{
if(r.integer<2>()<=542){
if(r.integer<6>()<=61){
if(r.integer<14>()<=10){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=177){
return 0x1.b36bd2b6f1994p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=2){
return -0x1.aa3a051c6509ap-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.10a1b8cce5a16p+0;
}
}
}else{
if(r.integer<53>()<=53){
if(r.integer<53>()<=32){
return 0x0.0p+0;
}else{
return 0x1.da24121cd1e1ap-7;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<14>()<=7){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<19>()<=27){
if(r.integer<50>()<=105){
return 0x0.0p+0;
}else{
if(r.integer<4>()<=102){
return 0x1.6fe08d9ee4873p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=47){
if(r.integer<51>()<=-33){
if(r.integer<33>()<=8){
if(r.integer<6>()<=362){
return 0x1.ad7f29abcaf48p-12;
}else{
return 0x1.57689ca18bd68p-4;
}
}else{
return -0x1.009de31406d43p-4;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<14>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<54>()<=7){
if(r.integer<36>()<=0){
if(r.integer<19>()<=20){
return 0x1.3ff62e27d8218p-9;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=6080){
if(r.integer<20>()<=57){
if(r.integer<29>()<=28){
if(r.integer<19>()<=40){
if(r.integer<5>()<=97){
if(r.integer<30>()<=7){
return -0x1.cf31ce50a7daap-1;
}else{
if(r.integer<26>()<=250){
if(r.integer<0>()<=1737){
return 0x1.b1a5fa6ba1374p-9;
}else{
return 0x1.1279702d1b89fp-7;
}
}else{
return 0x1.17afe48e35fd1p-1;
}
}
}else{
return -0x1.315867a02249ep-10;
}
}else{
if(r.integer<19>()<=96){
if(r.integer<35>()<=4){
if(r.integer<53>()<=41){
if(r.integer<4>()<=137){
return -0x1.4c305a3adef8ep-9;
}else{
if(r.integer<13>()<=7){
return -0x1.e0796bc087330p-4;
}else{
return -0x1.2ad0cdb332b96p-5;
}
}
}else{
if(r.integer<53>()<=154){
if(r.integer<20>()<=48){
return -0x1.fe7261466bf4dp-6;
}else{
return 0x1.43768ea162394p-3;
}
}else{
return -0x1.93a920bd683fap-4;
}
}
}else{
if(r.integer<3>()<=20){
if(r.integer<3>()<=6){
if(r.integer<55>()<=6){
if(r.integer<0>()<=2907){
return -0x1.4f55b66771028p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<6>()<=264){
return -0x1.0dc86a927004bp-2;
}else{
return 0x1.475a31a4bdba1p-2;
}
}
}else{
if(r.integer<50>()<=-60){
return 0x1.3e8a356ac9617p-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<24>()<=57){
if(r.integer<19>()<=46){
return -0x1.93d93b4525792p-2;
}else{
if(r.integer<18>()<=9){
if(r.integer<7>()<=49){
return 0x1.21c8046ead3a7p-3;
}else{
return -0x1.1095684b5cb9ap-3;
}
}else{
if(r.integer<31>()<=10160){
return -0x1.67a95c853c148p-2;
}else{
if(r.integer<26>()<=130){
return 0x1.803417df9aafcp-2;
}else{
return -0x1.6ac13efa10d2dp-3;
}
}
}
}
}else{
return 0x1.6e8a03167d4ecp-1;
}
}else{
return -0x1.60f0b0acb0a2ap-4;
}
}
}
}else{
if(r.integer<31>()<=8282){
return 0x1.7423930016060p-1;
}else{
if(r.integer<53>()<=59){
if(r.integer<0>()<=2152){
return -0x1.e252200077034p-6;
}else{
return 0x1.696037af19ebcp+0;
}
}else{
return -0x1.19f8fa7d34333p-4;
}
}
}
}
}else{
if(r.integer<31>()<=10320){
if(r.integer<53>()<=34){
return 0x1.a5719416f8bfdp-9;
}else{
if(r.integer<13>()<=0){
if(r.integer<55>()<=4){
return 0x1.d7ed0037cd100p-1;
}else{
return 0x1.529070a60562cp-9;
}
}else{
return 0x1.5ca16ba00c255p-9;
}
}
}else{
if(r.integer<0>()<=2075){
if(r.integer<31>()<=12771){
if(r.integer<54>()<=3){
return -0x1.05b5d6cef4bdfp-4;
}else{
return -0x1.2eef4dcb7aeb3p-8;
}
}else{
return 0x1.b287a728ce558p-9;
}
}else{
if(r.integer<26>()<=14){
return 0x1.7cf413daf5a6ep-2;
}else{
if(r.integer<38>()<=-1){
if(r.integer<13>()<=2){
return -0x1.ed60822a1e01dp-6;
}else{
return 0x1.b089a02752547p-4;
}
}else{
return -0x1.4f38e1eea9080p-8;
}
}
}
}
}
}else{
if(r.integer<35>()<=5){
if(r.integer<7>()<=69){
if(r.integer<10>()<=212){
return 0x1.5de29d80b4b60p-15;
}else{
if(r.integer<31>()<=8216){
return 0x1.9b2c40d0aaa7fp-3;
}else{
if(r.integer<0>()<=3731){
return -0x1.29a6964ac69dfp-1;
}else{
return -0x1.89374bc6a7ef4p-5;
}
}
}
}else{
if(r.integer<53>()<=111){
if(r.integer<31>()<=15353){
return -0x1.184a6872c9e5ep-4;
}else{
return 0x1.78f697c2e5b58p-6;
}
}else{
if(r.integer<43>()<=1){
if(r.integer<35>()<=2){
return -0x1.02de00d1b7176p-1;
}else{
return 0x1.90d829f8210e7p-3;
}
}else{
if(r.integer<43>()<=5){
return -0x1.08c3f3e0370cfp-5;
}else{
return 0x1.56c59e2a2e192p-5;
}
}
}
}
}else{
if(r.integer<23>()<=55){
if(r.integer<0>()<=3163){
return -0x1.674a1331fdcacp-6;
}else{
return 0x0.0p+0;
}
}else{
return -0x1.6872b020c49bbp-3;
}
}
}
}else{
if(r.integer<43>()<=5){
if(r.integer<35>()<=4){
return -0x1.729472126c135p+1;
}else{
return -0x1.46341f74edf17p-5;
}
}else{
return 0x1.28bad4eab7f62p-3;
}
}
}
}else{
if(r.integer<8>()<=-34){
if(r.integer<36>()<=9){
if(r.integer<35>()<=3){
if(r.integer<15>()<=0){
return 0x1.119ce075f6fd3p-2;
}else{
if(r.integer<3>()<=110){
if(r.integer<6>()<=265){
if(r.integer<26>()<=83){
return -0x1.db22d0e560418p-3;
}else{
if(r.integer<26>()<=104){
return 0x1.c8754f3775b82p-2;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.8327bd3351bc0p-5;
}
}else{
if(r.integer<1>()<=61){
return -0x1.14ad6121adfabp-4;
}else{
return -0x1.252121b8b76c3p-2;
}
}
}
}else{
if(r.integer<52>()<=71){
if(r.integer<43>()<=5){
if(r.integer<7>()<=67){
if(r.integer<25>()<=53){
return -0x1.80abff7d443d8p-5;
}else{
return 0x1.9b84d63e0fb02p-3;
}
}else{
return -0x1.b12e3aefcdd57p-4;
}
}else{
return -0x1.2599ed7c6fbd3p-5;
}
}else{
if(r.integer<47>()<=7){
return 0x1.53dea465a5764p-2;
}else{
return 0x1.c09ce7a69db10p-1;
}
}
}
}else{
if(r.integer<43>()<=3){
if(r.integer<2>()<=284){
if(r.integer<55>()<=8){
return 0x1.919614ffc16b7p-2;
}else{
return -0x1.1f9d603fdf27cp-2;
}
}else{
return -0x1.9a6942fcb9557p-3;
}
}else{
if(r.integer<31>()<=7615){
return -0x1.97911a88dc20fp-3;
}else{
if(r.integer<51>()<=-119){
return 0x1.d0fa58f7121acp-2;
}else{
return 0x1.529070a60562cp-9;
}
}
}
}
}else{
if(r.integer<1>()<=82){
if(r.integer<24>()<=57){
if(r.integer<5>()<=493){
return -0x1.e32f0ee144520p-14;
}else{
return 0x1.2dfd694ccab40p-8;
}
}else{
return 0x1.92a737110e453p-11;
}
}else{
if(r.integer<17>()<=8){
if(r.integer<20>()<=31){
if(r.integer<2>()<=162){
return -0x1.7c01025e7f117p-4;
}else{
return 0x1.86c9d07186acfp-10;
}
}else{
if(r.integer<19>()<=3){
return -0x1.1cf1f021c2979p-2;
}else{
return 0x1.1714083d98bf0p-5;
}
}
}else{
if(r.integer<4>()<=297){
return 0x1.54478a981bd88p-1;
}else{
return 0x1.1d9a16578a764p-8;
}
}
}
}
}
}
}
}
}
}
__attribute__((noinline)) static double budget_tree_15(const BudgetResidualFeatures&r){
if(r.integer<0>()<=1653){
if(r.integer<52>()<=29){
if(r.integer<5>()<=284){
if(r.integer<53>()<=59){
if(r.integer<0>()<=1346){
if(r.integer<44>()<=13){
if(r.integer<33>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-51){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<0>()<=532){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=9){
if(r.integer<14>()<=6){
if(r.integer<19>()<=72){
if(r.integer<0>()<=591){
if(r.integer<5>()<=37){
return 0x0.0p+0;
}else{
return 0x1.100b473c084f1p+1;
}
}else{
if(r.integer<1>()<=37){
return 0x0.0p+0;
}else{
if(r.integer<6>()<=283){
if(r.integer<3>()<=43){
if(r.integer<26>()<=151){
return 0x0.0p+0;
}else{
return 0x1.0574cea12bf04p+1;
}
}else{
if(r.integer<38>()<=-2){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<30>()<=5){
if(r.integer<5>()<=133){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<0>()<=1548){
if(r.integer<7>()<=-36){
return 0x1.0e5110158f200p-13;
}else{
if(r.integer<5>()<=145){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<53>()<=97){
if(r.integer<6>()<=137){
return 0x0.0p+0;
}else{
if(r.integer<51>()<=-73){
if(r.integer<7>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=139){
if(r.integer<6>()<=421){
if(r.integer<8>()<=-87){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=41){
if(r.integer<38>()<=1){
if(r.integer<31>()<=7817){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<29>()<=7){
if(r.integer<20>()<=78){
if(r.integer<47>()<=-7){
if(r.integer<16>()<=3){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1384){
return 0x1.da69bf598952ap+2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=94){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}else{
if(r.integer<10>()<=63){
return 0x1.8e368f08461fap+1;
}else{
if(r.integer<9>()<=16){
return 0x1.9999999999997p-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<8>()<=-36){
if(r.integer<10>()<=71){
if(r.integer<31>()<=5198){
if(r.integer<47>()<=7){
return 0x0.0p+0;
}else{
if(r.integer<14>()<=7){
if(r.integer<30>()<=11){
return 0x1.353f7ced91688p+1;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<44>()<=13){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=9){
if(r.integer<31>()<=3891){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<53>()<=36){
if(r.integer<52>()<=38){
if(r.integer<35>()<=2){
if(r.integer<55>()<=0){
if(r.integer<19>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=35){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<7>()<=31){
if(r.integer<20>()<=9){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=5799){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=35){
if(r.integer<1>()<=88){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=49){
return 0x0.0p+0;
}else{
return 0x1.699312bb03c79p+0;
}
}
}else{
if(r.integer<51>()<=-33){
if(r.integer<1>()<=76){
return 0x0.0p+0;
}else{
return -0x1.7e7a84558fa99p-3;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=51){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=39){
if(r.integer<28>()<=0){
if(r.integer<10>()<=77){
if(r.integer<9>()<=29){
if(r.integer<32>()<=5){
if(r.integer<25>()<=140){
return 0x1.54a7f8012dfd7p-3;
}else{
return 0x1.3333333333334p-1;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<17>()<=2){
if(r.integer<20>()<=85){
if(r.integer<19>()<=27){
if(r.integer<20>()<=71){
if(r.integer<51>()<=-60){
return 0x0.0p+0;
}else{
if(r.integer<18>()<=8){
if(r.integer<25>()<=203){
return -0x1.8eb276398c208p-4;
}else{
return -0x1.c8571c4687a3dp-9;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.0461e4768ca47p-10;
}
}else{
if(r.integer<24>()<=56){
if(r.integer<55>()<=10){
if(r.integer<43>()<=5){
if(r.integer<29>()<=4){
return -0x1.cd5e39eb8ced4p-5;
}else{
if(r.integer<31>()<=5866){
if(r.integer<52>()<=35){
if(r.integer<33>()<=4){
return 0x0.0p+0;
}else{
return 0x1.09a4cb4f3eef5p-12;
}
}else{
return -0x1.d9ec3c761f642p-9;
}
}else{
return 0x1.27b717f380846p-8;
}
}
}else{
if(r.integer<3>()<=49){
return 0x1.7f4280582a0dap-3;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.2469a1165626ep-5;
}
}else{
if(r.integer<4>()<=410){
return 0x0.0p+0;
}else{
return -0x1.4d31c835499f2p-3;
}
}
}
}else{
if(r.integer<6>()<=143){
return -0x1.5bad24e6bf3c5p-3;
}else{
if(r.integer<1>()<=46){
return -0x1.0a569b17481b3p-7;
}else{
return 0x1.b5ff5bb85e0fdp-4;
}
}
}
}else{
if(r.integer<20>()<=60){
if(r.integer<3>()<=7){
if(r.integer<31>()<=6068){
return 0x1.067b9f51a230bp-7;
}else{
return -0x1.b1caaca5d4aaap-15;
}
}else{
if(r.integer<2>()<=66){
if(r.integer<31>()<=6698){
return -0x1.815645a0b7dfdp-4;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<53>()<=71){
if(r.integer<8>()<=63){
if(r.integer<20>()<=50){
if(r.integer<25>()<=69){
if(r.integer<25>()<=65){
if(r.integer<31>()<=6633){
return 0x1.bd41bf680a54dp-4;
}else{
return -0x1.f8f1f96c0f0a5p-6;
}
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<44>()<=7){
if(r.integer<19>()<=89){
if(r.integer<25>()<=97){
if(r.integer<6>()<=397){
return -0x1.77f92fb217655p-9;
}else{
return -0x1.0821e74d57ffdp-4;
}
}else{
if(r.integer<7>()<=-34){
return -0x1.cbbb8d86d21cdp-7;
}else{
if(r.integer<6>()<=399){
if(r.integer<29>()<=6){
return -0x1.d8b42c2543c7dp-5;
}else{
if(r.integer<55>()<=3){
if(r.integer<6>()<=55){
return 0x1.7668a33dc36b4p-6;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<20>()<=21){
return 0x0.0p+0;
}else{
return 0x1.999999999999ap-3;
}
}
}
}
}else{
if(r.integer<1>()<=71){
return 0x0.0p+0;
}else{
return 0x1.6d21409774d14p-1;
}
}
}else{
if(r.integer<30>()<=27){
if(r.integer<31>()<=7173){
if(r.integer<31>()<=6068){
return 0x1.77914010476c9p-2;
}else{
return 0x1.999999999999ap-1;
}
}else{
return 0x1.4ca0058843f5cp-8;
}
}else{
if(r.integer<19>()<=68){
return 0x1.8362cb7c3fc1cp-8;
}else{
return -0x1.6773aca0069b3p-6;
}
}
}
}
}else{
if(r.integer<10>()<=57){
if(r.integer<43>()<=3){
return -0x1.2a6a1161c156dp-14;
}else{
return -0x1.9b9003b8b02c0p-4;
}
}else{
if(r.integer<18>()<=6){
return -0x1.a382cc59a7965p-11;
}else{
return 0x1.8599bb052cc34p-3;
}
}
}
}else{
return -0x1.240eca6a943ffp-13;
}
}else{
return 0x1.38531c7672112p-10;
}
}
}
}else{
if(r.integer<24>()<=53){
if(r.integer<7>()<=33){
if(r.integer<18>()<=0){
return -0x1.4981285e98e7ap-9;
}else{
if(r.integer<5>()<=383){
return 0x1.1cf604ff6e34dp-7;
}else{
if(r.integer<19>()<=41){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=-54){
return 0x0.0p+0;
}else{
return 0x1.bfeb92e097da7p-4;
}
}
}else{
return 0x1.91dc472467fa8p-2;
}
}
}
}
}else{
if(r.integer<19>()<=24){
return 0x1.4a70b0220c660p-3;
}else{
if(r.integer<19>()<=73){
return -0x1.21407518b967fp-5;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<23>()<=52){
if(r.integer<7>()<=-40){
if(r.integer<29>()<=10){
return 0x1.27b717f380846p-8;
}else{
return 0x1.999999999999ap-2;
}
}else{
if(r.integer<55>()<=10){
if(r.integer<44>()<=13){
if(r.integer<4>()<=370){
if(r.integer<5>()<=19){
if(r.integer<30>()<=18){
return 0x0.0p+0;
}else{
return 0x1.adb9eafd79650p-8;
}
}else{
if(r.integer<5>()<=488){
return 0x0.0p+0;
}else{
return -0x1.1553cf3506f2cp-6;
}
}
}else{
if(r.integer<5>()<=27){
if(r.integer<24>()<=45){
return -0x1.ca77ece2bc505p-5;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<13>()<=8){
if(r.integer<4>()<=348){
if(r.integer<15>()<=4){
if(r.integer<29>()<=3){
return 0x1.df91f5f88ee6cp-4;
}else{
if(r.integer<24>()<=41){
return -0x1.3ac965cb4721fp-5;
}else{
return -0x1.77227e1aa367dp-3;
}
}
}else{
return -0x1.861a945e79e68p-9;
}
}else{
if(r.integer<4>()<=408){
return 0x1.93c7783d61544p-3;
}else{
if(r.integer<18>()<=6){
return -0x1.0791efac1fd91p-5;
}else{
return 0x1.f5834f5552c27p-6;
}
}
}
}else{
return 0x1.c9d2ad9d98bdfp-3;
}
}
}else{
if(r.integer<0>()<=1384){
return 0x0.0p+0;
}else{
if(r.integer<17>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=32){
return -0x1.5127a9abfa334p-7;
}else{
return -0x1.db695f1f8e507p-5;
}
}
}
}
}
}else{
if(r.integer<6>()<=457){
if(r.integer<14>()<=10){
if(r.integer<50>()<=-34){
return 0x1.300e8d21ec2d4p-8;
}else{
if(r.integer<3>()<=25){
return -0x1.c07f3696eae8ap-6;
}else{
if(r.integer<25>()<=236){
if(r.integer<20>()<=66){
if(r.integer<25>()<=79){
return -0x1.d4ac204c29380p-5;
}else{
if(r.integer<55>()<=3){
return -0x1.240eca6a943ffp-13;
}else{
if(r.integer<1>()<=62){
return 0x1.c298cdfc60862p-1;
}else{
return -0x1.4afb1d648c3e4p-9;
}
}
}
}else{
if(r.integer<50>()<=32){
return 0x1.4a57e7f36ecd4p-8;
}else{
return -0x1.b8cdf8821884dp-5;
}
}
}else{
if(r.integer<31>()<=5900){
return 0x1.2ad2933fa0447p-1;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x1.9aa84a5201d72p-2;
}
}else{
return -0x1.d09a61c08f51dp-5;
}
}
}
}else{
if(r.integer<53>()<=49){
if(r.integer<35>()<=2){
if(r.integer<26>()<=42){
if(r.integer<31>()<=6732){
return 0x1.3e005df740b99p-3;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=7){
if(r.integer<5>()<=280){
return 0x1.e8ba0208b29adp-3;
}else{
if(r.integer<24>()<=3){
return -0x1.04bbc7196332ap-9;
}else{
return 0x1.985622a16a9e6p-3;
}
}
}else{
if(r.integer<4>()<=442){
if(r.integer<25>()<=167){
if(r.integer<3>()<=21){
return -0x1.c07f3696eae8ap-6;
}else{
if(r.integer<2>()<=108){
if(r.integer<8>()<=39){
return -0x1.ed76e81e1eea7p-4;
}else{
return 0x1.efa923aff2734p-11;
}
}else{
if(r.integer<0>()<=1476){
return -0x1.c28f7e850d930p-5;
}else{
if(r.integer<26>()<=177){
if(r.integer<5>()<=383){
return 0x1.d0802ebb33b00p-6;
}else{
return 0x1.40e7d36db8b07p-2;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<4>()<=380){
if(r.integer<55>()<=2){
if(r.integer<33>()<=1){
return 0x0.0p+0;
}else{
return -0x1.1dfc9a63d1b33p-3;
}
}else{
if(r.integer<5>()<=48){
return -0x1.5845e8acd916ep-2;
}else{
return 0x0.0p+0;
}
}
}else{
return -0x1.40d7580d7f91dp-4;
}
}
}else{
if(r.integer<1>()<=59){
return 0x0.0p+0;
}else{
return -0x1.6b4e8ce8ccabcp-3;
}
}
}
}
}else{
if(r.integer<19>()<=29){
if(r.integer<51>()<=42){
if(r.integer<17>()<=5){
if(r.integer<1>()<=54){
return -0x1.0f2f8cfc4d7c3p-4;
}else{
return -0x1.466f5019f3c71p-2;
}
}else{
return -0x1.f3390bff00800p-9;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=38){
if(r.integer<5>()<=97){
return 0x1.3978c791fa68dp-2;
}else{
return -0x1.5306fb2b60d55p-6;
}
}else{
if(r.integer<14>()<=5){
return -0x1.23dbc9b73b0c9p-4;
}else{
if(r.integer<5>()<=262){
if(r.integer<20>()<=21){
return 0x1.c7a338549af9ap-6;
}else{
if(r.integer<16>()<=3){
return 0x1.c94e3e2cb094dp-6;
}else{
return -0x1.ede7bc49c24afp-4;
}
}
}else{
return 0x1.068881da904dep-5;
}
}
}
}
}
}else{
if(r.integer<44>()<=8){
return 0x0.0p+0;
}else{
return 0x1.16fb668a9af08p-3;
}
}
}
}
}
}else{
if(r.integer<52>()<=26){
if(r.integer<31>()<=5091){
if(r.integer<36>()<=17){
if(r.integer<47>()<=7){
if(r.integer<53>()<=190){
if(r.integer<31>()<=4164){
return 0x0.0p+0;
}else{
if(r.integer<9>()<=23){
if(r.integer<6>()<=285){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<8>()<=-102){
if(r.integer<29>()<=8){
if(r.integer<20>()<=55){
return 0x1.d3e438794337dp+2;
}else{
return 0x1.c007a163e80e0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<29>()<=6){
if(r.integer<25>()<=198){
return -0x1.04dfdddea01d7p+0;
}else{
return 0x1.3ab475be99df0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<51>()<=129){
if(r.integer<31>()<=3443){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<43>()<=4){
if(r.integer<53>()<=95){
return 0x0.0p+0;
}else{
if(r.integer<53>()<=162){
if(r.integer<8>()<=-108){
if(r.integer<55>()<=0){
return 0x0.0p+0;
}else{
if(r.integer<52>()<=15){
if(r.integer<44>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<6>()<=321){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=2){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=5){
if(r.integer<53>()<=107){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<9>()<=2){
if(r.integer<6>()<=280){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<5>()<=261){
if(r.integer<31>()<=7915){
if(r.integer<47>()<=7){
if(r.integer<52>()<=16){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<51>()<=-318){
if(r.integer<0>()<=5419){
return 0x0.0p+0;
}else{
return -0x1.8e757928e0ca0p-8;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=12352){
if(r.integer<35>()<=5){
if(r.integer<8>()<=-430){
return -0x1.8cee5abc0e38bp+2;
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.0941c8216c617p-1;
}
}
}else{
if(r.integer<2>()<=364){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=280){
return 0x0.0p+0;
}else{
if(r.integer<35>()<=6){
return 0x0.0p+0;
}else{
return -0x1.47ae147ae147cp-5;
}
}
}
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<9>()<=41){
if(r.integer<6>()<=157){
if(r.integer<35>()<=5){
if(r.integer<10>()<=31){
return 0x1.070f934ba19bep-9;
}else{
if(r.integer<19>()<=0){
if(r.integer<3>()<=90){
return 0x0.0p+0;
}else{
return -0x1.e45fbb7c6d63fp-3;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<51>()<=-68){
if(r.integer<52>()<=33){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=1){
return -0x1.7cc4f7964f0c5p-3;
}else{
if(r.integer<0>()<=1786){
return -0x1.fa0af37909007p-5;
}else{
if(r.integer<10>()<=85){
if(r.integer<5>()<=134){
return 0x0.0p+0;
}else{
return 0x1.66f17badcb54dp-3;
}
}else{
return 0x0.0p+0;
}
}
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=7378){
if(r.integer<30>()<=11){
if(r.integer<4>()<=539){
return 0x1.d924f31f34105p-11;
}else{
return 0x1.578012b69b450p-1;
}
}else{
if(r.integer<4>()<=102){
if(r.integer<1>()<=12){
if(r.integer<36>()<=13){
return 0x1.0a4a687a59063p-8;
}else{
return -0x1.c8571c4687a3dp-9;
}
}else{
if(r.integer<50>()<=-40){
return 0x1.9a415f45e0b4fp-2;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<5>()<=8){
if(r.integer<43>()<=1){
if(r.integer<29>()<=8){
if(r.integer<2>()<=162){
return 0x1.29aa1d755bccbp-1;
}else{
return 0x1.2dfd694ccab40p-11;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x1.ad7f29abcaf52p-16;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<6>()<=278){
if(r.integer<20>()<=66){
if(r.integer<2>()<=422){
return 0x0.0p+0;
}else{
if(r.integer<31>()<=9368){
if(r.integer<39>()<=-1){
return -0x1.0158b4187fa8bp-4;
}else{
if(r.integer<8>()<=57){
if(r.integer<52>()<=36){
return 0x0.0p+0;
}else{
return 0x1.07c84b5dcc647p-2;
}
}else{
return -0x1.f2b1c1613c63ap-6;
}
}
}else{
if(r.integer<6>()<=275){
return -0x1.7d426153a0f4dp-3;
}else{
return 0x1.9428e735f6e03p-7;
}
}
}
}else{
if(r.integer<6>()<=258){
if(r.integer<9>()<=37){
if(r.integer<25>()<=224){
if(r.integer<1>()<=107){
return 0x0.0p+0;
}else{
return 0x1.8ec95bff04578p+0;
}
}else{
return -0x1.14095d8801a7ep-3;
}
}else{
return 0x1.999999999999ap-3;
}
}else{
if(r.integer<24>()<=23){
if(r.integer<25>()<=189){
if(r.integer<35>()<=6){
if(r.integer<5>()<=271){
return -0x1.ef606cf49763ap-4;
}else{
if(r.integer<50>()<=40){
return 0x1.3b673cd8ac06cp-6;
}else{
return -0x1.6bfb6ea106520p-3;
}
}
}else{
return 0x1.f212d77318fc7p-5;
}
}else{
return 0x1.9094c9616e962p-3;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<10>()<=61){
if(r.integer<52>()<=33){
return -0x1.0c6f7a0b5ed8fp-13;
}else{
if(r.integer<23>()<=50){
return 0x1.4c976e824fe23p-9;
}else{
if(r.integer<9>()<=37){
return 0x0.0p+0;
}else{
if(r.integer<20>()<=51){
return -0x1.a1bb95dc8f7c5p-3;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<55>()<=3){
if(r.integer<14>()<=1){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<35>()<=4){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}else{
if(r.integer<44>()<=13){
if(r.integer<27>()<=0){
if(r.integer<8>()<=-46){
if(r.integer<6>()<=409){
if(r.integer<43>()<=3){
if(r.integer<5>()<=493){
if(r.integer<35>()<=3){
if(r.integer<31>()<=9764){
if(r.integer<32>()<=5){
if(r.integer<51>()<=-68){
if(r.integer<36>()<=3){
if(r.integer<5>()<=383){
return 0x0.0p+0;
}else{
if(r.integer<5>()<=423){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<15>()<=0){
return 0x1.1f3df699439a2p-9;
}else{
if(r.integer<18>()<=4){
return 0x0.0p+0;
}else{
return -0x1.5575c05b00553p-6;
}
}
}
}else{
if(r.integer<24>()<=50){
return 0x0.0p+0;
}else{
return -0x1.8c7e28240b780p-3;
}
}
}else{
if(r.integer<1>()<=70){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<52>()<=66){
if(r.integer<50>()<=-51){
return -0x1.9e30014f8b587p-6;
}else{
if(r.integer<36>()<=18){
if(r.integer<5>()<=362){
return -0x1.189374bc6a7f0p+1;
}else{
if(r.integer<8>()<=-111){
return 0x0.0p+0;
}else{
return -0x1.3301f9c41587fp+0;
}
}
}else{
return 0x1.86c1396b92926p-6;
}
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<31>()<=11277){
if(r.integer<47>()<=-1){
return -0x1.cac083126e974p-4;
}else{
if(r.integer<14>()<=3){
if(r.integer<50>()<=-70){
return 0x1.1d3671ac14c68p-9;
}else{
return -0x1.47ae147ae147cp-5;
}
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<1>()<=73){
if(r.integer<26>()<=113){
if(r.integer<14>()<=5){
return -0x1.68c1726c27475p-3;
}else{
return 0x1.8036ec2d3ec25p-2;
}
}else{
return -0x1.9652bd3c36114p-5;
}
}else{
return 0x1.886594af4f0d8p-1;
}
}
}
}else{
return -0x1.999999999999ap-3;
}
}else{
if(r.integer<23>()<=37){
return 0x0.0p+0;
}else{
if(r.integer<43>()<=6){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<4>()<=165){
if(r.integer<39>()<=7){
return 0x0.0p+0;
}else{
return 0x1.47420fc33739fp-3;
}
}else{
if(r.integer<13>()<=8){
return 0x0.0p+0;
}else{
if(r.integer<1>()<=6){
return -0x1.d26817408e658p-10;
}else{
return 0x1.89cb78ed5a3edp-11;
}
}
}
}
}else{
if(r.integer<3>()<=84){
if(r.integer<1>()<=86){
if(r.integer<0>()<=2044){
if(r.integer<31>()<=11962){
return 0x0.0p+0;
}else{
return -0x1.e486a7cf675bfp-11;
}
}else{
if(r.integer<8>()<=141){
if(r.integer<55>()<=5){
if(r.integer<25>()<=86){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<24>()<=35){
return -0x1.ad7f29abcaf4cp-14;
}else{
if(r.integer<19>()<=41){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<31>()<=8083){
return 0x0.0p+0;
}else{
if(r.integer<24>()<=57){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}
}
}else{
if(r.integer<19>()<=87){
if(r.integer<33>()<=10){
return 0x0.0p+0;
}else{
return 0x1.463078df3302cp-6;
}
}else{
return 0x1.0a137f38c5437p-3;
}
}
}else{
if(r.integer<47>()<=-1){
return 0x0.0p+0;
}else{
if(r.integer<55>()<=9){
return 0x0.0p+0;
}else{
if(r.integer<13>()<=5){
return 0x0.0p+0;
}else{
return -0x1.452f342018238p-5;
}
}
}
}
}
}else{
if(r.integer<14>()<=8){
if(r.integer<31>()<=14167){
if(r.integer<2>()<=514){
if(r.integer<25>()<=86){
if(r.integer<23>()<=52){
return 0x0.0p+0;
}else{
return -0x1.955be84d4cc09p-13;
}
}else{
if(r.integer<13>()<=4){
return 0x0.0p+0;
}else{
if(r.integer<25>()<=122){
if(r.integer<29>()<=26){
if(r.integer<26>()<=53){
if(r.integer<31>()<=7173){
return -0x1.937339de73128p-3;
}else{
return -0x1.6dad1b7062ad7p-9;
}
}else{
if(r.integer<0>()<=1721){
return -0x1.a36e2eb1c432fp-10;
}else{
if(r.integer<3>()<=57){
if(r.integer<20>()<=57){
return 0x0.0p+0;
}else{
return 0x1.25dd095af294dp-4;
}
}else{
if(r.integer<15>()<=7){
return 0x1.7c14c41f63a45p-4;
}else{
return 0x1.7f6cc7a9775d4p-2;
}
}
}
}
}else{
if(r.integer<5>()<=49){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<19>()<=48){
if(r.integer<5>()<=477){
if(r.integer<29>()<=13){
if(r.integer<14>()<=3){
if(r.integer<38>()<=-2){
return -0x1.3ebae301cdce7p-5;
}else{
if(r.integer<1>()<=94){
if(r.integer<26>()<=258){
return 0x1.5e950bc052960p-1;
}else{
return 0x1.24946f444dbb3p+1;
}
}else{
if(r.integer<8>()<=-90){
return 0x1.f80b45d79b4a0p-1;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<44>()<=0){
return 0x1.991fc8b392b28p-5;
}else{
return 0x0.0p+0;
}
}
}else{
if(r.integer<10>()<=10){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=2060){
if(r.integer<26>()<=264){
if(r.integer<14>()<=7){
if(r.integer<53>()<=49){
if(r.integer<53>()<=39){
return 0x0.0p+0;
}else{
return -0x1.95e5ed1bad1ddp-4;
}
}else{
if(r.integer<6>()<=400){
if(r.integer<0>()<=1802){
return 0x1.ce895bdced66fp-5;
}else{
if(r.integer<4>()<=175){
return 0x1.3a33b7d056e91p-5;
}else{
if(r.integer<0>()<=1949){
return -0x1.b7cde2209c01dp-4;
}else{
return -0x1.771a310d4cf20p-8;
}
}
}
}else{
return 0x1.30a362a579923p-1;
}
}
}else{
return -0x1.f75104d551d68p-4;
}
}else{
return -0x1.64f1b0a541eb7p-4;
}
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<10>()<=83){
if(r.integer<29>()<=13){
return 0x1.30c0bd1f04d30p-3;
}else{
return -0x1.1008515660943p-10;
}
}else{
return -0x1.365fd23c67287p-5;
}
}
}else{
if(r.integer<15>()<=4){
if(r.integer<30>()<=21){
if(r.integer<8>()<=78){
if(r.integer<6>()<=23){
if(r.integer<20>()<=55){
if(r.integer<26>()<=213){
return 0x1.999999999999ap-3;
}else{
return 0x1.d38af068cdeb5p-2;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<19>()<=90){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}else{
return 0x0.0p+0;
}
}
}
}
}
}else{
if(r.integer<5>()<=373){
if(r.integer<6>()<=469){
if(r.integer<5>()<=345){
if(r.integer<23>()<=45){
if(r.integer<6>()<=21){
return -0x1.b56da6c9c8538p-6;
}else{
return 0x0.0p+0;
}
}else{
return 0x1.f970e97cfed4dp-4;
}
}else{
if(r.integer<29>()<=22){
return 0x1.2b1af204fbce8p+0;
}else{
return 0x0.0p+0;
}
}
}else{
return 0x1.b0930555d549ap-2;
}
}else{
if(r.integer<24>()<=40){
if(r.integer<4>()<=370){
return 0x1.9b3c85372412fp-7;
}else{
if(r.integer<16>()<=6){
return -0x1.90cec4c99e19ap-7;
}else{
if(r.integer<7>()<=-69){
return 0x1.a8e84643e9e15p-3;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<5>()<=394){
return -0x1.0fbb2f7ba3a67p-2;
}else{
return -0x1.083dbc23315d6p-7;
}
}
}
}
}else{
if(r.integer<50>()<=110){
return 0x0.0p+0;
}else{
if(r.integer<19>()<=42){
return 0x1.4304b92c99d79p-6;
}else{
return 0x0.0p+0;
}
}
}
}else{
if(r.integer<55>()<=2){
if(r.integer<31>()<=14914){
return 0x0.0p+0;
}else{
return -0x1.828c0be769dc2p-14;
}
}else{
if(r.integer<19>()<=67){
if(r.integer<0>()<=3304){
if(r.integer<25>()<=4){
if(r.integer<26>()<=83){
return 0x0.0p+0;
}else{
return 0x1.a02b08db7eb62p-2;
}
}else{
if(r.integer<1>()<=94){
if(r.integer<2>()<=337){
return 0x0.0p+0;
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<47>()<=-2){
if(r.integer<18>()<=6){
if(r.integer<33>()<=9){
return -0x1.8c32d8c110cfap-3;
}else{
return 0x1.80c67f79df73ep-10;
}
}else{
return 0x1.0899457aa24c6p-3;
}
}else{
return -0x1.54bb0197038fcp-8;
}
}
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<10>()<=69){
if(r.integer<8>()<=30){
if(r.integer<15>()<=3){
if(r.integer<13>()<=8){
return 0x0.0p+0;
}else{
return 0x1.b049d867eaddfp-10;
}
}else{
if(r.integer<0>()<=2684){
return 0x0.0p+0;
}else{
return 0x1.38a2ff61032c0p-1;
}
}
}else{
if(r.integer<6>()<=474){
return 0x1.a78a5a4ddfa00p-3;
}else{
return -0x1.9d3814008381ap-4;
}
}
}else{
if(r.integer<24>()<=23){
if(r.integer<0>()<=2301){
if(r.integer<35>()<=1){
return -0x1.2df55bb735e1bp-4;
}else{
return -0x1.a36e2eb1c432fp-10;
}
}else{
return 0x0.0p+0;
}
}else{
if(r.integer<0>()<=2810){
return 0x1.d4e3bef91c01ap-6;
}else{
return 0x0.0p+0;
}
}
}
}
}
}
}
}else{
if(r.integer<52>()<=58){
if(r.integer<31>()<=9629){
if(r.integer<36>()<=13){
if(r.integer<50>()<=-58){
if(r.integer<8>()<=-46){
return 0x0.0p+0;
}else{
return -0x1.2fe5f6bf64847p-3;
}
}else{
if(r.integer<29>()<=4){
if(r.integer<14>()<=5){
if(r.integer<15>()<=1){
return 0x1.7a2ee51420dd4p-1;
}else{
return 0x1.09fb147f87287p-3;
}
}else{
if(r.integer<38>()<=-1){
return 0x1.b5be685b08397p-3;
}else{
if(r.integer<20>()<=4){
return -0x1.7afea3df6db95p-2;
}else{
if(r.integer<19>()<=89){
return -0x1.35b964290e300p-7;
}else{
if(r.integer<8>()<=-46){
return -0x1.fff227584dbfap-4;
}else{
return 0x1.400652ab8b52ap-1;
}
}
}
}
}
}else{
if(r.integer<31>()<=7514){
if(r.integer<9>()<=44){
if(r.integer<25>()<=227){
if(r.integer<36>()<=8){
return -0x1.0936d7cfd7920p-12;
}else{
return -0x1.6ac29692fef5cp-2;
}
}else{
return 0x1.98993e7fed761p-3;
}
}else{
if(r.integer<2>()<=156){
return 0x1.92a737110e453p-11;
}else{
if(r.integer<8>()<=-126){
return 0x0.0p+0;
}else{
if(r.integer<0>()<=1933){
return -0x1.ca9e7776962c0p-5;
}else{
return -0x1.637de1b392b4ap-2;
}
}
}
}
}else{
if(r.integer<55>()<=4){
if(r.integer<10>()<=25){
return -0x1.a5734be4f65d7p-8;
}else{
return 0x1.832d898a89b0bp-7;
}
}else{
if(r.integer<54>()<=6){
if(r.integer<2>()<=12){
return -0x1.1813a2ed25edep-3;
}else{
if(r.integer<26>()<=256){
if(r.integer<26>()<=149){
if(r.integer<17>()<=0){
return 0x1.4c5e8b7a3ed9ap-4;
}else{
if(r.integer<0>()<=1851){
if(r.integer<54>()<=4){
if(r.integer<25>()<=120){
return 0x0.0p+0;
}else{
return -0x1.9b66a76ca9962p-3;
}
}else{
return -0x1.623c7f7204090p-3;
}
}else{
if(r.integer<8>()<=45){
return 0x0.0p+0;
}else{
if(r.integer<50>()<=-50){
return -0x1.949197fe5f57bp-2;
}else{
return -0x1.16e7894cd6844p-11;
}
}
}
}
}else{
return 0x1.3b02ccfca2f7ap-11;
}
}else{
return -0x1.2072ba7d56fcdp-5;
}
}
}else{
return 0x1.143fe69485f3bp-9;
}
}
}
}
}
}else{
if(r.integer<3>()<=19){
return 0x1.0d6e3bcbe8b9ap-11;
}else{
if(r.integer<15>()<=1){
if(r.integer<14>()<=0){
return 0x1.30086a7aeb17bp-3;
}else{
return -0x1.619d8a8520b11p-3;
}
}else{
if(r.integer<31>()<=8216){
return 0x1.e88d7299d0764p-13;
}else{
if(r.integer<29>()<=11){
if(r.integer<8>()<=198){
return -0x1.ff01389ce6f3dp-3;
}else{
return 0x1.547520892490cp-5;
}
}else{
if(r.integer<51>()<=-149){
return -0x1.3d2d694b60861p+0;
}else{
if(r.integer<26>()<=170){
if(r.integer<51>()<=-9){
return 0x1.420f6ac3f8bb8p-2;
}else{
return -0x1.390106c461ecep-7;
}
}else{
return -0x1.86e7769795cfcp-5;
}
}
}
}
}
}
}
}else{
if(r.integer<52>()<=42){
return -0x1.99938f6969fc0p-2;
}else{
if(r.integer<50>()<=53){
if(r.integer<31>()<=11349){
return -0x1.fb26553fff9fdp-10;
}else{
if(r.integer<5>()<=53){
return -0x1.6c6bae8e5f5c7p-1;
}else{
if(r.integer<51>()<=-375){
return -0x1.3f85513cb885cp+3;
}else{
if(r.integer<54>()<=0){
return -0x1.fa467a044a5edp-1;
}else{
return -0x1.d248347a544cdp-8;
}
}
}
}
}else{
if(r.integer<5>()<=477){
if(r.integer<10>()<=12){
if(r.integer<6>()<=272){
return -0x1.1de23e23264abp-11;
}else{
return 0x1.a13e5db5c311ap-10;
}
}else{
if(r.integer<19>()<=2){
return -0x1.d28375e3d867ap-3;
}else{
if(r.integer<17>()<=8){
return 0x1.13bbc0ce70995p-8;
}else{
return -0x1.c17406c097124p-6;
}
}
}
}else{
if(r.integer<14>()<=3){
return 0x1.fff049d959cf4p-10;
}else{
return -0x1.cac083126e978p-5;
}
}
}
}
}
}else{
if(r.integer<53>()<=4){
if(r.integer<5>()<=141){
if(r.integer<9>()<=63){
return -0x1.e8a00b7c76a55p-2;
}else{
if(r.integer<6>()<=276){
if(r.integer<15>()<=3){
return -0x1.467d232788965p-5;
}else{
return 0x1.0c2d818bba6cdp-10;
}
}else{
return 0x1.6f0dfb5078d58p-8;
}
}
}else{
if(r.integer<26>()<=226){
if(r.integer<25>()<=148){
return -0x1.73a0ca2f1f92ep-6;
}else{
return 0x1.828c0be769db4p-16;
}
}else{
return -0x1.dabcb8f4712d7p-5;
}
}
}else{
if(r.integer<10>()<=6){
return 0x1.48d5a7e71449ap-9;
}else{
if(r.integer<31>()<=11886){
if(r.integer<36>()<=17){
if(r.integer<0>()<=3920){
if(r.integer<32>()<=8){
if(r.integer<5>()<=378){
if(r.integer<16>()<=1){
if(r.integer<6>()<=259){
return -0x1.38fd7aca58c4cp-4;
}else{
if(r.integer<5>()<=5){
return 0x1.5810624dd2f1bp-2;
}else{
return -0x1.253e255cc62f7p-10;
}
}
}else{
return 0x1.e12ba97c0fc55p-9;
}
}else{
if(r.integer<43>()<=6){
if(r.integer<20>()<=95){
return -0x1.5191374501462p-11;
}else{
return 0x1.0d671bc2ff18ap-2;
}
}else{
if(r.integer<0>()<=3023){
return 0x1.26054d46daafap-3;
}else{
return -0x1.0624dd2f1a9fbp-6;
}
}
}
}else{
if(r.integer<20>()<=42){
return 0x1.474bd526c9a9ap-3;
}else{
if(r.integer<1>()<=83){
if(r.integer<1>()<=11){
return 0x1.8e4795190c02fp-11;
}else{
if(r.integer<8>()<=150){
if(r.integer<47>()<=-1){
return -0x1.3f16b690ce56ap-3;
}else{
return -0x1.bc98a222d516dp-9;
}
}else{
return 0x1.2b4e377084a26p-8;
}
}
}else{
if(r.integer<3>()<=16){
return 0x1.9971ec1afd143p+0;
}else{
if(r.integer<25>()<=203){
return -0x1.082a4607c742bp-7;
}else{
return 0x1.4c09e4ca605c2p+0;
}
}
}
}
}
}else{
return 0x1.471e69d0e8b60p-5;
}
}else{
if(r.integer<2>()<=48){
return 0x1.65a1bccb1965dp-1;
}else{
return -0x1.40ee57efffa48p-5;
}
}
}else{
if(r.integer<52>()<=94){
if(r.integer<31>()<=14435){
if(r.integer<30>()<=9){
if(r.integer<36>()<=18){
if(r.integer<31>()<=13299){
if(r.integer<2>()<=428){
if(r.integer<15>()<=3){
return -0x1.182a2c9d16a4bp-3;
}else{
return 0x1.ffb480a5accd7p-8;
}
}else{
return -0x1.9250e9c13e124p-1;
}
}else{
return -0x1.42fb6f7af6bc4p+0;
}
}else{
if(r.integer<7>()<=59){
return -0x1.7a79e5ac781a8p-6;
}else{
return 0x1.77ac8f8753af2p-3;
}
}
}else{
if(r.integer<33>()<=1){
return -0x1.7c622627d2559p-6;
}else{
if(r.integer<52>()<=75){
if(r.integer<5>()<=2){
return 0x1.9cf5f44e49db4p-2;
}else{
if(r.integer<1>()<=35){
return 0x1.8d321d20d4d9ap-7;
}else{
return -0x1.711947cfa26a2p-8;
}
}
}else{
if(r.integer<53>()<=316){
return 0x1.2c03af7a2047ap-8;
}else{
return 0x1.0a66b90221bbbp-2;
}
}
}
}
}else{
if(r.integer<36>()<=10){
if(r.integer<12>()<=0){
return 0x1.c9b9aa1a975d4p-9;
}else{
return -0x1.77c88e79aae6dp-3;
}
}else{
return 0x1.5e1d4d3ac99c7p-9;
}
}
}else{
if(r.integer<31>()<=16763){
if(r.integer<53>()<=20){
return -0x1.b994193e534f8p-7;
}else{
if(r.integer<0>()<=2653){
return 0x1.8f16b3cb9efa6p+0;
}else{
if(r.integer<4>()<=546){
if(r.integer<52>()<=106){
return 0x1.6a702db1e15b8p-6;
}else{
if(r.integer<9>()<=107){
return 0x1.f632e61e0f042p-2;
}else{
return 0x1.47325d0c2d048p-3;
}
}
}else{
return 0x1.689dc2de75893p+0;
}
}
}
}else{
return -0x1.6ce49b60a33e0p-3;
}
}
}
}
}
}
}
}
}
}
}
static int budget_correct(Node from,Node to,int base){BudgetResidualFeatures r(from,to,base);double value=0.;
value+=budget_tree_0(r);
value+=budget_tree_1(r);
value+=budget_tree_2(r);
value+=budget_tree_3(r);
value+=budget_tree_4(r);
value+=budget_tree_5(r);
value+=budget_tree_6(r);
value+=budget_tree_7(r);
value+=budget_tree_8(r);
value+=budget_tree_9(r);
value+=budget_tree_10(r);
value+=budget_tree_11(r);
value+=budget_tree_12(r);
value+=budget_tree_13(r);
value+=budget_tree_14(r);
value+=budget_tree_15(r);
return int(std::nearbyint(std::max(0.,double(base)+value)));}
